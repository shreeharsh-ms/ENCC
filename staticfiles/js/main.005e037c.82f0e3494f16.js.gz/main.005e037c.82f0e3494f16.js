function primary_crowd(prime, bool) {
    var e = {
        945: function (e) {
            e.exports = function (e) {
                function t(r) {
                    if (n[r]) return n[r].exports;
                    var a = n[r] = {
                        exports: {},
                        id: r,
                        loaded: !1
                    };
                    return e[r].call(a.exports, a, a.exports, t), a.loaded = !0, a.exports
                }
                var n = {};
                return t.m = e, t.c = n, t.p = "dist/", t(0)
            }([function (e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                var a = Object.assign || function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                },
                    i = (r(n(1)), n(6)),
                    o = r(i),
                    l = r(n(7)),
                    u = r(n(8)),
                    s = r(n(9)),
                    c = r(n(10)),
                    d = r(n(11)),
                    f = r(n(14)),
                    p = [],
                    h = !1,
                    m = {
                        offset: 120,
                        delay: 0,
                        easing: "ease",
                        duration: 400,
                        disable: !1,
                        once: !1,
                        startEvent: "DOMContentLoaded",
                        throttleDelay: 99,
                        debounceDelay: 50,
                        disableMutationObserver: !1
                    },
                    v = function () {
                        if (arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && (h = !0), h) return p = (0, d.default)(p, m), (0, c.default)(p, m.once), p
                    },
                    g = function () {
                        p = (0, f.default)(), v()
                    },
                    y = function () {
                        p.forEach((function (e, t) {
                            e.node.removeAttribute("data-aos"), e.node.removeAttribute("data-aos-easing"), e.node.removeAttribute("data-aos-duration"), e.node.removeAttribute("data-aos-delay")
                        }))
                    },
                    b = function (e) {
                        return !0 === e || "mobile" === e && s.default.mobile() || "phone" === e && s.default.phone() || "tablet" === e && s.default.tablet() || "function" == typeof e && !0 === e()
                    },
                    w = function (e) {
                        m = a(m, e), p = (0, f.default)();
                        var t = document.all && !window.atob;
                        return b(m.disable) || t ? y() : (m.disableMutationObserver || u.default.isSupported() || (console.info('\n      aos: MutationObserver is not supported on this browser,\n      code mutations observing has been disabled.\n      You may have to call "refreshHard()" by yourself.\n    '), m.disableMutationObserver = !0), document.querySelector("body").setAttribute("data-aos-easing", m.easing), document.querySelector("body").setAttribute("data-aos-duration", m.duration), document.querySelector("body").setAttribute("data-aos-delay", m.delay), "DOMContentLoaded" === m.startEvent && ["complete", "interactive"].indexOf(document.readyState) > -1 ? v(!0) : "load" === m.startEvent ? window.addEventListener(m.startEvent, (function () {
                            v(!0)
                        })) : document.addEventListener(m.startEvent, (function () {
                            v(!0)
                        })), window.addEventListener("resize", (0, l.default)(v, m.debounceDelay, !0)), window.addEventListener("orientationchange", (0, l.default)(v, m.debounceDelay, !0)), window.addEventListener("scroll", (0, o.default)((function () {
                            (0, c.default)(p, m.once)
                        }), m.throttleDelay)), m.disableMutationObserver || u.default.ready("[data-aos]", g), p)
                    };
                e.exports = {
                    init: w,
                    refresh: v,
                    refreshHard: g
                }
            }, function (e, t) { }, , , , , function (e, t) {
                (function (t) {
                    "use strict";

                    function n(e, t, n) {
                        function r(t) {
                            var n = m,
                                r = v;
                            return m = v = void 0, _ = t, y = e.apply(r, n)
                        }

                        function i(e) {
                            return _ = e, b = setTimeout(c, t), E ? r(e) : y
                        }

                        function o(e) {
                            var n = t - (e - w);
                            return C ? k(n, g - (e - _)) : n
                        }

                        function u(e) {
                            var n = e - w;
                            return void 0 === w || n >= t || n < 0 || C && e - _ >= g
                        }

                        function c() {
                            var e = S();
                            return u(e) ? d(e) : void (b = setTimeout(c, o(e)))
                        }

                        function d(e) {
                            return b = void 0, N && m ? r(e) : (m = v = void 0, y)
                        }

                        function f() {
                            void 0 !== b && clearTimeout(b), _ = 0, m = w = v = b = void 0
                        }

                        function p() {
                            return void 0 === b ? y : d(S())
                        }

                        function h() {
                            var e = S(),
                                n = u(e);
                            if (m = arguments, v = this, w = e, n) {
                                if (void 0 === b) return i(w);
                                if (C) return b = setTimeout(c, t), r(w)
                            }
                            return void 0 === b && (b = setTimeout(c, t)), y
                        }
                        var m, v, g, y, b, w, _ = 0,
                            E = !1,
                            C = !1,
                            N = !0;
                        if ("function" != typeof e) throw new TypeError(s);
                        return t = l(t) || 0, a(n) && (E = !!n.leading, g = (C = "maxWait" in n) ? x(l(n.maxWait) || 0, t) : g, N = "trailing" in n ? !!n.trailing : N), h.cancel = f, h.flush = p, h
                    }

                    function r(e, t, r) {
                        var i = !0,
                            o = !0;
                        if ("function" != typeof e) throw new TypeError(s);
                        return a(r) && (i = "leading" in r ? !!r.leading : i, o = "trailing" in r ? !!r.trailing : o), n(e, t, {
                            leading: i,
                            maxWait: t,
                            trailing: o
                        })
                    }

                    function a(e) {
                        var t = "undefined" == typeof e ? "undefined" : u(e);
                        return !!e && ("object" == t || "function" == t)
                    }

                    function i(e) {
                        return !!e && "object" == ("undefined" == typeof e ? "undefined" : u(e))
                    }

                    function o(e) {
                        return "symbol" == ("undefined" == typeof e ? "undefined" : u(e)) || i(e) && w.call(e) == d
                    }

                    function l(e) {
                        if ("number" == typeof e) return e;
                        if (o(e)) return c;
                        if (a(e)) {
                            var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                            e = a(t) ? t + "" : t
                        }
                        if ("string" != typeof e) return 0 === e ? e : +e;
                        e = e.replace(f, "");
                        var n = h.test(e);
                        return n || m.test(e) ? v(e.slice(2), n ? 2 : 8) : p.test(e) ? c : +e
                    }
                    var u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
                        return typeof e
                    } : function (e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    },
                        s = "Expected a function",
                        c = NaN,
                        d = "[object Symbol]",
                        f = /^\s+|\s+$/g,
                        p = /^[-+]0x[0-9a-f]+$/i,
                        h = /^0b[01]+$/i,
                        m = /^0o[0-7]+$/i,
                        v = parseInt,
                        g = "object" == ("undefined" == typeof t ? "undefined" : u(t)) && t && t.Object === Object && t,
                        y = "object" == ("undefined" == typeof self ? "undefined" : u(self)) && self && self.Object === Object && self,
                        b = g || y || Function("return this")(),
                        w = Object.prototype.toString,
                        x = Math.max,
                        k = Math.min,
                        S = function () {
                            return b.Date.now()
                        };
                    e.exports = r
                }).call(t, function () {
                    return this
                }())
            }, function (e, t) {
                (function (t) {
                    "use strict";

                    function n(e, t, n) {
                        function a(t) {
                            var n = m,
                                r = v;
                            return m = v = void 0, _ = t, y = e.apply(r, n)
                        }

                        function i(e) {
                            return _ = e, b = setTimeout(c, t), E ? a(e) : y
                        }

                        function l(e) {
                            var n = t - (e - S);
                            return C ? x(n, g - (e - _)) : n
                        }

                        function s(e) {
                            var n = e - S;
                            return void 0 === S || n >= t || n < 0 || C && e - _ >= g
                        }

                        function c() {
                            var e = k();
                            return s(e) ? d(e) : void (b = setTimeout(c, l(e)))
                        }

                        function d(e) {
                            return b = void 0, N && m ? a(e) : (m = v = void 0, y)
                        }

                        function f() {
                            void 0 !== b && clearTimeout(b), _ = 0, m = S = v = b = void 0
                        }

                        function p() {
                            return void 0 === b ? y : d(k())
                        }

                        function h() {
                            var e = k(),
                                n = s(e);
                            if (m = arguments, v = this, S = e, n) {
                                if (void 0 === b) return i(S);
                                if (C) return b = setTimeout(c, t), a(S)
                            }
                            return void 0 === b && (b = setTimeout(c, t)), y
                        }
                        var m, v, g, y, b, S, _ = 0,
                            E = !1,
                            C = !1,
                            N = !0;
                        if ("function" != typeof e) throw new TypeError(u);
                        return t = o(t) || 0, r(n) && (E = !!n.leading, g = (C = "maxWait" in n) ? w(o(n.maxWait) || 0, t) : g, N = "trailing" in n ? !!n.trailing : N), h.cancel = f, h.flush = p, h
                    }

                    function r(e) {
                        var t = "undefined" == typeof e ? "undefined" : l(e);
                        return !!e && ("object" == t || "function" == t)
                    }

                    function a(e) {
                        return !!e && "object" == ("undefined" == typeof e ? "undefined" : l(e))
                    }

                    function i(e) {
                        return "symbol" == ("undefined" == typeof e ? "undefined" : l(e)) || a(e) && b.call(e) == c
                    }

                    function o(e) {
                        if ("number" == typeof e) return e;
                        if (i(e)) return s;
                        if (r(e)) {
                            var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                            e = r(t) ? t + "" : t
                        }
                        if ("string" != typeof e) return 0 === e ? e : +e;
                        e = e.replace(d, "");
                        var n = p.test(e);
                        return n || h.test(e) ? m(e.slice(2), n ? 2 : 8) : f.test(e) ? s : +e
                    }
                    var l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
                        return typeof e
                    } : function (e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    },
                        u = "Expected a function",
                        s = NaN,
                        c = "[object Symbol]",
                        d = /^\s+|\s+$/g,
                        f = /^[-+]0x[0-9a-f]+$/i,
                        p = /^0b[01]+$/i,
                        h = /^0o[0-7]+$/i,
                        m = parseInt,
                        v = "object" == ("undefined" == typeof t ? "undefined" : l(t)) && t && t.Object === Object && t,
                        g = "object" == ("undefined" == typeof self ? "undefined" : l(self)) && self && self.Object === Object && self,
                        y = v || g || Function("return this")(),
                        b = Object.prototype.toString,
                        w = Math.max,
                        x = Math.min,
                        k = function () {
                            return y.Date.now()
                        };
                    e.exports = n
                }).call(t, function () {
                    return this
                }())
            }, function (e, t) {
                "use strict";

                function n(e) {
                    var t = void 0,
                        r = void 0;
                    for (t = 0; t < e.length; t += 1) {
                        if ((r = e[t]).dataset && r.dataset.aos) return !0;
                        if (r.children && n(r.children)) return !0
                    }
                    return !1
                }

                function r() {
                    return window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver
                }

                function a() {
                    return !!r()
                }

                function i(e, t) {
                    var n = window.document,
                        a = new (r())(o);
                    l = t, a.observe(n.documentElement, {
                        childList: !0,
                        subtree: !0,
                        removedNodes: !0
                    })
                }

                function o(e) {
                    e && e.forEach((function (e) {
                        var t = Array.prototype.slice.call(e.addedNodes),
                            r = Array.prototype.slice.call(e.removedNodes);
                        if (n(t.concat(r))) return l()
                    }))
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var l = function () { };
                t.default = {
                    isSupported: a,
                    ready: i
                }
            }, function (e, t) {
                "use strict";

                function n(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }

                function r() {
                    return navigator.userAgent || navigator.vendor || window.opera || ""
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var a = function () {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var r = t[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                        }
                    }
                    return function (t, n, r) {
                        return n && e(t.prototype, n), r && e(t, r), t
                    }
                }(),
                    i = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,
                    o = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i,
                    l = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i,
                    u = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i,
                    s = function () {
                        function e() {
                            n(this, e)
                        }
                        return a(e, [{
                            key: "phone",
                            value: function () {
                                var e = r();
                                return !(!i.test(e) && !o.test(e.substr(0, 4)))
                            }
                        }, {
                            key: "mobile",
                            value: function () {
                                var e = r();
                                return !(!l.test(e) && !u.test(e.substr(0, 4)))
                            }
                        }, {
                            key: "tablet",
                            value: function () {
                                return this.mobile() && !this.phone()
                            }
                        }]), e
                    }();
                t.default = new s
            }, function (e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var n = function (e, t, n) {
                    var r = e.node.getAttribute("data-aos-once");
                    t > e.position ? e.node.classList.add("aos-animate") : "undefined" != typeof r && ("false" === r || !n && "true" !== r) && e.node.classList.remove("aos-animate")
                },
                    r = function (e, t) {
                        var r = window.pageYOffset,
                            a = window.innerHeight;
                        e.forEach((function (e, i) {
                            n(e, a + r, t)
                        }))
                    };
                t.default = r
            }, function (e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var a = r(n(12)),
                    i = function (e, t) {
                        return e.forEach((function (e, n) {
                            e.node.classList.add("aos-init"), e.position = (0, a.default)(e.node, t.offset)
                        })), e
                    };
                t.default = i
            }, function (e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var a = r(n(13)),
                    i = function (e, t) {
                        var n = 0,
                            r = 0,
                            i = window.innerHeight,
                            o = {
                                offset: e.getAttribute("data-aos-offset"),
                                anchor: e.getAttribute("data-aos-anchor"),
                                anchorPlacement: e.getAttribute("data-aos-anchor-placement")
                            };
                        switch (o.offset && !isNaN(o.offset) && (r = parseInt(o.offset)), o.anchor && document.querySelectorAll(o.anchor) && (e = document.querySelectorAll(o.anchor)[0]), n = (0, a.default)(e).top, o.anchorPlacement) {
                            case "top-bottom":
                                break;
                            case "center-bottom":
                                n += e.offsetHeight / 2;
                                break;
                            case "bottom-bottom":
                                n += e.offsetHeight;
                                break;
                            case "top-center":
                                n += i / 2;
                                break;
                            case "bottom-center":
                                n += i / 2 + e.offsetHeight;
                                break;
                            case "center-center":
                                n += i / 2 + e.offsetHeight / 2;
                                break;
                            case "top-top":
                                n += i;
                                break;
                            case "bottom-top":
                                n += e.offsetHeight + i;
                                break;
                            case "center-top":
                                n += e.offsetHeight / 2 + i
                        }
                        return o.anchorPlacement || o.offset || isNaN(t) || (r = t), n + r
                    };
                t.default = i
            }, function (e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var n = function (e) {
                    for (var t = 0, n = 0; e && !isNaN(e.offsetLeft) && !isNaN(e.offsetTop);) t += e.offsetLeft - ("BODY" != e.tagName ? e.scrollLeft : 0), n += e.offsetTop - ("BODY" != e.tagName ? e.scrollTop : 0), e = e.offsetParent;
                    return {
                        top: n,
                        left: t
                    }
                };
                t.default = n
            }, function (e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var n = function (e) {
                    return e = e || document.querySelectorAll("[data-aos]"), Array.prototype.map.call(e, (function (e) {
                        return {
                            node: e
                        }
                    }))
                };
                t.default = n
            }])
        },
        463: function (e, t, n) {
            "use strict";
            var r = n(791),
                a = n(296);

            function i(e) {
                for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
                return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
            }
            var o = new Set,
                l = {};

            function u(e, t) {
                s(e, t), s(e + "Capture", t)
            }

            function s(e, t) {
                for (l[e] = t, e = 0; e < t.length; e++) o.add(t[e])
            }
            var c = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement),
                d = Object.prototype.hasOwnProperty,
                f = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
                p = {},
                h = {};

            function m(e, t, n, r, a, i, o) {
                this.acceptsBooleans = 2 === t || 3 === t || 4 === t, this.attributeName = r, this.attributeNamespace = a, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = i, this.removeEmptyString = o
            }
            var v = {};
            "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach((function (e) {
                v[e] = new m(e, 0, !1, e, null, !1, !1)
            })), [
                ["acceptCharset", "accept-charset"],
                ["className", "class"],
                ["htmlFor", "for"],
                ["httpEquiv", "http-equiv"]
            ].forEach((function (e) {
                var t = e[0];
                v[t] = new m(t, 1, !1, e[1], null, !1, !1)
            })), ["contentEditable", "draggable", "spellCheck", "value"].forEach((function (e) {
                v[e] = new m(e, 2, !1, e.toLowerCase(), null, !1, !1)
            })), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach((function (e) {
                v[e] = new m(e, 2, !1, e, null, !1, !1)
            })), "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach((function (e) {
                v[e] = new m(e, 3, !1, e.toLowerCase(), null, !1, !1)
            })), ["checked", "multiple", "muted", "selected"].forEach((function (e) {
                v[e] = new m(e, 3, !0, e, null, !1, !1)
            })), ["capture", "download"].forEach((function (e) {
                v[e] = new m(e, 4, !1, e, null, !1, !1)
            })), ["cols", "rows", "size", "span"].forEach((function (e) {
                v[e] = new m(e, 6, !1, e, null, !1, !1)
            })), ["rowSpan", "start"].forEach((function (e) {
                v[e] = new m(e, 5, !1, e.toLowerCase(), null, !1, !1)
            }));
            var g = /[\-:]([a-z])/g;

            function y(e) {
                return e[1].toUpperCase()
            }

            function b(e, t, n, r) {
                var a = v.hasOwnProperty(t) ? v[t] : null;
                (null !== a ? 0 !== a.type : r || !(2 < t.length) || "o" !== t[0] && "O" !== t[0] || "n" !== t[1] && "N" !== t[1]) && (function (e, t, n, r) {
                    if (null === t || "undefined" === typeof t || function (e, t, n, r) {
                        if (null !== n && 0 === n.type) return !1;
                        switch (typeof t) {
                            case "function":
                            case "symbol":
                                return !0;
                            case "boolean":
                                return !r && (null !== n ? !n.acceptsBooleans : "data-" !== (e = e.toLowerCase().slice(0, 5)) && "aria-" !== e);
                            default:
                                return !1
                        }
                    }(e, t, n, r)) return !0;
                    if (r) return !1;
                    if (null !== n) switch (n.type) {
                        case 3:
                            return !t;
                        case 4:
                            return !1 === t;
                        case 5:
                            return isNaN(t);
                        case 6:
                            return isNaN(t) || 1 > t
                    }
                    return !1
                }(t, n, a, r) && (n = null), r || null === a ? function (e) {
                    return !!d.call(h, e) || !d.call(p, e) && (f.test(e) ? h[e] = !0 : (p[e] = !0, !1))
                }(t) && (null === n ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : a.mustUseProperty ? e[a.propertyName] = null === n ? 3 !== a.type && "" : n : (t = a.attributeName, r = a.attributeNamespace, null === n ? e.removeAttribute(t) : (n = 3 === (a = a.type) || 4 === a && !0 === n ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
            }
            "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach((function (e) {
                var t = e.replace(g, y);
                v[t] = new m(t, 1, !1, e, null, !1, !1)
            })), "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach((function (e) {
                var t = e.replace(g, y);
                v[t] = new m(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
            })), ["xml:base", "xml:lang", "xml:space"].forEach((function (e) {
                var t = e.replace(g, y);
                v[t] = new m(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
            })), ["tabIndex", "crossOrigin"].forEach((function (e) {
                v[e] = new m(e, 1, !1, e.toLowerCase(), null, !1, !1)
            })), v.xlinkHref = new m("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1), ["src", "href", "action", "formAction"].forEach((function (e) {
                v[e] = new m(e, 1, !1, e.toLowerCase(), null, !0, !0)
            }));
            var w = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
                x = Symbol.for("react.element"),
                k = Symbol.for("react.portal"),
                S = Symbol.for("react.fragment"),
                _ = Symbol.for("react.strict_mode"),
                E = Symbol.for("react.profiler"),
                C = Symbol.for("react.provider"),
                N = Symbol.for("react.context"),
                j = Symbol.for("react.forward_ref"),
                T = Symbol.for("react.suspense"),
                P = Symbol.for("react.suspense_list"),
                z = Symbol.for("react.memo"),
                M = Symbol.for("react.lazy");
            Symbol.for("react.scope"), Symbol.for("react.debug_trace_mode");
            var A = Symbol.for("react.offscreen");
            Symbol.for("react.legacy_hidden"), Symbol.for("react.cache"), Symbol.for("react.tracing_marker");
            var O = Symbol.iterator;

            function L(e) {
                return null === e || "object" !== typeof e ? null : "function" === typeof (e = O && e[O] || e["@@iterator"]) ? e : null
            }
            var R, I = Object.assign;

            function D(e) {
                if (void 0 === R) try {
                    throw Error()
                } catch (n) {
                    var t = n.stack.trim().match(/\n( *(at )?)/);
                    R = t && t[1] || ""
                }
                return "\n" + R + e
            }
            var F = !1;

            function U(e, t) {
                if (!e || F) return "";
                F = !0;
                var n = Error.prepareStackTrace;
                Error.prepareStackTrace = void 0;
                try {
                    if (t)
                        if (t = function () {
                            throw Error()
                        }, Object.defineProperty(t.prototype, "props", {
                            set: function () {
                                throw Error()
                            }
                        }), "object" === typeof Reflect && Reflect.construct) {
                            try {
                                Reflect.construct(t, [])
                            } catch (s) {
                                var r = s
                            }
                            Reflect.construct(e, [], t)
                        } else {
                            try {
                                t.call()
                            } catch (s) {
                                r = s
                            }
                            e.call(t.prototype)
                        }
                    else {
                        try {
                            throw Error()
                        } catch (s) {
                            r = s
                        }
                        e()
                    }
                } catch (s) {
                    if (s && r && "string" === typeof s.stack) {
                        for (var a = s.stack.split("\n"), i = r.stack.split("\n"), o = a.length - 1, l = i.length - 1; 1 <= o && 0 <= l && a[o] !== i[l];) l--;
                        for (; 1 <= o && 0 <= l; o--, l--)
                            if (a[o] !== i[l]) {
                                if (1 !== o || 1 !== l)
                                    do {
                                        if (o--, 0 > --l || a[o] !== i[l]) {
                                            var u = "\n" + a[o].replace(" at new ", " at ");
                                            return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u
                                        }
                                    } while (1 <= o && 0 <= l);
                                break
                            }
                    }
                } finally {
                    F = !1, Error.prepareStackTrace = n
                }
                return (e = e ? e.displayName || e.name : "") ? D(e) : ""
            }

            function B(e) {
                switch (e.tag) {
                    case 5:
                        return D(e.type);
                    case 16:
                        return D("Lazy");
                    case 13:
                        return D("Suspense");
                    case 19:
                        return D("SuspenseList");
                    case 0:
                    case 2:
                    case 15:
                        return e = U(e.type, !1);
                    case 11:
                        return e = U(e.type.render, !1);
                    case 1:
                        return e = U(e.type, !0);
                    default:
                        return ""
                }
            }

            function V(e) {
                if (null == e) return null;
                if ("function" === typeof e) return e.displayName || e.name || null;
                if ("string" === typeof e) return e;
                switch (e) {
                    case S:
                        return "Fragment";
                    case k:
                        return "Portal";
                    case E:
                        return "Profiler";
                    case _:
                        return "StrictMode";
                    case T:
                        return "Suspense";
                    case P:
                        return "SuspenseList"
                }
                if ("object" === typeof e) switch (e.$$typeof) {
                    case N:
                        return (e.displayName || "Context") + ".Consumer";
                    case C:
                        return (e._context.displayName || "Context") + ".Provider";
                    case j:
                        var t = e.render;
                        return (e = e.displayName) || (e = "" !== (e = t.displayName || t.name || "") ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
                    case z:
                        return null !== (t = e.displayName || null) ? t : V(e.type) || "Memo";
                    case M:
                        t = e._payload, e = e._init;
                        try {
                            return V(e(t))
                        } catch (n) { }
                }
                return null
            }

            function H(e) {
                var t = e.type;
                switch (e.tag) {
                    case 24:
                        return "Cache";
                    case 9:
                        return (t.displayName || "Context") + ".Consumer";
                    case 10:
                        return (t._context.displayName || "Context") + ".Provider";
                    case 18:
                        return "DehydratedFragment";
                    case 11:
                        return e = (e = t.render).displayName || e.name || "", t.displayName || ("" !== e ? "ForwardRef(" + e + ")" : "ForwardRef");
                    case 7:
                        return "Fragment";
                    case 5:
                        return t;
                    case 4:
                        return "Portal";
                    case 3:
                        return "Root";
                    case 6:
                        return "Text";
                    case 16:
                        return V(t);
                    case 8:
                        return t === _ ? "StrictMode" : "Mode";
                    case 22:
                        return "Offscreen";
                    case 12:
                        return "Profiler";
                    case 21:
                        return "Scope";
                    case 13:
                        return "Suspense";
                    case 19:
                        return "SuspenseList";
                    case 25:
                        return "TracingMarker";
                    case 1:
                    case 0:
                    case 17:
                    case 2:
                    case 14:
                    case 15:
                        if ("function" === typeof t) return t.displayName || t.name || null;
                        if ("string" === typeof t) return t
                }
                return null
            }

            function W(e) {
                switch (typeof e) {
                    case "boolean":
                    case "number":
                    case "string":
                    case "undefined":
                    case "object":
                        return e;
                    default:
                        return ""
                }
            }

            function Q(e) {
                var t = e.type;
                return (e = e.nodeName) && "input" === e.toLowerCase() && ("checkbox" === t || "radio" === t)
            }

            function G(e) {
                e._valueTracker || (e._valueTracker = function (e) {
                    var t = Q(e) ? "checked" : "value",
                        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
                        r = "" + e[t];
                    if (!e.hasOwnProperty(t) && "undefined" !== typeof n && "function" === typeof n.get && "function" === typeof n.set) {
                        var a = n.get,
                            i = n.set;
                        return Object.defineProperty(e, t, {
                            configurable: !0,
                            get: function () {
                                return a.call(this)
                            },
                            set: function (e) {
                                r = "" + e, i.call(this, e)
                            }
                        }), Object.defineProperty(e, t, {
                            enumerable: n.enumerable
                        }), {
                            getValue: function () {
                                return r
                            },
                            setValue: function (e) {
                                r = "" + e
                            },
                            stopTracking: function () {
                                e._valueTracker = null, delete e[t]
                            }
                        }
                    }
                }(e))
            }

            function X(e) {
                if (!e) return !1;
                var t = e._valueTracker;
                if (!t) return !0;
                var n = t.getValue(),
                    r = "";
                return e && (r = Q(e) ? e.checked ? "true" : "false" : e.value), (e = r) !== n && (t.setValue(e), !0)
            }

            function q(e) {
                if ("undefined" === typeof (e = e || ("undefined" !== typeof document ? document : void 0))) return null;
                try {
                    return e.activeElement || e.body
                } catch (t) {
                    return e.body
                }
            }

            function Y(e, t) {
                var n = t.checked;
                return I({}, t, {
                    defaultChecked: void 0,
                    defaultValue: void 0,
                    value: void 0,
                    checked: null != n ? n : e._wrapperState.initialChecked
                })
            }

            function K(e, t) {
                var n = null == t.defaultValue ? "" : t.defaultValue,
                    r = null != t.checked ? t.checked : t.defaultChecked;
                n = W(null != t.value ? t.value : n), e._wrapperState = {
                    initialChecked: r,
                    initialValue: n,
                    controlled: "checkbox" === t.type || "radio" === t.type ? null != t.checked : null != t.value
                }
            }

            function $(e, t) {
                null != (t = t.checked) && b(e, "checked", t, !1)
            }

            function J(e, t) {
                $(e, t);
                var n = W(t.value),
                    r = t.type;
                if (null != n) "number" === r ? (0 === n && "" === e.value || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
                else if ("submit" === r || "reset" === r) return void e.removeAttribute("value");
                t.hasOwnProperty("value") ? ee(e, t.type, n) : t.hasOwnProperty("defaultValue") && ee(e, t.type, W(t.defaultValue)), null == t.checked && null != t.defaultChecked && (e.defaultChecked = !!t.defaultChecked)
            }

            function Z(e, t, n) {
                if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
                    var r = t.type;
                    if (!("submit" !== r && "reset" !== r || void 0 !== t.value && null !== t.value)) return;
                    t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
                }
                "" !== (n = e.name) && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, "" !== n && (e.name = n)
            }

            function ee(e, t, n) {
                "number" === t && q(e.ownerDocument) === e || (null == n ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
            }
            var te = Array.isArray;

            function ne(e, t, n, r) {
                if (e = e.options, t) {
                    t = {};
                    for (var a = 0; a < n.length; a++) t["$" + n[a]] = !0;
                    for (n = 0; n < e.length; n++) a = t.hasOwnProperty("$" + e[n].value), e[n].selected !== a && (e[n].selected = a), a && r && (e[n].defaultSelected = !0)
                } else {
                    for (n = "" + W(n), t = null, a = 0; a < e.length; a++) {
                        if (e[a].value === n) return e[a].selected = !0, void (r && (e[a].defaultSelected = !0));
                        null !== t || e[a].disabled || (t = e[a])
                    }
                    null !== t && (t.selected = !0)
                }
            }

            function re(e, t) {
                if (null != t.dangerouslySetInnerHTML) throw Error(i(91));
                return I({}, t, {
                    value: void 0,
                    defaultValue: void 0,
                    children: "" + e._wrapperState.initialValue
                })
            }

            function ae(e, t) {
                var n = t.value;
                if (null == n) {
                    if (n = t.children, t = t.defaultValue, null != n) {
                        if (null != t) throw Error(i(92));
                        if (te(n)) {
                            if (1 < n.length) throw Error(i(93));
                            n = n[0]
                        }
                        t = n
                    }
                    null == t && (t = ""), n = t
                }
                e._wrapperState = {
                    initialValue: W(n)
                }
            }

            function ie(e, t) {
                var n = W(t.value),
                    r = W(t.defaultValue);
                null != n && ((n = "" + n) !== e.value && (e.value = n), null == t.defaultValue && e.defaultValue !== n && (e.defaultValue = n)), null != r && (e.defaultValue = "" + r)
            }

            function oe(e) {
                var t = e.textContent;
                t === e._wrapperState.initialValue && "" !== t && null !== t && (e.value = t)
            }

            function le(e) {
                switch (e) {
                    case "svg":
                        return "http://www.w3.org/2000/svg";
                    case "math":
                        return "http://www.w3.org/1998/Math/MathML";
                    default:
                        return "http://www.w3.org/1999/xhtml"
                }
            }

            function ue(e, t) {
                return null == e || "http://www.w3.org/1999/xhtml" === e ? le(t) : "http://www.w3.org/2000/svg" === e && "foreignObject" === t ? "http://www.w3.org/1999/xhtml" : e
            }
            var se, ce, de = (ce = function (e, t) {
                if ("http://www.w3.org/2000/svg" !== e.namespaceURI || "innerHTML" in e) e.innerHTML = t;
                else {
                    for ((se = se || document.createElement("div")).innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = se.firstChild; e.firstChild;) e.removeChild(e.firstChild);
                    for (; t.firstChild;) e.appendChild(t.firstChild)
                }
            }, "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function (e, t, n, r) {
                MSApp.execUnsafeLocalFunction((function () {
                    return ce(e, t)
                }))
            } : ce);

            function fe(e, t) {
                if (t) {
                    var n = e.firstChild;
                    if (n && n === e.lastChild && 3 === n.nodeType) return void (n.nodeValue = t)
                }
                e.textContent = t
            }
            var pe = {
                animationIterationCount: !0,
                aspectRatio: !0,
                borderImageOutset: !0,
                borderImageSlice: !0,
                borderImageWidth: !0,
                boxFlex: !0,
                boxFlexGroup: !0,
                boxOrdinalGroup: !0,
                columnCount: !0,
                columns: !0,
                flex: !0,
                flexGrow: !0,
                flexPositive: !0,
                flexShrink: !0,
                flexNegative: !0,
                flexOrder: !0,
                gridArea: !0,
                gridRow: !0,
                gridRowEnd: !0,
                gridRowSpan: !0,
                gridRowStart: !0,
                gridColumn: !0,
                gridColumnEnd: !0,
                gridColumnSpan: !0,
                gridColumnStart: !0,
                fontWeight: !0,
                lineClamp: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                tabSize: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0,
                fillOpacity: !0,
                floodOpacity: !0,
                stopOpacity: !0,
                strokeDasharray: !0,
                strokeDashoffset: !0,
                strokeMiterlimit: !0,
                strokeOpacity: !0,
                strokeWidth: !0
            },
                he = ["Webkit", "ms", "Moz", "O"];

            function me(e, t, n) {
                return null == t || "boolean" === typeof t || "" === t ? "" : n || "number" !== typeof t || 0 === t || pe.hasOwnProperty(e) && pe[e] ? ("" + t).trim() : t + "px"
            }

            function ve(e, t) {
                for (var n in e = e.style, t)
                    if (t.hasOwnProperty(n)) {
                        var r = 0 === n.indexOf("--"),
                            a = me(n, t[n], r);
                        "float" === n && (n = "cssFloat"), r ? e.setProperty(n, a) : e[n] = a
                    }
            }
            Object.keys(pe).forEach((function (e) {
                he.forEach((function (t) {
                    t = t + e.charAt(0).toUpperCase() + e.substring(1), pe[t] = pe[e]
                }))
            }));
            var ge = I({
                menuitem: !0
            }, {
                area: !0,
                base: !0,
                br: !0,
                col: !0,
                embed: !0,
                hr: !0,
                img: !0,
                input: !0,
                keygen: !0,
                link: !0,
                meta: !0,
                param: !0,
                source: !0,
                track: !0,
                wbr: !0
            });

            function ye(e, t) {
                if (t) {
                    if (ge[e] && (null != t.children || null != t.dangerouslySetInnerHTML)) throw Error(i(137, e));
                    if (null != t.dangerouslySetInnerHTML) {
                        if (null != t.children) throw Error(i(60));
                        if ("object" !== typeof t.dangerouslySetInnerHTML || !("__html" in t.dangerouslySetInnerHTML)) throw Error(i(61))
                    }
                    if (null != t.style && "object" !== typeof t.style) throw Error(i(62))
                }
            }

            function be(e, t) {
                if (-1 === e.indexOf("-")) return "string" === typeof t.is;
                switch (e) {
                    case "annotation-xml":
                    case "color-profile":
                    case "font-face":
                    case "font-face-src":
                    case "font-face-uri":
                    case "font-face-format":
                    case "font-face-name":
                    case "missing-glyph":
                        return !1;
                    default:
                        return !0
                }
            }
            var we = null;

            function xe(e) {
                return (e = e.target || e.srcElement || window).correspondingUseElement && (e = e.correspondingUseElement), 3 === e.nodeType ? e.parentNode : e
            }
            var ke = null,
                Se = null,
                _e = null;

            function Ee(e) {
                if (e = ba(e)) {
                    if ("function" !== typeof ke) throw Error(i(280));
                    var t = e.stateNode;
                    t && (t = xa(t), ke(e.stateNode, e.type, t))
                }
            }

            function Ce(e) {
                Se ? _e ? _e.push(e) : _e = [e] : Se = e
            }

            function Ne() {
                if (Se) {
                    var e = Se,
                        t = _e;
                    if (_e = Se = null, Ee(e), t)
                        for (e = 0; e < t.length; e++) Ee(t[e])
                }
            }

            function je(e, t) {
                return e(t)
            }

            function Te() { }
            var Pe = !1;

            function ze(e, t, n) {
                if (Pe) return e(t, n);
                Pe = !0;
                try {
                    return je(e, t, n)
                } finally {
                    Pe = !1, (null !== Se || null !== _e) && (Te(), Ne())
                }
            }

            function Me(e, t) {
                var n = e.stateNode;
                if (null === n) return null;
                var r = xa(n);
                if (null === r) return null;
                n = r[t];
                e: switch (t) {
                    case "onClick":
                    case "onClickCapture":
                    case "onDoubleClick":
                    case "onDoubleClickCapture":
                    case "onMouseDown":
                    case "onMouseDownCapture":
                    case "onMouseMove":
                    case "onMouseMoveCapture":
                    case "onMouseUp":
                    case "onMouseUpCapture":
                    case "onMouseEnter":
                        (r = !r.disabled) || (r = !("button" === (e = e.type) || "input" === e || "select" === e || "textarea" === e)), e = !r;
                        break e;
                    default:
                        e = !1
                }
                if (e) return null;
                if (n && "function" !== typeof n) throw Error(i(231, t, typeof n));
                return n
            }
            var Ae = !1;
            if (c) try {
                var Oe = {};
                Object.defineProperty(Oe, "passive", {
                    get: function () {
                        Ae = !0
                    }
                }), window.addEventListener("test", Oe, Oe), window.removeEventListener("test", Oe, Oe)
            } catch (ce) {
                Ae = !1
            }

            function Le(e, t, n, r, a, i, o, l, u) {
                var s = Array.prototype.slice.call(arguments, 3);
                try {
                    t.apply(n, s)
                } catch (c) {
                    this.onError(c)
                }
            }
            var Re = !1,
                Ie = null,
                De = !1,
                Fe = null,
                Ue = {
                    onError: function (e) {
                        Re = !0, Ie = e
                    }
                };

            function Be(e, t, n, r, a, i, o, l, u) {
                Re = !1, Ie = null, Le.apply(Ue, arguments)
            }

            function Ve(e) {
                var t = e,
                    n = e;
                if (e.alternate)
                    for (; t.return;) t = t.return;
                else {
                    e = t;
                    do {
                        0 !== (4098 & (t = e).flags) && (n = t.return), e = t.return
                    } while (e)
                }
                return 3 === t.tag ? n : null
            }

            function He(e) {
                if (13 === e.tag) {
                    var t = e.memoizedState;
                    if (null === t && (null !== (e = e.alternate) && (t = e.memoizedState)), null !== t) return t.dehydrated
                }
                return null
            }

            function We(e) {
                if (Ve(e) !== e) throw Error(i(188))
            }

            function Qe(e) {
                return null !== (e = function (e) {
                    var t = e.alternate;
                    if (!t) {
                        if (null === (t = Ve(e))) throw Error(i(188));
                        return t !== e ? null : e
                    }
                    for (var n = e, r = t; ;) {
                        var a = n.return;
                        if (null === a) break;
                        var o = a.alternate;
                        if (null === o) {
                            if (null !== (r = a.return)) {
                                n = r;
                                continue
                            }
                            break
                        }
                        if (a.child === o.child) {
                            for (o = a.child; o;) {
                                if (o === n) return We(a), e;
                                if (o === r) return We(a), t;
                                o = o.sibling
                            }
                            throw Error(i(188))
                        }
                        if (n.return !== r.return) n = a, r = o;
                        else {
                            for (var l = !1, u = a.child; u;) {
                                if (u === n) {
                                    l = !0, n = a, r = o;
                                    break
                                }
                                if (u === r) {
                                    l = !0, r = a, n = o;
                                    break
                                }
                                u = u.sibling
                            }
                            if (!l) {
                                for (u = o.child; u;) {
                                    if (u === n) {
                                        l = !0, n = o, r = a;
                                        break
                                    }
                                    if (u === r) {
                                        l = !0, r = o, n = a;
                                        break
                                    }
                                    u = u.sibling
                                }
                                if (!l) throw Error(i(189))
                            }
                        }
                        if (n.alternate !== r) throw Error(i(190))
                    }
                    if (3 !== n.tag) throw Error(i(188));
                    return n.stateNode.current === n ? e : t
                }(e)) ? Ge(e) : null
            }

            function Ge(e) {
                if (5 === e.tag || 6 === e.tag) return e;
                for (e = e.child; null !== e;) {
                    var t = Ge(e);
                    if (null !== t) return t;
                    e = e.sibling
                }
                return null
            }
            var Xe = a.unstable_scheduleCallback,
                qe = a.unstable_cancelCallback,
                Ye = a.unstable_shouldYield,
                Ke = a.unstable_requestPaint,
                $e = a.unstable_now,
                Je = a.unstable_getCurrentPriorityLevel,
                Ze = a.unstable_ImmediatePriority,
                et = a.unstable_UserBlockingPriority,
                tt = a.unstable_NormalPriority,
                nt = a.unstable_LowPriority,
                rt = a.unstable_IdlePriority,
                at = null,
                it = null;
            var ot = Math.clz32 ? Math.clz32 : function (e) {
                return e >>>= 0, 0 === e ? 32 : 31 - (lt(e) / ut | 0) | 0
            },
                lt = Math.log,
                ut = Math.LN2;
            var st = 64,
                ct = 4194304;

            function dt(e) {
                switch (e & -e) {
                    case 1:
                        return 1;
                    case 2:
                        return 2;
                    case 4:
                        return 4;
                    case 8:
                        return 8;
                    case 16:
                        return 16;
                    case 32:
                        return 32;
                    case 64:
                    case 128:
                    case 256:
                    case 512:
                    case 1024:
                    case 2048:
                    case 4096:
                    case 8192:
                    case 16384:
                    case 32768:
                    case 65536:
                    case 131072:
                    case 262144:
                    case 524288:
                    case 1048576:
                    case 2097152:
                        return 4194240 & e;
                    case 4194304:
                    case 8388608:
                    case 16777216:
                    case 33554432:
                    case 67108864:
                        return 130023424 & e;
                    case 134217728:
                        return 134217728;
                    case 268435456:
                        return 268435456;
                    case 536870912:
                        return 536870912;
                    case 1073741824:
                        return 1073741824;
                    default:
                        return e
                }
            }

            function ft(e, t) {
                var n = e.pendingLanes;
                if (0 === n) return 0;
                var r = 0,
                    a = e.suspendedLanes,
                    i = e.pingedLanes,
                    o = 268435455 & n;
                if (0 !== o) {
                    var l = o & ~a;
                    0 !== l ? r = dt(l) : 0 !== (i &= o) && (r = dt(i))
                } else 0 !== (o = n & ~a) ? r = dt(o) : 0 !== i && (r = dt(i));
                if (0 === r) return 0;
                if (0 !== t && t !== r && 0 === (t & a) && ((a = r & -r) >= (i = t & -t) || 16 === a && 0 !== (4194240 & i))) return t;
                if (0 !== (4 & r) && (r |= 16 & n), 0 !== (t = e.entangledLanes))
                    for (e = e.entanglements, t &= r; 0 < t;) a = 1 << (n = 31 - ot(t)), r |= e[n], t &= ~a;
                return r
            }

            function pt(e, t) {
                switch (e) {
                    case 1:
                    case 2:
                    case 4:
                        return t + 250;
                    case 8:
                    case 16:
                    case 32:
                    case 64:
                    case 128:
                    case 256:
                    case 512:
                    case 1024:
                    case 2048:
                    case 4096:
                    case 8192:
                    case 16384:
                    case 32768:
                    case 65536:
                    case 131072:
                    case 262144:
                    case 524288:
                    case 1048576:
                    case 2097152:
                        return t + 5e3;
                    default:
                        return -1
                }
            }

            function ht(e) {
                return 0 !== (e = -1073741825 & e.pendingLanes) ? e : 1073741824 & e ? 1073741824 : 0
            }

            function mt() {
                var e = st;
                return 0 === (4194240 & (st <<= 1)) && (st = 64), e
            }

            function vt(e) {
                for (var t = [], n = 0; 31 > n; n++) t.push(e);
                return t
            }

            function gt(e, t, n) {
                e.pendingLanes |= t, 536870912 !== t && (e.suspendedLanes = 0, e.pingedLanes = 0), (e = e.eventTimes)[t = 31 - ot(t)] = n
            }

            function yt(e, t) {
                var n = e.entangledLanes |= t;
                for (e = e.entanglements; n;) {
                    var r = 31 - ot(n),
                        a = 1 << r;
                    a & t | e[r] & t && (e[r] |= t), n &= ~a
                }
            }
            var bt = 0;

            function wt(e) {
                return 1 < (e &= -e) ? 4 < e ? 0 !== (268435455 & e) ? 16 : 536870912 : 4 : 1
            }
            var xt, kt, St, _t, Et, Ct = !1,
                Nt = [],
                jt = null,
                Tt = null,
                Pt = null,
                zt = new Map,
                Mt = new Map,
                At = [],
                Ot = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

            function Lt(e, t) {
                switch (e) {
                    case "focusin":
                    case "focusout":
                        jt = null;
                        break;
                    case "dragenter":
                    case "dragleave":
                        Tt = null;
                        break;
                    case "mouseover":
                    case "mouseout":
                        Pt = null;
                        break;
                    case "pointerover":
                    case "pointerout":
                        zt.delete(t.pointerId);
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                        Mt.delete(t.pointerId)
                }
            }

            function Rt(e, t, n, r, a, i) {
                return null === e || e.nativeEvent !== i ? (e = {
                    blockedOn: t,
                    domEventName: n,
                    eventSystemFlags: r,
                    nativeEvent: i,
                    targetContainers: [a]
                }, null !== t && (null !== (t = ba(t)) && kt(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, null !== a && -1 === t.indexOf(a) && t.push(a), e)
            }

            function It(e) {
                var t = ya(e.target);
                if (null !== t) {
                    var n = Ve(t);
                    if (null !== n)
                        if (13 === (t = n.tag)) {
                            if (null !== (t = He(n))) return e.blockedOn = t, void Et(e.priority, (function () {
                                St(n)
                            }))
                        } else if (3 === t && n.stateNode.current.memoizedState.isDehydrated) return void (e.blockedOn = 3 === n.tag ? n.stateNode.containerInfo : null)
                }
                e.blockedOn = null
            }

            function Dt(e) {
                if (null !== e.blockedOn) return !1;
                for (var t = e.targetContainers; 0 < t.length;) {
                    var n = Yt(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
                    if (null !== n) return null !== (t = ba(n)) && kt(t), e.blockedOn = n, !1;
                    var r = new (n = e.nativeEvent).constructor(n.type, n);
                    we = r, n.target.dispatchEvent(r), we = null, t.shift()
                }
                return !0
            }

            function Ft(e, t, n) {
                Dt(e) && n.delete(t)
            }

            function Ut() {
                Ct = !1, null !== jt && Dt(jt) && (jt = null), null !== Tt && Dt(Tt) && (Tt = null), null !== Pt && Dt(Pt) && (Pt = null), zt.forEach(Ft), Mt.forEach(Ft)
            }

            function Bt(e, t) {
                e.blockedOn === t && (e.blockedOn = null, Ct || (Ct = !0, a.unstable_scheduleCallback(a.unstable_NormalPriority, Ut)))
            }

            function Vt(e) {
                function t(t) {
                    return Bt(t, e)
                }
                if (0 < Nt.length) {
                    Bt(Nt[0], e);
                    for (var n = 1; n < Nt.length; n++) {
                        var r = Nt[n];
                        r.blockedOn === e && (r.blockedOn = null)
                    }
                }
                for (null !== jt && Bt(jt, e), null !== Tt && Bt(Tt, e), null !== Pt && Bt(Pt, e), zt.forEach(t), Mt.forEach(t), n = 0; n < At.length; n++)(r = At[n]).blockedOn === e && (r.blockedOn = null);
                for (; 0 < At.length && null === (n = At[0]).blockedOn;) It(n), null === n.blockedOn && At.shift()
            }
            var Ht = w.ReactCurrentBatchConfig,
                Wt = !0;

            function Qt(e, t, n, r) {
                var a = bt,
                    i = Ht.transition;
                Ht.transition = null;
                try {
                    bt = 1, Xt(e, t, n, r)
                } finally {
                    bt = a, Ht.transition = i
                }
            }

            function Gt(e, t, n, r) {
                var a = bt,
                    i = Ht.transition;
                Ht.transition = null;
                try {
                    bt = 4, Xt(e, t, n, r)
                } finally {
                    bt = a, Ht.transition = i
                }
            }

            function Xt(e, t, n, r) {
                if (Wt) {
                    var a = Yt(e, t, n, r);
                    if (null === a) Wr(e, t, r, qt, n), Lt(e, r);
                    else if (function (e, t, n, r, a) {
                        switch (t) {
                            case "focusin":
                                return jt = Rt(jt, e, t, n, r, a), !0;
                            case "dragenter":
                                return Tt = Rt(Tt, e, t, n, r, a), !0;
                            case "mouseover":
                                return Pt = Rt(Pt, e, t, n, r, a), !0;
                            case "pointerover":
                                var i = a.pointerId;
                                return zt.set(i, Rt(zt.get(i) || null, e, t, n, r, a)), !0;
                            case "gotpointercapture":
                                return i = a.pointerId, Mt.set(i, Rt(Mt.get(i) || null, e, t, n, r, a)), !0
                        }
                        return !1
                    }(a, e, t, n, r)) r.stopPropagation();
                    else if (Lt(e, r), 4 & t && -1 < Ot.indexOf(e)) {
                        for (; null !== a;) {
                            var i = ba(a);
                            if (null !== i && xt(i), null === (i = Yt(e, t, n, r)) && Wr(e, t, r, qt, n), i === a) break;
                            a = i
                        }
                        null !== a && r.stopPropagation()
                    } else Wr(e, t, r, null, n)
                }
            }
            var qt = null;

            function Yt(e, t, n, r) {
                if (qt = null, null !== (e = ya(e = xe(r))))
                    if (null === (t = Ve(e))) e = null;
                    else if (13 === (n = t.tag)) {
                        if (null !== (e = He(t))) return e;
                        e = null
                    } else if (3 === n) {
                        if (t.stateNode.current.memoizedState.isDehydrated) return 3 === t.tag ? t.stateNode.containerInfo : null;
                        e = null
                    } else t !== e && (e = null);
                return qt = e, null
            }

            function Kt(e) {
                switch (e) {
                    case "cancel":
                    case "click":
                    case "close":
                    case "contextmenu":
                    case "copy":
                    case "cut":
                    case "auxclick":
                    case "dblclick":
                    case "dragend":
                    case "dragstart":
                    case "drop":
                    case "focusin":
                    case "focusout":
                    case "input":
                    case "invalid":
                    case "keydown":
                    case "keypress":
                    case "keyup":
                    case "mousedown":
                    case "mouseup":
                    case "paste":
                    case "pause":
                    case "play":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointerup":
                    case "ratechange":
                    case "reset":
                    case "resize":
                    case "seeked":
                    case "submit":
                    case "touchcancel":
                    case "touchend":
                    case "touchstart":
                    case "volumechange":
                    case "change":
                    case "selectionchange":
                    case "textInput":
                    case "compositionstart":
                    case "compositionend":
                    case "compositionupdate":
                    case "beforeblur":
                    case "afterblur":
                    case "beforeinput":
                    case "blur":
                    case "fullscreenchange":
                    case "focus":
                    case "hashchange":
                    case "popstate":
                    case "select":
                    case "selectstart":
                        return 1;
                    case "drag":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "mousemove":
                    case "mouseout":
                    case "mouseover":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "scroll":
                    case "toggle":
                    case "touchmove":
                    case "wheel":
                    case "mouseenter":
                    case "mouseleave":
                    case "pointerenter":
                    case "pointerleave":
                        return 4;
                    case "message":
                        switch (Je()) {
                            case Ze:
                                return 1;
                            case et:
                                return 4;
                            case tt:
                            case nt:
                                return 16;
                            case rt:
                                return 536870912;
                            default:
                                return 16
                        }
                    default:
                        return 16
                }
            }
            var $t = null,
                Jt = null,
                Zt = null;

            function en() {
                if (Zt) return Zt;
                var e, t, n = Jt,
                    r = n.length,
                    a = "value" in $t ? $t.value : $t.textContent,
                    i = a.length;
                for (e = 0; e < r && n[e] === a[e]; e++);
                var o = r - e;
                for (t = 1; t <= o && n[r - t] === a[i - t]; t++);
                return Zt = a.slice(e, 1 < t ? 1 - t : void 0)
            }

            function tn(e) {
                var t = e.keyCode;
                return "charCode" in e ? 0 === (e = e.charCode) && 13 === t && (e = 13) : e = t, 10 === e && (e = 13), 32 <= e || 13 === e ? e : 0
            }

            function nn() {
                return !0
            }

            function rn() {
                return !1
            }

            function an(e) {
                function t(t, n, r, a, i) {
                    for (var o in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = a, this.target = i, this.currentTarget = null, e) e.hasOwnProperty(o) && (t = e[o], this[o] = t ? t(a) : a[o]);
                    return this.isDefaultPrevented = (null != a.defaultPrevented ? a.defaultPrevented : !1 === a.returnValue) ? nn : rn, this.isPropagationStopped = rn, this
                }
                return I(t.prototype, {
                    preventDefault: function () {
                        this.defaultPrevented = !0;
                        var e = this.nativeEvent;
                        e && (e.preventDefault ? e.preventDefault() : "unknown" !== typeof e.returnValue && (e.returnValue = !1), this.isDefaultPrevented = nn)
                    },
                    stopPropagation: function () {
                        var e = this.nativeEvent;
                        e && (e.stopPropagation ? e.stopPropagation() : "unknown" !== typeof e.cancelBubble && (e.cancelBubble = !0), this.isPropagationStopped = nn)
                    },
                    persist: function () { },
                    isPersistent: nn
                }), t
            }
            var on, ln, un, sn = {
                eventPhase: 0,
                bubbles: 0,
                cancelable: 0,
                timeStamp: function (e) {
                    return e.timeStamp || Date.now()
                },
                defaultPrevented: 0,
                isTrusted: 0
            },
                cn = an(sn),
                dn = I({}, sn, {
                    view: 0,
                    detail: 0
                }),
                fn = an(dn),
                pn = I({}, dn, {
                    screenX: 0,
                    screenY: 0,
                    clientX: 0,
                    clientY: 0,
                    pageX: 0,
                    pageY: 0,
                    ctrlKey: 0,
                    shiftKey: 0,
                    altKey: 0,
                    metaKey: 0,
                    getModifierState: En,
                    button: 0,
                    buttons: 0,
                    relatedTarget: function (e) {
                        return void 0 === e.relatedTarget ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
                    },
                    movementX: function (e) {
                        return "movementX" in e ? e.movementX : (e !== un && (un && "mousemove" === e.type ? (on = e.screenX - un.screenX, ln = e.screenY - un.screenY) : ln = on = 0, un = e), on)
                    },
                    movementY: function (e) {
                        return "movementY" in e ? e.movementY : ln
                    }
                }),
                hn = an(pn),
                mn = an(I({}, pn, {
                    dataTransfer: 0
                })),
                vn = an(I({}, dn, {
                    relatedTarget: 0
                })),
                gn = an(I({}, sn, {
                    animationName: 0,
                    elapsedTime: 0,
                    pseudoElement: 0
                })),
                yn = I({}, sn, {
                    clipboardData: function (e) {
                        return "clipboardData" in e ? e.clipboardData : window.clipboardData
                    }
                }),
                bn = an(yn),
                wn = an(I({}, sn, {
                    data: 0
                })),
                xn = {
                    Esc: "Escape",
                    Spacebar: " ",
                    Left: "ArrowLeft",
                    Up: "ArrowUp",
                    Right: "ArrowRight",
                    Down: "ArrowDown",
                    Del: "Delete",
                    Win: "OS",
                    Menu: "ContextMenu",
                    Apps: "ContextMenu",
                    Scroll: "ScrollLock",
                    MozPrintableKey: "Unidentified"
                },
                kn = {
                    8: "Backspace",
                    9: "Tab",
                    12: "Clear",
                    13: "Enter",
                    16: "Shift",
                    17: "Control",
                    18: "Alt",
                    19: "Pause",
                    20: "CapsLock",
                    27: "Escape",
                    32: " ",
                    33: "PageUp",
                    34: "PageDown",
                    35: "End",
                    36: "Home",
                    37: "ArrowLeft",
                    38: "ArrowUp",
                    39: "ArrowRight",
                    40: "ArrowDown",
                    45: "Insert",
                    46: "Delete",
                    112: "F1",
                    113: "F2",
                    114: "F3",
                    115: "F4",
                    116: "F5",
                    117: "F6",
                    118: "F7",
                    119: "F8",
                    120: "F9",
                    121: "F10",
                    122: "F11",
                    123: "F12",
                    144: "NumLock",
                    145: "ScrollLock",
                    224: "Meta"
                },
                Sn = {
                    Alt: "altKey",
                    Control: "ctrlKey",
                    Meta: "metaKey",
                    Shift: "shiftKey"
                };

            function _n(e) {
                var t = this.nativeEvent;
                return t.getModifierState ? t.getModifierState(e) : !!(e = Sn[e]) && !!t[e]
            }

            function En() {
                return _n
            }
            var Cn = I({}, dn, {
                key: function (e) {
                    if (e.key) {
                        var t = xn[e.key] || e.key;
                        if ("Unidentified" !== t) return t
                    }
                    return "keypress" === e.type ? 13 === (e = tn(e)) ? "Enter" : String.fromCharCode(e) : "keydown" === e.type || "keyup" === e.type ? kn[e.keyCode] || "Unidentified" : ""
                },
                code: 0,
                location: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                repeat: 0,
                locale: 0,
                getModifierState: En,
                charCode: function (e) {
                    return "keypress" === e.type ? tn(e) : 0
                },
                keyCode: function (e) {
                    return "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
                },
                which: function (e) {
                    return "keypress" === e.type ? tn(e) : "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
                }
            }),
                Nn = an(Cn),
                jn = an(I({}, pn, {
                    pointerId: 0,
                    width: 0,
                    height: 0,
                    pressure: 0,
                    tangentialPressure: 0,
                    tiltX: 0,
                    tiltY: 0,
                    twist: 0,
                    pointerType: 0,
                    isPrimary: 0
                })),
                Tn = an(I({}, dn, {
                    touches: 0,
                    targetTouches: 0,
                    changedTouches: 0,
                    altKey: 0,
                    metaKey: 0,
                    ctrlKey: 0,
                    shiftKey: 0,
                    getModifierState: En
                })),
                Pn = an(I({}, sn, {
                    propertyName: 0,
                    elapsedTime: 0,
                    pseudoElement: 0
                })),
                zn = I({}, pn, {
                    deltaX: function (e) {
                        return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
                    },
                    deltaY: function (e) {
                        return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
                    },
                    deltaZ: 0,
                    deltaMode: 0
                }),
                Mn = an(zn),
                An = [9, 13, 27, 32],
                On = c && "CompositionEvent" in window,
                Ln = null;
            c && "documentMode" in document && (Ln = document.documentMode);
            var Rn = c && "TextEvent" in window && !Ln,
                In = c && (!On || Ln && 8 < Ln && 11 >= Ln),
                Dn = String.fromCharCode(32),
                Fn = !1;

            function Un(e, t) {
                switch (e) {
                    case "keyup":
                        return -1 !== An.indexOf(t.keyCode);
                    case "keydown":
                        return 229 !== t.keyCode;
                    case "keypress":
                    case "mousedown":
                    case "focusout":
                        return !0;
                    default:
                        return !1
                }
            }

            function Bn(e) {
                return "object" === typeof (e = e.detail) && "data" in e ? e.data : null
            }
            var Vn = !1;
            var Hn = {
                color: !0,
                date: !0,
                datetime: !0,
                "datetime-local": !0,
                email: !0,
                month: !0,
                number: !0,
                password: !0,
                range: !0,
                search: !0,
                tel: !0,
                text: !0,
                time: !0,
                url: !0,
                week: !0
            };

            function Wn(e) {
                var t = e && e.nodeName && e.nodeName.toLowerCase();
                return "input" === t ? !!Hn[e.type] : "textarea" === t
            }

            function Qn(e, t, n, r) {
                Ce(r), 0 < (t = Gr(t, "onChange")).length && (n = new cn("onChange", "change", null, n, r), e.push({
                    event: n,
                    listeners: t
                }))
            }
            var Gn = null,
                Xn = null;

            function qn(e) {
                Dr(e, 0)
            }

            function Yn(e) {
                if (X(wa(e))) return e
            }

            function Kn(e, t) {
                if ("change" === e) return t
            }
            var $n = !1;
            if (c) {
                var Jn;
                if (c) {
                    var Zn = "oninput" in document;
                    if (!Zn) {
                        var er = document.createElement("div");
                        er.setAttribute("oninput", "return;"), Zn = "function" === typeof er.oninput
                    }
                    Jn = Zn
                } else Jn = !1;
                $n = Jn && (!document.documentMode || 9 < document.documentMode)
            }

            function tr() {
                Gn && (Gn.detachEvent("onpropertychange", nr), Xn = Gn = null)
            }

            function nr(e) {
                if ("value" === e.propertyName && Yn(Xn)) {
                    var t = [];
                    Qn(t, Xn, e, xe(e)), ze(qn, t)
                }
            }

            function rr(e, t, n) {
                "focusin" === e ? (tr(), Xn = n, (Gn = t).attachEvent("onpropertychange", nr)) : "focusout" === e && tr()
            }

            function ar(e) {
                if ("selectionchange" === e || "keyup" === e || "keydown" === e) return Yn(Xn)
            }

            function ir(e, t) {
                if ("click" === e) return Yn(t)
            }

            function or(e, t) {
                if ("input" === e || "change" === e) return Yn(t)
            }
            var lr = "function" === typeof Object.is ? Object.is : function (e, t) {
                return e === t && (0 !== e || 1 / e === 1 / t) || e !== e && t !== t
            };

            function ur(e, t) {
                if (lr(e, t)) return !0;
                if ("object" !== typeof e || null === e || "object" !== typeof t || null === t) return !1;
                var n = Object.keys(e),
                    r = Object.keys(t);
                if (n.length !== r.length) return !1;
                for (r = 0; r < n.length; r++) {
                    var a = n[r];
                    if (!d.call(t, a) || !lr(e[a], t[a])) return !1
                }
                return !0
            }

            function sr(e) {
                for (; e && e.firstChild;) e = e.firstChild;
                return e
            }

            function cr(e, t) {
                var n, r = sr(e);
                for (e = 0; r;) {
                    if (3 === r.nodeType) {
                        if (n = e + r.textContent.length, e <= t && n >= t) return {
                            node: r,
                            offset: t - e
                        };
                        e = n
                    }
                    e: {
                        for (; r;) {
                            if (r.nextSibling) {
                                r = r.nextSibling;
                                break e
                            }
                            r = r.parentNode
                        }
                        r = void 0
                    }
                    r = sr(r)
                }
            }

            function dr(e, t) {
                return !(!e || !t) && (e === t || (!e || 3 !== e.nodeType) && (t && 3 === t.nodeType ? dr(e, t.parentNode) : "contains" in e ? e.contains(t) : !!e.compareDocumentPosition && !!(16 & e.compareDocumentPosition(t))))
            }

            function fr() {
                for (var e = window, t = q(); t instanceof e.HTMLIFrameElement;) {
                    try {
                        var n = "string" === typeof t.contentWindow.location.href
                    } catch (r) {
                        n = !1
                    }
                    if (!n) break;
                    t = q((e = t.contentWindow).document)
                }
                return t
            }

            function pr(e) {
                var t = e && e.nodeName && e.nodeName.toLowerCase();
                return t && ("input" === t && ("text" === e.type || "search" === e.type || "tel" === e.type || "url" === e.type || "password" === e.type) || "textarea" === t || "true" === e.contentEditable)
            }

            function hr(e) {
                var t = fr(),
                    n = e.focusedElem,
                    r = e.selectionRange;
                if (t !== n && n && n.ownerDocument && dr(n.ownerDocument.documentElement, n)) {
                    if (null !== r && pr(n))
                        if (t = r.start, void 0 === (e = r.end) && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
                        else if ((e = (t = n.ownerDocument || document) && t.defaultView || window).getSelection) {
                            e = e.getSelection();
                            var a = n.textContent.length,
                                i = Math.min(r.start, a);
                            r = void 0 === r.end ? i : Math.min(r.end, a), !e.extend && i > r && (a = r, r = i, i = a), a = cr(n, i);
                            var o = cr(n, r);
                            a && o && (1 !== e.rangeCount || e.anchorNode !== a.node || e.anchorOffset !== a.offset || e.focusNode !== o.node || e.focusOffset !== o.offset) && ((t = t.createRange()).setStart(a.node, a.offset), e.removeAllRanges(), i > r ? (e.addRange(t), e.extend(o.node, o.offset)) : (t.setEnd(o.node, o.offset), e.addRange(t)))
                        }
                    for (t = [], e = n; e = e.parentNode;) 1 === e.nodeType && t.push({
                        element: e,
                        left: e.scrollLeft,
                        top: e.scrollTop
                    });
                    for ("function" === typeof n.focus && n.focus(), n = 0; n < t.length; n++)(e = t[n]).element.scrollLeft = e.left, e.element.scrollTop = e.top
                }
            }
            var mr = c && "documentMode" in document && 11 >= document.documentMode,
                vr = null,
                gr = null,
                yr = null,
                br = !1;

            function wr(e, t, n) {
                var r = n.window === n ? n.document : 9 === n.nodeType ? n : n.ownerDocument;
                br || null == vr || vr !== q(r) || ("selectionStart" in (r = vr) && pr(r) ? r = {
                    start: r.selectionStart,
                    end: r.selectionEnd
                } : r = {
                    anchorNode: (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection()).anchorNode,
                    anchorOffset: r.anchorOffset,
                    focusNode: r.focusNode,
                    focusOffset: r.focusOffset
                }, yr && ur(yr, r) || (yr = r, 0 < (r = Gr(gr, "onSelect")).length && (t = new cn("onSelect", "select", null, t, n), e.push({
                    event: t,
                    listeners: r
                }), t.target = vr)))
            }

            function xr(e, t) {
                var n = {};
                return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
            }
            var kr = {
                animationend: xr("Animation", "AnimationEnd"),
                animationiteration: xr("Animation", "AnimationIteration"),
                animationstart: xr("Animation", "AnimationStart"),
                transitionend: xr("Transition", "TransitionEnd")
            },
                Sr = {},
                _r = {};

            function Er(e) {
                if (Sr[e]) return Sr[e];
                if (!kr[e]) return e;
                var t, n = kr[e];
                for (t in n)
                    if (n.hasOwnProperty(t) && t in _r) return Sr[e] = n[t];
                return e
            }
            c && (_r = document.createElement("div").style, "AnimationEvent" in window || (delete kr.animationend.animation, delete kr.animationiteration.animation, delete kr.animationstart.animation), "TransitionEvent" in window || delete kr.transitionend.transition);
            var Cr = Er("animationend"),
                Nr = Er("animationiteration"),
                jr = Er("animationstart"),
                Tr = Er("transitionend"),
                Pr = new Map,
                zr = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

            function Mr(e, t) {
                Pr.set(e, t), u(t, [e])
            }
            for (var Ar = 0; Ar < zr.length; Ar++) {
                var Or = zr[Ar];
                Mr(Or.toLowerCase(), "on" + (Or[0].toUpperCase() + Or.slice(1)))
            }
            Mr(Cr, "onAnimationEnd"), Mr(Nr, "onAnimationIteration"), Mr(jr, "onAnimationStart"), Mr("dblclick", "onDoubleClick"), Mr("focusin", "onFocus"), Mr("focusout", "onBlur"), Mr(Tr, "onTransitionEnd"), s("onMouseEnter", ["mouseout", "mouseover"]), s("onMouseLeave", ["mouseout", "mouseover"]), s("onPointerEnter", ["pointerout", "pointerover"]), s("onPointerLeave", ["pointerout", "pointerover"]), u("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), u("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), u("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), u("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), u("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), u("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
            var Lr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
                Rr = new Set("cancel close invalid load scroll toggle".split(" ").concat(Lr));

            function Ir(e, t, n) {
                var r = e.type || "unknown-event";
                e.currentTarget = n,
                    function (e, t, n, r, a, o, l, u, s) {
                        if (Be.apply(this, arguments), Re) {
                            if (!Re) throw Error(i(198));
                            var c = Ie;
                            Re = !1, Ie = null, De || (De = !0, Fe = c)
                        }
                    }(r, t, void 0, e), e.currentTarget = null
            }

            function Dr(e, t) {
                t = 0 !== (4 & t);
                for (var n = 0; n < e.length; n++) {
                    var r = e[n],
                        a = r.event;
                    r = r.listeners;
                    e: {
                        var i = void 0;
                        if (t)
                            for (var o = r.length - 1; 0 <= o; o--) {
                                var l = r[o],
                                    u = l.instance,
                                    s = l.currentTarget;
                                if (l = l.listener, u !== i && a.isPropagationStopped()) break e;
                                Ir(a, l, s), i = u
                            } else
                            for (o = 0; o < r.length; o++) {
                                if (u = (l = r[o]).instance, s = l.currentTarget, l = l.listener, u !== i && a.isPropagationStopped()) break e;
                                Ir(a, l, s), i = u
                            }
                    }
                }
                if (De) throw e = Fe, De = !1, Fe = null, e
            }

            function Fr(e, t) {
                var n = t[ma];
                void 0 === n && (n = t[ma] = new Set);
                var r = e + "__bubble";
                n.has(r) || (Hr(t, e, 2, !1), n.add(r))
            }

            function Ur(e, t, n) {
                var r = 0;
                t && (r |= 4), Hr(n, e, r, t)
            }
            var Br = "_reactListening" + Math.random().toString(36).slice(2);

            function Vr(e) {
                if (!e[Br]) {
                    e[Br] = !0, o.forEach((function (t) {
                        "selectionchange" !== t && (Rr.has(t) || Ur(t, !1, e), Ur(t, !0, e))
                    }));
                    var t = 9 === e.nodeType ? e : e.ownerDocument;
                    null === t || t[Br] || (t[Br] = !0, Ur("selectionchange", !1, t))
                }
            }

            function Hr(e, t, n, r) {
                switch (Kt(t)) {
                    case 1:
                        var a = Qt;
                        break;
                    case 4:
                        a = Gt;
                        break;
                    default:
                        a = Xt
                }
                n = a.bind(null, t, n, e), a = void 0, !Ae || "touchstart" !== t && "touchmove" !== t && "wheel" !== t || (a = !0), r ? void 0 !== a ? e.addEventListener(t, n, {
                    capture: !0,
                    passive: a
                }) : e.addEventListener(t, n, !0) : void 0 !== a ? e.addEventListener(t, n, {
                    passive: a
                }) : e.addEventListener(t, n, !1)
            }

            function Wr(e, t, n, r, a) {
                var i = r;
                if (0 === (1 & t) && 0 === (2 & t) && null !== r) e: for (; ;) {
                    if (null === r) return;
                    var o = r.tag;
                    if (3 === o || 4 === o) {
                        var l = r.stateNode.containerInfo;
                        if (l === a || 8 === l.nodeType && l.parentNode === a) break;
                        if (4 === o)
                            for (o = r.return; null !== o;) {
                                var u = o.tag;
                                if ((3 === u || 4 === u) && ((u = o.stateNode.containerInfo) === a || 8 === u.nodeType && u.parentNode === a)) return;
                                o = o.return
                            }
                        for (; null !== l;) {
                            if (null === (o = ya(l))) return;
                            if (5 === (u = o.tag) || 6 === u) {
                                r = i = o;
                                continue e
                            }
                            l = l.parentNode
                        }
                    }
                    r = r.return
                }
                ze((function () {
                    var r = i,
                        a = xe(n),
                        o = [];
                    e: {
                        var l = Pr.get(e);
                        if (void 0 !== l) {
                            var u = cn,
                                s = e;
                            switch (e) {
                                case "keypress":
                                    if (0 === tn(n)) break e;
                                case "keydown":
                                case "keyup":
                                    u = Nn;
                                    break;
                                case "focusin":
                                    s = "focus", u = vn;
                                    break;
                                case "focusout":
                                    s = "blur", u = vn;
                                    break;
                                case "beforeblur":
                                case "afterblur":
                                    u = vn;
                                    break;
                                case "click":
                                    if (2 === n.button) break e;
                                case "auxclick":
                                case "dblclick":
                                case "mousedown":
                                case "mousemove":
                                case "mouseup":
                                case "mouseout":
                                case "mouseover":
                                case "contextmenu":
                                    u = hn;
                                    break;
                                case "drag":
                                case "dragend":
                                case "dragenter":
                                case "dragexit":
                                case "dragleave":
                                case "dragover":
                                case "dragstart":
                                case "drop":
                                    u = mn;
                                    break;
                                case "touchcancel":
                                case "touchend":
                                case "touchmove":
                                case "touchstart":
                                    u = Tn;
                                    break;
                                case Cr:
                                case Nr:
                                case jr:
                                    u = gn;
                                    break;
                                case Tr:
                                    u = Pn;
                                    break;
                                case "scroll":
                                    u = fn;
                                    break;
                                case "wheel":
                                    u = Mn;
                                    break;
                                case "copy":
                                case "cut":
                                case "paste":
                                    u = bn;
                                    break;
                                case "gotpointercapture":
                                case "lostpointercapture":
                                case "pointercancel":
                                case "pointerdown":
                                case "pointermove":
                                case "pointerout":
                                case "pointerover":
                                case "pointerup":
                                    u = jn
                            }
                            var c = 0 !== (4 & t),
                                d = !c && "scroll" === e,
                                f = c ? null !== l ? l + "Capture" : null : l;
                            c = [];
                            for (var p, h = r; null !== h;) {
                                var m = (p = h).stateNode;
                                if (5 === p.tag && null !== m && (p = m, null !== f && (null != (m = Me(h, f)) && c.push(Qr(h, m, p)))), d) break;
                                h = h.return
                            }
                            0 < c.length && (l = new u(l, s, null, n, a), o.push({
                                event: l,
                                listeners: c
                            }))
                        }
                    }
                    if (0 === (7 & t)) {
                        if (u = "mouseout" === e || "pointerout" === e, (!(l = "mouseover" === e || "pointerover" === e) || n === we || !(s = n.relatedTarget || n.fromElement) || !ya(s) && !s[ha]) && (u || l) && (l = a.window === a ? a : (l = a.ownerDocument) ? l.defaultView || l.parentWindow : window, u ? (u = r, null !== (s = (s = n.relatedTarget || n.toElement) ? ya(s) : null) && (s !== (d = Ve(s)) || 5 !== s.tag && 6 !== s.tag) && (s = null)) : (u = null, s = r), u !== s)) {
                            if (c = hn, m = "onMouseLeave", f = "onMouseEnter", h = "mouse", "pointerout" !== e && "pointerover" !== e || (c = jn, m = "onPointerLeave", f = "onPointerEnter", h = "pointer"), d = null == u ? l : wa(u), p = null == s ? l : wa(s), (l = new c(m, h + "leave", u, n, a)).target = d, l.relatedTarget = p, m = null, ya(a) === r && ((c = new c(f, h + "enter", s, n, a)).target = p, c.relatedTarget = d, m = c), d = m, u && s) e: {
                                for (f = s, h = 0, p = c = u; p; p = Xr(p)) h++;
                                for (p = 0, m = f; m; m = Xr(m)) p++;
                                for (; 0 < h - p;) c = Xr(c),
                                    h--;
                                for (; 0 < p - h;) f = Xr(f),
                                    p--;
                                for (; h--;) {
                                    if (c === f || null !== f && c === f.alternate) break e;
                                    c = Xr(c), f = Xr(f)
                                }
                                c = null
                            }
                            else c = null;
                            null !== u && qr(o, l, u, c, !1), null !== s && null !== d && qr(o, d, s, c, !0)
                        }
                        if ("select" === (u = (l = r ? wa(r) : window).nodeName && l.nodeName.toLowerCase()) || "input" === u && "file" === l.type) var v = Kn;
                        else if (Wn(l))
                            if ($n) v = or;
                            else {
                                v = ar;
                                var g = rr
                            }
                        else (u = l.nodeName) && "input" === u.toLowerCase() && ("checkbox" === l.type || "radio" === l.type) && (v = ir);
                        switch (v && (v = v(e, r)) ? Qn(o, v, n, a) : (g && g(e, l, r), "focusout" === e && (g = l._wrapperState) && g.controlled && "number" === l.type && ee(l, "number", l.value)), g = r ? wa(r) : window, e) {
                            case "focusin":
                                (Wn(g) || "true" === g.contentEditable) && (vr = g, gr = r, yr = null);
                                break;
                            case "focusout":
                                yr = gr = vr = null;
                                break;
                            case "mousedown":
                                br = !0;
                                break;
                            case "contextmenu":
                            case "mouseup":
                            case "dragend":
                                br = !1, wr(o, n, a);
                                break;
                            case "selectionchange":
                                if (mr) break;
                            case "keydown":
                            case "keyup":
                                wr(o, n, a)
                        }
                        var y;
                        if (On) e: {
                            switch (e) {
                                case "compositionstart":
                                    var b = "onCompositionStart";
                                    break e;
                                case "compositionend":
                                    b = "onCompositionEnd";
                                    break e;
                                case "compositionupdate":
                                    b = "onCompositionUpdate";
                                    break e
                            }
                            b = void 0
                        }
                        else Vn ? Un(e, n) && (b = "onCompositionEnd") : "keydown" === e && 229 === n.keyCode && (b = "onCompositionStart");
                        b && (In && "ko" !== n.locale && (Vn || "onCompositionStart" !== b ? "onCompositionEnd" === b && Vn && (y = en()) : (Jt = "value" in ($t = a) ? $t.value : $t.textContent, Vn = !0)), 0 < (g = Gr(r, b)).length && (b = new wn(b, e, null, n, a), o.push({
                            event: b,
                            listeners: g
                        }), y ? b.data = y : null !== (y = Bn(n)) && (b.data = y))), (y = Rn ? function (e, t) {
                            switch (e) {
                                case "compositionend":
                                    return Bn(t);
                                case "keypress":
                                    return 32 !== t.which ? null : (Fn = !0, Dn);
                                case "textInput":
                                    return (e = t.data) === Dn && Fn ? null : e;
                                default:
                                    return null
                            }
                        }(e, n) : function (e, t) {
                            if (Vn) return "compositionend" === e || !On && Un(e, t) ? (e = en(), Zt = Jt = $t = null, Vn = !1, e) : null;
                            switch (e) {
                                case "paste":
                                default:
                                    return null;
                                case "keypress":
                                    if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                                        if (t.char && 1 < t.char.length) return t.char;
                                        if (t.which) return String.fromCharCode(t.which)
                                    }
                                    return null;
                                case "compositionend":
                                    return In && "ko" !== t.locale ? null : t.data
                            }
                        }(e, n)) && (0 < (r = Gr(r, "onBeforeInput")).length && (a = new wn("onBeforeInput", "beforeinput", null, n, a), o.push({
                            event: a,
                            listeners: r
                        }), a.data = y))
                    }
                    Dr(o, t)
                }))
            }

            function Qr(e, t, n) {
                return {
                    instance: e,
                    listener: t,
                    currentTarget: n
                }
            }

            function Gr(e, t) {
                for (var n = t + "Capture", r = []; null !== e;) {
                    var a = e,
                        i = a.stateNode;
                    5 === a.tag && null !== i && (a = i, null != (i = Me(e, n)) && r.unshift(Qr(e, i, a)), null != (i = Me(e, t)) && r.push(Qr(e, i, a))), e = e.return
                }
                return r
            }

            function Xr(e) {
                if (null === e) return null;
                do {
                    e = e.return
                } while (e && 5 !== e.tag);
                return e || null
            }

            function qr(e, t, n, r, a) {
                for (var i = t._reactName, o = []; null !== n && n !== r;) {
                    var l = n,
                        u = l.alternate,
                        s = l.stateNode;
                    if (null !== u && u === r) break;
                    5 === l.tag && null !== s && (l = s, a ? null != (u = Me(n, i)) && o.unshift(Qr(n, u, l)) : a || null != (u = Me(n, i)) && o.push(Qr(n, u, l))), n = n.return
                }
                0 !== o.length && e.push({
                    event: t,
                    listeners: o
                })
            }
            var Yr = /\r\n?/g,
                Kr = /\u0000|\uFFFD/g;

            function $r(e) {
                return ("string" === typeof e ? e : "" + e).replace(Yr, "\n").replace(Kr, "")
            }

            function Jr(e, t, n) {
                if (t = $r(t), $r(e) !== t && n) throw Error(i(425))
            }

            function Zr() { }
            var ea = null,
                ta = null;

            function na(e, t) {
                return "textarea" === e || "noscript" === e || "string" === typeof t.children || "number" === typeof t.children || "object" === typeof t.dangerouslySetInnerHTML && null !== t.dangerouslySetInnerHTML && null != t.dangerouslySetInnerHTML.__html
            }
            var ra = "function" === typeof setTimeout ? setTimeout : void 0,
                aa = "function" === typeof clearTimeout ? clearTimeout : void 0,
                ia = "function" === typeof Promise ? Promise : void 0,
                oa = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof ia ? function (e) {
                    return ia.resolve(null).then(e).catch(la)
                } : ra;

            function la(e) {
                setTimeout((function () {
                    throw e
                }))
            }

            function ua(e, t) {
                var n = t,
                    r = 0;
                do {
                    var a = n.nextSibling;
                    if (e.removeChild(n), a && 8 === a.nodeType)
                        if ("/$" === (n = a.data)) {
                            if (0 === r) return e.removeChild(a), void Vt(t);
                            r--
                        } else "$" !== n && "$?" !== n && "$!" !== n || r++;
                    n = a
                } while (n);
                Vt(t)
            }

            function sa(e) {
                for (; null != e; e = e.nextSibling) {
                    var t = e.nodeType;
                    if (1 === t || 3 === t) break;
                    if (8 === t) {
                        if ("$" === (t = e.data) || "$!" === t || "$?" === t) break;
                        if ("/$" === t) return null
                    }
                }
                return e
            }

            function ca(e) {
                e = e.previousSibling;
                for (var t = 0; e;) {
                    if (8 === e.nodeType) {
                        var n = e.data;
                        if ("$" === n || "$!" === n || "$?" === n) {
                            if (0 === t) return e;
                            t--
                        } else "/$" === n && t++
                    }
                    e = e.previousSibling
                }
                return null
            }
            var da = Math.random().toString(36).slice(2),
                fa = "__reactFiber$" + da,
                pa = "__reactProps$" + da,
                ha = "__reactContainer$" + da,
                ma = "__reactEvents$" + da,
                va = "__reactListeners$" + da,
                ga = "__reactHandles$" + da;

            function ya(e) {
                var t = e[fa];
                if (t) return t;
                for (var n = e.parentNode; n;) {
                    if (t = n[ha] || n[fa]) {
                        if (n = t.alternate, null !== t.child || null !== n && null !== n.child)
                            for (e = ca(e); null !== e;) {
                                if (n = e[fa]) return n;
                                e = ca(e)
                            }
                        return t
                    }
                    n = (e = n).parentNode
                }
                return null
            }

            function ba(e) {
                return !(e = e[fa] || e[ha]) || 5 !== e.tag && 6 !== e.tag && 13 !== e.tag && 3 !== e.tag ? null : e
            }

            function wa(e) {
                if (5 === e.tag || 6 === e.tag) return e.stateNode;
                throw Error(i(33))
            }

            function xa(e) {
                return e[pa] || null
            }
            var ka = [],
                Sa = -1;

            function _a(e) {
                return {
                    current: e
                }
            }

            function Ea(e) {
                0 > Sa || (e.current = ka[Sa], ka[Sa] = null, Sa--)
            }

            function Ca(e, t) {
                Sa++, ka[Sa] = e.current, e.current = t
            }
            var Na = {},
                ja = _a(Na),
                Ta = _a(!1),
                Pa = Na;

            function za(e, t) {
                var n = e.type.contextTypes;
                if (!n) return Na;
                var r = e.stateNode;
                if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
                var a, i = {};
                for (a in n) i[a] = t[a];
                return r && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i
            }

            function Ma(e) {
                return null !== (e = e.childContextTypes) && void 0 !== e
            }

            function Aa() {
                Ea(Ta), Ea(ja)
            }

            function Oa(e, t, n) {
                if (ja.current !== Na) throw Error(i(168));
                Ca(ja, t), Ca(Ta, n)
            }

            function La(e, t, n) {
                var r = e.stateNode;
                if (t = t.childContextTypes, "function" !== typeof r.getChildContext) return n;
                for (var a in r = r.getChildContext())
                    if (!(a in t)) throw Error(i(108, H(e) || "Unknown", a));
                return I({}, n, r)
            }

            function Ra(e) {
                return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || Na, Pa = ja.current, Ca(ja, e), Ca(Ta, Ta.current), !0
            }

            function Ia(e, t, n) {
                var r = e.stateNode;
                if (!r) throw Error(i(169));
                n ? (e = La(e, t, Pa), r.__reactInternalMemoizedMergedChildContext = e, Ea(Ta), Ea(ja), Ca(ja, e)) : Ea(Ta), Ca(Ta, n)
            }
            var Da = null,
                Fa = !1,
                Ua = !1;

            function Ba(e) {
                null === Da ? Da = [e] : Da.push(e)
            }

            function Va() {
                if (!Ua && null !== Da) {
                    Ua = !0;
                    var e = 0,
                        t = bt;
                    try {
                        var n = Da;
                        for (bt = 1; e < n.length; e++) {
                            var r = n[e];
                            do {
                                r = r(!0)
                            } while (null !== r)
                        }
                        Da = null, Fa = !1
                    } catch (a) {
                        throw null !== Da && (Da = Da.slice(e + 1)), Xe(Ze, Va), a
                    } finally {
                        bt = t, Ua = !1
                    }
                }
                return null
            }
            var Ha = [],
                Wa = 0,
                Qa = null,
                Ga = 0,
                Xa = [],
                qa = 0,
                Ya = null,
                Ka = 1,
                $a = "";

            function Ja(e, t) {
                Ha[Wa++] = Ga, Ha[Wa++] = Qa, Qa = e, Ga = t
            }

            function Za(e, t, n) {
                Xa[qa++] = Ka, Xa[qa++] = $a, Xa[qa++] = Ya, Ya = e;
                var r = Ka;
                e = $a;
                var a = 32 - ot(r) - 1;
                r &= ~(1 << a), n += 1;
                var i = 32 - ot(t) + a;
                if (30 < i) {
                    var o = a - a % 5;
                    i = (r & (1 << o) - 1).toString(32), r >>= o, a -= o, Ka = 1 << 32 - ot(t) + a | n << a | r, $a = i + e
                } else Ka = 1 << i | n << a | r, $a = e
            }

            function ei(e) {
                null !== e.return && (Ja(e, 1), Za(e, 1, 0))
            }

            function ti(e) {
                for (; e === Qa;) Qa = Ha[--Wa], Ha[Wa] = null, Ga = Ha[--Wa], Ha[Wa] = null;
                for (; e === Ya;) Ya = Xa[--qa], Xa[qa] = null, $a = Xa[--qa], Xa[qa] = null, Ka = Xa[--qa], Xa[qa] = null
            }
            var ni = null,
                ri = null,
                ai = !1,
                ii = null;

            function oi(e, t) {
                var n = Ms(5, null, null, 0);
                n.elementType = "DELETED", n.stateNode = t, n.return = e, null === (t = e.deletions) ? (e.deletions = [n], e.flags |= 16) : t.push(n)
            }

            function li(e, t) {
                switch (e.tag) {
                    case 5:
                        var n = e.type;
                        return null !== (t = 1 !== t.nodeType || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t) && (e.stateNode = t, ni = e, ri = sa(t.firstChild), !0);
                    case 6:
                        return null !== (t = "" === e.pendingProps || 3 !== t.nodeType ? null : t) && (e.stateNode = t, ni = e, ri = null, !0);
                    case 13:
                        return null !== (t = 8 !== t.nodeType ? null : t) && (n = null !== Ya ? {
                            id: Ka,
                            overflow: $a
                        } : null, e.memoizedState = {
                            dehydrated: t,
                            treeContext: n,
                            retryLane: 1073741824
                        }, (n = Ms(18, null, null, 0)).stateNode = t, n.return = e, e.child = n, ni = e, ri = null, !0);
                    default:
                        return !1
                }
            }

            function ui(e) {
                return 0 !== (1 & e.mode) && 0 === (128 & e.flags)
            }

            function si(e) {
                if (ai) {
                    var t = ri;
                    if (t) {
                        var n = t;
                        if (!li(e, t)) {
                            if (ui(e)) throw Error(i(418));
                            t = sa(n.nextSibling);
                            var r = ni;
                            t && li(e, t) ? oi(r, n) : (e.flags = -4097 & e.flags | 2, ai = !1, ni = e)
                        }
                    } else {
                        if (ui(e)) throw Error(i(418));
                        e.flags = -4097 & e.flags | 2, ai = !1, ni = e
                    }
                }
            }

            function ci(e) {
                for (e = e.return; null !== e && 5 !== e.tag && 3 !== e.tag && 13 !== e.tag;) e = e.return;
                ni = e
            }

            function di(e) {
                if (e !== ni) return !1;
                if (!ai) return ci(e), ai = !0, !1;
                var t;
                if ((t = 3 !== e.tag) && !(t = 5 !== e.tag) && (t = "head" !== (t = e.type) && "body" !== t && !na(e.type, e.memoizedProps)), t && (t = ri)) {
                    if (ui(e)) throw fi(), Error(i(418));
                    for (; t;) oi(e, t), t = sa(t.nextSibling)
                }
                if (ci(e), 13 === e.tag) {
                    if (!(e = null !== (e = e.memoizedState) ? e.dehydrated : null)) throw Error(i(317));
                    e: {
                        for (e = e.nextSibling, t = 0; e;) {
                            if (8 === e.nodeType) {
                                var n = e.data;
                                if ("/$" === n) {
                                    if (0 === t) {
                                        ri = sa(e.nextSibling);
                                        break e
                                    }
                                    t--
                                } else "$" !== n && "$!" !== n && "$?" !== n || t++
                            }
                            e = e.nextSibling
                        }
                        ri = null
                    }
                } else ri = ni ? sa(e.stateNode.nextSibling) : null;
                return !0
            }

            function fi() {
                for (var e = ri; e;) e = sa(e.nextSibling)
            }

            function pi() {
                ri = ni = null, ai = !1
            }

            function hi(e) {
                null === ii ? ii = [e] : ii.push(e)
            }
            var mi = w.ReactCurrentBatchConfig;

            function vi(e, t) {
                if (e && e.defaultProps) {
                    for (var n in t = I({}, t), e = e.defaultProps) void 0 === t[n] && (t[n] = e[n]);
                    return t
                }
                return t
            }
            var gi = _a(null),
                yi = null,
                bi = null,
                wi = null;

            function xi() {
                wi = bi = yi = null
            }

            function ki(e) {
                var t = gi.current;
                Ea(gi), e._currentValue = t
            }

            function Si(e, t, n) {
                for (; null !== e;) {
                    var r = e.alternate;
                    if ((e.childLanes & t) !== t ? (e.childLanes |= t, null !== r && (r.childLanes |= t)) : null !== r && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
                    e = e.return
                }
            }

            function _i(e, t) {
                yi = e, wi = bi = null, null !== (e = e.dependencies) && null !== e.firstContext && (0 !== (e.lanes & t) && (wl = !0), e.firstContext = null)
            }

            function Ei(e) {
                var t = e._currentValue;
                if (wi !== e)
                    if (e = {
                        context: e,
                        memoizedValue: t,
                        next: null
                    }, null === bi) {
                        if (null === yi) throw Error(i(308));
                        bi = e, yi.dependencies = {
                            lanes: 0,
                            firstContext: e
                        }
                    } else bi = bi.next = e;
                return t
            }
            var Ci = null;

            function Ni(e) {
                null === Ci ? Ci = [e] : Ci.push(e)
            }

            function ji(e, t, n, r) {
                var a = t.interleaved;
                return null === a ? (n.next = n, Ni(t)) : (n.next = a.next, a.next = n), t.interleaved = n, Ti(e, r)
            }

            function Ti(e, t) {
                e.lanes |= t;
                var n = e.alternate;
                for (null !== n && (n.lanes |= t), n = e, e = e.return; null !== e;) e.childLanes |= t, null !== (n = e.alternate) && (n.childLanes |= t), n = e, e = e.return;
                return 3 === n.tag ? n.stateNode : null
            }
            var Pi = !1;

            function zi(e) {
                e.updateQueue = {
                    baseState: e.memoizedState,
                    firstBaseUpdate: null,
                    lastBaseUpdate: null,
                    shared: {
                        pending: null,
                        interleaved: null,
                        lanes: 0
                    },
                    effects: null
                }
            }

            function Mi(e, t) {
                e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
                    baseState: e.baseState,
                    firstBaseUpdate: e.firstBaseUpdate,
                    lastBaseUpdate: e.lastBaseUpdate,
                    shared: e.shared,
                    effects: e.effects
                })
            }

            function Ai(e, t) {
                return {
                    eventTime: e,
                    lane: t,
                    tag: 0,
                    payload: null,
                    callback: null,
                    next: null
                }
            }

            function Oi(e, t, n) {
                var r = e.updateQueue;
                if (null === r) return null;
                if (r = r.shared, 0 !== (2 & Tu)) {
                    var a = r.pending;
                    return null === a ? t.next = t : (t.next = a.next, a.next = t), r.pending = t, Ti(e, n)
                }
                return null === (a = r.interleaved) ? (t.next = t, Ni(r)) : (t.next = a.next, a.next = t), r.interleaved = t, Ti(e, n)
            }

            function Li(e, t, n) {
                if (null !== (t = t.updateQueue) && (t = t.shared, 0 !== (4194240 & n))) {
                    var r = t.lanes;
                    n |= r &= e.pendingLanes, t.lanes = n, yt(e, n)
                }
            }

            function Ri(e, t) {
                var n = e.updateQueue,
                    r = e.alternate;
                if (null !== r && n === (r = r.updateQueue)) {
                    var a = null,
                        i = null;
                    if (null !== (n = n.firstBaseUpdate)) {
                        do {
                            var o = {
                                eventTime: n.eventTime,
                                lane: n.lane,
                                tag: n.tag,
                                payload: n.payload,
                                callback: n.callback,
                                next: null
                            };
                            null === i ? a = i = o : i = i.next = o, n = n.next
                        } while (null !== n);
                        null === i ? a = i = t : i = i.next = t
                    } else a = i = t;
                    return n = {
                        baseState: r.baseState,
                        firstBaseUpdate: a,
                        lastBaseUpdate: i,
                        shared: r.shared,
                        effects: r.effects
                    }, void (e.updateQueue = n)
                }
                null === (e = n.lastBaseUpdate) ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
            }

            function Ii(e, t, n, r) {
                var a = e.updateQueue;
                Pi = !1;
                var i = a.firstBaseUpdate,
                    o = a.lastBaseUpdate,
                    l = a.shared.pending;
                if (null !== l) {
                    a.shared.pending = null;
                    var u = l,
                        s = u.next;
                    u.next = null, null === o ? i = s : o.next = s, o = u;
                    var c = e.alternate;
                    null !== c && ((l = (c = c.updateQueue).lastBaseUpdate) !== o && (null === l ? c.firstBaseUpdate = s : l.next = s, c.lastBaseUpdate = u))
                }
                if (null !== i) {
                    var d = a.baseState;
                    for (o = 0, c = s = u = null, l = i; ;) {
                        var f = l.lane,
                            p = l.eventTime;
                        if ((r & f) === f) {
                            null !== c && (c = c.next = {
                                eventTime: p,
                                lane: 0,
                                tag: l.tag,
                                payload: l.payload,
                                callback: l.callback,
                                next: null
                            });
                            e: {
                                var h = e,
                                    m = l;
                                switch (f = t, p = n, m.tag) {
                                    case 1:
                                        if ("function" === typeof (h = m.payload)) {
                                            d = h.call(p, d, f);
                                            break e
                                        }
                                        d = h;
                                        break e;
                                    case 3:
                                        h.flags = -65537 & h.flags | 128;
                                    case 0:
                                        if (null === (f = "function" === typeof (h = m.payload) ? h.call(p, d, f) : h) || void 0 === f) break e;
                                        d = I({}, d, f);
                                        break e;
                                    case 2:
                                        Pi = !0
                                }
                            }
                            null !== l.callback && 0 !== l.lane && (e.flags |= 64, null === (f = a.effects) ? a.effects = [l] : f.push(l))
                        } else p = {
                            eventTime: p,
                            lane: f,
                            tag: l.tag,
                            payload: l.payload,
                            callback: l.callback,
                            next: null
                        }, null === c ? (s = c = p, u = d) : c = c.next = p, o |= f;
                        if (null === (l = l.next)) {
                            if (null === (l = a.shared.pending)) break;
                            l = (f = l).next, f.next = null, a.lastBaseUpdate = f, a.shared.pending = null
                        }
                    }
                    if (null === c && (u = d), a.baseState = u, a.firstBaseUpdate = s, a.lastBaseUpdate = c, null !== (t = a.shared.interleaved)) {
                        a = t;
                        do {
                            o |= a.lane, a = a.next
                        } while (a !== t)
                    } else null === i && (a.shared.lanes = 0);
                    Iu |= o, e.lanes = o, e.memoizedState = d
                }
            }

            function Di(e, t, n) {
                if (e = t.effects, t.effects = null, null !== e)
                    for (t = 0; t < e.length; t++) {
                        var r = e[t],
                            a = r.callback;
                        if (null !== a) {
                            if (r.callback = null, r = n, "function" !== typeof a) throw Error(i(191, a));
                            a.call(r)
                        }
                    }
            }
            var Fi = (new r.Component).refs;

            function Ui(e, t, n, r) {
                n = null === (n = n(r, t = e.memoizedState)) || void 0 === n ? t : I({}, t, n), e.memoizedState = n, 0 === e.lanes && (e.updateQueue.baseState = n)
            }
            var Bi = {
                isMounted: function (e) {
                    return !!(e = e._reactInternals) && Ve(e) === e
                },
                enqueueSetState: function (e, t, n) {
                    e = e._reactInternals;
                    var r = ts(),
                        a = ns(e),
                        i = Ai(r, a);
                    i.payload = t, void 0 !== n && null !== n && (i.callback = n), null !== (t = Oi(e, i, a)) && (rs(t, e, a, r), Li(t, e, a))
                },
                enqueueReplaceState: function (e, t, n) {
                    e = e._reactInternals;
                    var r = ts(),
                        a = ns(e),
                        i = Ai(r, a);
                    i.tag = 1, i.payload = t, void 0 !== n && null !== n && (i.callback = n), null !== (t = Oi(e, i, a)) && (rs(t, e, a, r), Li(t, e, a))
                },
                enqueueForceUpdate: function (e, t) {
                    e = e._reactInternals;
                    var n = ts(),
                        r = ns(e),
                        a = Ai(n, r);
                    a.tag = 2, void 0 !== t && null !== t && (a.callback = t), null !== (t = Oi(e, a, r)) && (rs(t, e, r, n), Li(t, e, r))
                }
            };

            function Vi(e, t, n, r, a, i, o) {
                return "function" === typeof (e = e.stateNode).shouldComponentUpdate ? e.shouldComponentUpdate(r, i, o) : !t.prototype || !t.prototype.isPureReactComponent || (!ur(n, r) || !ur(a, i))
            }

            function Hi(e, t, n) {
                var r = !1,
                    a = Na,
                    i = t.contextType;
                return "object" === typeof i && null !== i ? i = Ei(i) : (a = Ma(t) ? Pa : ja.current, i = (r = null !== (r = t.contextTypes) && void 0 !== r) ? za(e, a) : Na), t = new t(n, i), e.memoizedState = null !== t.state && void 0 !== t.state ? t.state : null, t.updater = Bi, e.stateNode = t, t._reactInternals = e, r && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = a, e.__reactInternalMemoizedMaskedChildContext = i), t
            }

            function Wi(e, t, n, r) {
                e = t.state, "function" === typeof t.componentWillReceiveProps && t.componentWillReceiveProps(n, r), "function" === typeof t.UNSAFE_componentWillReceiveProps && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Bi.enqueueReplaceState(t, t.state, null)
            }

            function Qi(e, t, n, r) {
                var a = e.stateNode;
                a.props = n, a.state = e.memoizedState, a.refs = Fi, zi(e);
                var i = t.contextType;
                "object" === typeof i && null !== i ? a.context = Ei(i) : (i = Ma(t) ? Pa : ja.current, a.context = za(e, i)), a.state = e.memoizedState, "function" === typeof (i = t.getDerivedStateFromProps) && (Ui(e, t, i, n), a.state = e.memoizedState), "function" === typeof t.getDerivedStateFromProps || "function" === typeof a.getSnapshotBeforeUpdate || "function" !== typeof a.UNSAFE_componentWillMount && "function" !== typeof a.componentWillMount || (t = a.state, "function" === typeof a.componentWillMount && a.componentWillMount(), "function" === typeof a.UNSAFE_componentWillMount && a.UNSAFE_componentWillMount(), t !== a.state && Bi.enqueueReplaceState(a, a.state, null), Ii(e, n, a, r), a.state = e.memoizedState), "function" === typeof a.componentDidMount && (e.flags |= 4194308)
            }

            function Gi(e, t, n) {
                if (null !== (e = n.ref) && "function" !== typeof e && "object" !== typeof e) {
                    if (n._owner) {
                        if (n = n._owner) {
                            if (1 !== n.tag) throw Error(i(309));
                            var r = n.stateNode
                        }
                        if (!r) throw Error(i(147, e));
                        var a = r,
                            o = "" + e;
                        return null !== t && null !== t.ref && "function" === typeof t.ref && t.ref._stringRef === o ? t.ref : (t = function (e) {
                            var t = a.refs;
                            t === Fi && (t = a.refs = {}), null === e ? delete t[o] : t[o] = e
                        }, t._stringRef = o, t)
                    }
                    if ("string" !== typeof e) throw Error(i(284));
                    if (!n._owner) throw Error(i(290, e))
                }
                return e
            }

            function Xi(e, t) {
                throw e = Object.prototype.toString.call(t), Error(i(31, "[object Object]" === e ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
            }

            function qi(e) {
                return (0, e._init)(e._payload)
            }

            function Yi(e) {
                function t(t, n) {
                    if (e) {
                        var r = t.deletions;
                        null === r ? (t.deletions = [n], t.flags |= 16) : r.push(n)
                    }
                }

                function n(n, r) {
                    if (!e) return null;
                    for (; null !== r;) t(n, r), r = r.sibling;
                    return null
                }

                function r(e, t) {
                    for (e = new Map; null !== t;) null !== t.key ? e.set(t.key, t) : e.set(t.index, t), t = t.sibling;
                    return e
                }

                function a(e, t) {
                    return (e = Os(e, t)).index = 0, e.sibling = null, e
                }

                function o(t, n, r) {
                    return t.index = r, e ? null !== (r = t.alternate) ? (r = r.index) < n ? (t.flags |= 2, n) : r : (t.flags |= 2, n) : (t.flags |= 1048576, n)
                }

                function l(t) {
                    return e && null === t.alternate && (t.flags |= 2), t
                }

                function u(e, t, n, r) {
                    return null === t || 6 !== t.tag ? ((t = Ds(n, e.mode, r)).return = e, t) : ((t = a(t, n)).return = e, t)
                }

                function s(e, t, n, r) {
                    var i = n.type;
                    return i === S ? d(e, t, n.props.children, r, n.key) : null !== t && (t.elementType === i || "object" === typeof i && null !== i && i.$$typeof === M && qi(i) === t.type) ? ((r = a(t, n.props)).ref = Gi(e, t, n), r.return = e, r) : ((r = Ls(n.type, n.key, n.props, null, e.mode, r)).ref = Gi(e, t, n), r.return = e, r)
                }

                function c(e, t, n, r) {
                    return null === t || 4 !== t.tag || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? ((t = Fs(n, e.mode, r)).return = e, t) : ((t = a(t, n.children || [])).return = e, t)
                }

                function d(e, t, n, r, i) {
                    return null === t || 7 !== t.tag ? ((t = Rs(n, e.mode, r, i)).return = e, t) : ((t = a(t, n)).return = e, t)
                }

                function f(e, t, n) {
                    if ("string" === typeof t && "" !== t || "number" === typeof t) return (t = Ds("" + t, e.mode, n)).return = e, t;
                    if ("object" === typeof t && null !== t) {
                        switch (t.$$typeof) {
                            case x:
                                return (n = Ls(t.type, t.key, t.props, null, e.mode, n)).ref = Gi(e, null, t), n.return = e, n;
                            case k:
                                return (t = Fs(t, e.mode, n)).return = e, t;
                            case M:
                                return f(e, (0, t._init)(t._payload), n)
                        }
                        if (te(t) || L(t)) return (t = Rs(t, e.mode, n, null)).return = e, t;
                        Xi(e, t)
                    }
                    return null
                }

                function p(e, t, n, r) {
                    var a = null !== t ? t.key : null;
                    if ("string" === typeof n && "" !== n || "number" === typeof n) return null !== a ? null : u(e, t, "" + n, r);
                    if ("object" === typeof n && null !== n) {
                        switch (n.$$typeof) {
                            case x:
                                return n.key === a ? s(e, t, n, r) : null;
                            case k:
                                return n.key === a ? c(e, t, n, r) : null;
                            case M:
                                return p(e, t, (a = n._init)(n._payload), r)
                        }
                        if (te(n) || L(n)) return null !== a ? null : d(e, t, n, r, null);
                        Xi(e, n)
                    }
                    return null
                }

                function h(e, t, n, r, a) {
                    if ("string" === typeof r && "" !== r || "number" === typeof r) return u(t, e = e.get(n) || null, "" + r, a);
                    if ("object" === typeof r && null !== r) {
                        switch (r.$$typeof) {
                            case x:
                                return s(t, e = e.get(null === r.key ? n : r.key) || null, r, a);
                            case k:
                                return c(t, e = e.get(null === r.key ? n : r.key) || null, r, a);
                            case M:
                                return h(e, t, n, (0, r._init)(r._payload), a)
                        }
                        if (te(r) || L(r)) return d(t, e = e.get(n) || null, r, a, null);
                        Xi(t, r)
                    }
                    return null
                }

                function m(a, i, l, u) {
                    for (var s = null, c = null, d = i, m = i = 0, v = null; null !== d && m < l.length; m++) {
                        d.index > m ? (v = d, d = null) : v = d.sibling;
                        var g = p(a, d, l[m], u);
                        if (null === g) {
                            null === d && (d = v);
                            break
                        }
                        e && d && null === g.alternate && t(a, d), i = o(g, i, m), null === c ? s = g : c.sibling = g, c = g, d = v
                    }
                    if (m === l.length) return n(a, d), ai && Ja(a, m), s;
                    if (null === d) {
                        for (; m < l.length; m++) null !== (d = f(a, l[m], u)) && (i = o(d, i, m), null === c ? s = d : c.sibling = d, c = d);
                        return ai && Ja(a, m), s
                    }
                    for (d = r(a, d); m < l.length; m++) null !== (v = h(d, a, m, l[m], u)) && (e && null !== v.alternate && d.delete(null === v.key ? m : v.key), i = o(v, i, m), null === c ? s = v : c.sibling = v, c = v);
                    return e && d.forEach((function (e) {
                        return t(a, e)
                    })), ai && Ja(a, m), s
                }

                function v(a, l, u, s) {
                    var c = L(u);
                    if ("function" !== typeof c) throw Error(i(150));
                    if (null == (u = c.call(u))) throw Error(i(151));
                    for (var d = c = null, m = l, v = l = 0, g = null, y = u.next(); null !== m && !y.done; v++, y = u.next()) {
                        m.index > v ? (g = m, m = null) : g = m.sibling;
                        var b = p(a, m, y.value, s);
                        if (null === b) {
                            null === m && (m = g);
                            break
                        }
                        e && m && null === b.alternate && t(a, m), l = o(b, l, v), null === d ? c = b : d.sibling = b, d = b, m = g
                    }
                    if (y.done) return n(a, m), ai && Ja(a, v), c;
                    if (null === m) {
                        for (; !y.done; v++, y = u.next()) null !== (y = f(a, y.value, s)) && (l = o(y, l, v), null === d ? c = y : d.sibling = y, d = y);
                        return ai && Ja(a, v), c
                    }
                    for (m = r(a, m); !y.done; v++, y = u.next()) null !== (y = h(m, a, v, y.value, s)) && (e && null !== y.alternate && m.delete(null === y.key ? v : y.key), l = o(y, l, v), null === d ? c = y : d.sibling = y, d = y);
                    return e && m.forEach((function (e) {
                        return t(a, e)
                    })), ai && Ja(a, v), c
                }
                return function e(r, i, o, u) {
                    if ("object" === typeof o && null !== o && o.type === S && null === o.key && (o = o.props.children), "object" === typeof o && null !== o) {
                        switch (o.$$typeof) {
                            case x:
                                e: {
                                    for (var s = o.key, c = i; null !== c;) {
                                        if (c.key === s) {
                                            if ((s = o.type) === S) {
                                                if (7 === c.tag) {
                                                    n(r, c.sibling), (i = a(c, o.props.children)).return = r, r = i;
                                                    break e
                                                }
                                            } else if (c.elementType === s || "object" === typeof s && null !== s && s.$$typeof === M && qi(s) === c.type) {
                                                n(r, c.sibling), (i = a(c, o.props)).ref = Gi(r, c, o), i.return = r, r = i;
                                                break e
                                            }
                                            n(r, c);
                                            break
                                        }
                                        t(r, c), c = c.sibling
                                    }
                                    o.type === S ? ((i = Rs(o.props.children, r.mode, u, o.key)).return = r, r = i) : ((u = Ls(o.type, o.key, o.props, null, r.mode, u)).ref = Gi(r, i, o), u.return = r, r = u)
                                }
                                return l(r);
                            case k:
                                e: {
                                    for (c = o.key; null !== i;) {
                                        if (i.key === c) {
                                            if (4 === i.tag && i.stateNode.containerInfo === o.containerInfo && i.stateNode.implementation === o.implementation) {
                                                n(r, i.sibling), (i = a(i, o.children || [])).return = r, r = i;
                                                break e
                                            }
                                            n(r, i);
                                            break
                                        }
                                        t(r, i), i = i.sibling
                                    } (i = Fs(o, r.mode, u)).return = r,
                                        r = i
                                }
                                return l(r);
                            case M:
                                return e(r, i, (c = o._init)(o._payload), u)
                        }
                        if (te(o)) return m(r, i, o, u);
                        if (L(o)) return v(r, i, o, u);
                        Xi(r, o)
                    }
                    return "string" === typeof o && "" !== o || "number" === typeof o ? (o = "" + o, null !== i && 6 === i.tag ? (n(r, i.sibling), (i = a(i, o)).return = r, r = i) : (n(r, i), (i = Ds(o, r.mode, u)).return = r, r = i), l(r)) : n(r, i)
                }
            }
            var Ki = Yi(!0),
                $i = Yi(!1),
                Ji = {},
                Zi = _a(Ji),
                eo = _a(Ji),
                to = _a(Ji);

            function no(e) {
                if (e === Ji) throw Error(i(174));
                return e
            }

            function ro(e, t) {
                switch (Ca(to, t), Ca(eo, e), Ca(Zi, Ji), e = t.nodeType) {
                    case 9:
                    case 11:
                        t = (t = t.documentElement) ? t.namespaceURI : ue(null, "");
                        break;
                    default:
                        t = ue(t = (e = 8 === e ? t.parentNode : t).namespaceURI || null, e = e.tagName)
                }
                Ea(Zi), Ca(Zi, t)
            }

            function ao() {
                Ea(Zi), Ea(eo), Ea(to)
            }

            function io(e) {
                no(to.current);
                var t = no(Zi.current),
                    n = ue(t, e.type);
                t !== n && (Ca(eo, e), Ca(Zi, n))
            }

            function oo(e) {
                eo.current === e && (Ea(Zi), Ea(eo))
            }
            var lo = _a(0);

            function uo(e) {
                for (var t = e; null !== t;) {
                    if (13 === t.tag) {
                        var n = t.memoizedState;
                        if (null !== n && (null === (n = n.dehydrated) || "$?" === n.data || "$!" === n.data)) return t
                    } else if (19 === t.tag && void 0 !== t.memoizedProps.revealOrder) {
                        if (0 !== (128 & t.flags)) return t
                    } else if (null !== t.child) {
                        t.child.return = t, t = t.child;
                        continue
                    }
                    if (t === e) break;
                    for (; null === t.sibling;) {
                        if (null === t.return || t.return === e) return null;
                        t = t.return
                    }
                    t.sibling.return = t.return, t = t.sibling
                }
                return null
            }
            var so = [];

            function co() {
                for (var e = 0; e < so.length; e++) so[e]._workInProgressVersionPrimary = null;
                so.length = 0
            }
            var fo = w.ReactCurrentDispatcher,
                po = w.ReactCurrentBatchConfig,
                ho = 0,
                mo = null,
                vo = null,
                go = null,
                yo = !1,
                bo = !1,
                wo = 0,
                xo = 0;

            function ko() {
                throw Error(i(321))
            }

            function So(e, t) {
                if (null === t) return !1;
                for (var n = 0; n < t.length && n < e.length; n++)
                    if (!lr(e[n], t[n])) return !1;
                return !0
            }

            function _o(e, t, n, r, a, o) {
                if (ho = o, mo = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, fo.current = null === e || null === e.memoizedState ? ll : ul, e = n(r, a), bo) {
                    o = 0;
                    do {
                        if (bo = !1, wo = 0, 25 <= o) throw Error(i(301));
                        o += 1, go = vo = null, t.updateQueue = null, fo.current = sl, e = n(r, a)
                    } while (bo)
                }
                if (fo.current = ol, t = null !== vo && null !== vo.next, ho = 0, go = vo = mo = null, yo = !1, t) throw Error(i(300));
                return e
            }

            function Eo() {
                var e = 0 !== wo;
                return wo = 0, e
            }

            function Co() {
                var e = {
                    memoizedState: null,
                    baseState: null,
                    baseQueue: null,
                    queue: null,
                    next: null
                };
                return null === go ? mo.memoizedState = go = e : go = go.next = e, go
            }

            function No() {
                if (null === vo) {
                    var e = mo.alternate;
                    e = null !== e ? e.memoizedState : null
                } else e = vo.next;
                var t = null === go ? mo.memoizedState : go.next;
                if (null !== t) go = t, vo = e;
                else {
                    if (null === e) throw Error(i(310));
                    e = {
                        memoizedState: (vo = e).memoizedState,
                        baseState: vo.baseState,
                        baseQueue: vo.baseQueue,
                        queue: vo.queue,
                        next: null
                    }, null === go ? mo.memoizedState = go = e : go = go.next = e
                }
                return go
            }

            function jo(e, t) {
                return "function" === typeof t ? t(e) : t
            }

            function To(e) {
                var t = No(),
                    n = t.queue;
                if (null === n) throw Error(i(311));
                n.lastRenderedReducer = e;
                var r = vo,
                    a = r.baseQueue,
                    o = n.pending;
                if (null !== o) {
                    if (null !== a) {
                        var l = a.next;
                        a.next = o.next, o.next = l
                    }
                    r.baseQueue = a = o, n.pending = null
                }
                if (null !== a) {
                    o = a.next, r = r.baseState;
                    var u = l = null,
                        s = null,
                        c = o;
                    do {
                        var d = c.lane;
                        if ((ho & d) === d) null !== s && (s = s.next = {
                            lane: 0,
                            action: c.action,
                            hasEagerState: c.hasEagerState,
                            eagerState: c.eagerState,
                            next: null
                        }), r = c.hasEagerState ? c.eagerState : e(r, c.action);
                        else {
                            var f = {
                                lane: d,
                                action: c.action,
                                hasEagerState: c.hasEagerState,
                                eagerState: c.eagerState,
                                next: null
                            };
                            null === s ? (u = s = f, l = r) : s = s.next = f, mo.lanes |= d, Iu |= d
                        }
                        c = c.next
                    } while (null !== c && c !== o);
                    null === s ? l = r : s.next = u, lr(r, t.memoizedState) || (wl = !0), t.memoizedState = r, t.baseState = l, t.baseQueue = s, n.lastRenderedState = r
                }
                if (null !== (e = n.interleaved)) {
                    a = e;
                    do {
                        o = a.lane, mo.lanes |= o, Iu |= o, a = a.next
                    } while (a !== e)
                } else null === a && (n.lanes = 0);
                return [t.memoizedState, n.dispatch]
            }

            function Po(e) {
                var t = No(),
                    n = t.queue;
                if (null === n) throw Error(i(311));
                n.lastRenderedReducer = e;
                var r = n.dispatch,
                    a = n.pending,
                    o = t.memoizedState;
                if (null !== a) {
                    n.pending = null;
                    var l = a = a.next;
                    do {
                        o = e(o, l.action), l = l.next
                    } while (l !== a);
                    lr(o, t.memoizedState) || (wl = !0), t.memoizedState = o, null === t.baseQueue && (t.baseState = o), n.lastRenderedState = o
                }
                return [o, r]
            }

            function zo() { }

            function Mo(e, t) {
                var n = mo,
                    r = No(),
                    a = t(),
                    o = !lr(r.memoizedState, a);
                if (o && (r.memoizedState = a, wl = !0), r = r.queue, Wo(Lo.bind(null, n, r, e), [e]), r.getSnapshot !== t || o || null !== go && 1 & go.memoizedState.tag) {
                    if (n.flags |= 2048, Fo(9, Oo.bind(null, n, r, a, t), void 0, null), null === Pu) throw Error(i(349));
                    0 !== (30 & ho) || Ao(n, t, a)
                }
                return a
            }

            function Ao(e, t, n) {
                e.flags |= 16384, e = {
                    getSnapshot: t,
                    value: n
                }, null === (t = mo.updateQueue) ? (t = {
                    lastEffect: null,
                    stores: null
                }, mo.updateQueue = t, t.stores = [e]) : null === (n = t.stores) ? t.stores = [e] : n.push(e)
            }

            function Oo(e, t, n, r) {
                t.value = n, t.getSnapshot = r, Ro(t) && Io(e)
            }

            function Lo(e, t, n) {
                return n((function () {
                    Ro(t) && Io(e)
                }))
            }

            function Ro(e) {
                var t = e.getSnapshot;
                e = e.value;
                try {
                    var n = t();
                    return !lr(e, n)
                } catch (r) {
                    return !0
                }
            }

            function Io(e) {
                var t = Ti(e, 1);
                null !== t && rs(t, e, 1, -1)
            }

            function Do(e) {
                var t = Co();
                return "function" === typeof e && (e = e()), t.memoizedState = t.baseState = e, e = {
                    pending: null,
                    interleaved: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: jo,
                    lastRenderedState: e
                }, t.queue = e, e = e.dispatch = nl.bind(null, mo, e), [t.memoizedState, e]
            }

            function Fo(e, t, n, r) {
                return e = {
                    tag: e,
                    create: t,
                    destroy: n,
                    deps: r,
                    next: null
                }, null === (t = mo.updateQueue) ? (t = {
                    lastEffect: null,
                    stores: null
                }, mo.updateQueue = t, t.lastEffect = e.next = e) : null === (n = t.lastEffect) ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e
            }

            function Uo() {
                return No().memoizedState
            }

            function Bo(e, t, n, r) {
                var a = Co();
                mo.flags |= e, a.memoizedState = Fo(1 | t, n, void 0, void 0 === r ? null : r)
            }

            function Vo(e, t, n, r) {
                var a = No();
                r = void 0 === r ? null : r;
                var i = void 0;
                if (null !== vo) {
                    var o = vo.memoizedState;
                    if (i = o.destroy, null !== r && So(r, o.deps)) return void (a.memoizedState = Fo(t, n, i, r))
                }
                mo.flags |= e, a.memoizedState = Fo(1 | t, n, i, r)
            }

            function Ho(e, t) {
                return Bo(8390656, 8, e, t)
            }

            function Wo(e, t) {
                return Vo(2048, 8, e, t)
            }

            function Qo(e, t) {
                return Vo(4, 2, e, t)
            }

            function Go(e, t) {
                return Vo(4, 4, e, t)
            }

            function Xo(e, t) {
                return "function" === typeof t ? (e = e(), t(e), function () {
                    t(null)
                }) : null !== t && void 0 !== t ? (e = e(), t.current = e, function () {
                    t.current = null
                }) : void 0
            }

            function qo(e, t, n) {
                return n = null !== n && void 0 !== n ? n.concat([e]) : null, Vo(4, 4, Xo.bind(null, t, e), n)
            }

            function Yo() { }

            function Ko(e, t) {
                var n = No();
                t = void 0 === t ? null : t;
                var r = n.memoizedState;
                return null !== r && null !== t && So(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
            }

            function $o(e, t) {
                var n = No();
                t = void 0 === t ? null : t;
                var r = n.memoizedState;
                return null !== r && null !== t && So(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
            }

            function Jo(e, t, n) {
                return 0 === (21 & ho) ? (e.baseState && (e.baseState = !1, wl = !0), e.memoizedState = n) : (lr(n, t) || (n = mt(), mo.lanes |= n, Iu |= n, e.baseState = !0), t)
            }

            function Zo(e, t) {
                var n = bt;
                bt = 0 !== n && 4 > n ? n : 4, e(!0);
                var r = po.transition;
                po.transition = {};
                try {
                    e(!1), t()
                } finally {
                    bt = n, po.transition = r
                }
            }

            function el() {
                return No().memoizedState
            }

            function tl(e, t, n) {
                var r = ns(e);
                if (n = {
                    lane: r,
                    action: n,
                    hasEagerState: !1,
                    eagerState: null,
                    next: null
                }, rl(e)) al(t, n);
                else if (null !== (n = ji(e, t, n, r))) {
                    rs(n, e, r, ts()), il(n, t, r)
                }
            }

            function nl(e, t, n) {
                var r = ns(e),
                    a = {
                        lane: r,
                        action: n,
                        hasEagerState: !1,
                        eagerState: null,
                        next: null
                    };
                if (rl(e)) al(t, a);
                else {
                    var i = e.alternate;
                    if (0 === e.lanes && (null === i || 0 === i.lanes) && null !== (i = t.lastRenderedReducer)) try {
                        var o = t.lastRenderedState,
                            l = i(o, n);
                        if (a.hasEagerState = !0, a.eagerState = l, lr(l, o)) {
                            var u = t.interleaved;
                            return null === u ? (a.next = a, Ni(t)) : (a.next = u.next, u.next = a), void (t.interleaved = a)
                        }
                    } catch (s) { }
                    null !== (n = ji(e, t, a, r)) && (rs(n, e, r, a = ts()), il(n, t, r))
                }
            }

            function rl(e) {
                var t = e.alternate;
                return e === mo || null !== t && t === mo
            }

            function al(e, t) {
                bo = yo = !0;
                var n = e.pending;
                null === n ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
            }

            function il(e, t, n) {
                if (0 !== (4194240 & n)) {
                    var r = t.lanes;
                    n |= r &= e.pendingLanes, t.lanes = n, yt(e, n)
                }
            }
            var ol = {
                readContext: Ei,
                useCallback: ko,
                useContext: ko,
                useEffect: ko,
                useImperativeHandle: ko,
                useInsertionEffect: ko,
                useLayoutEffect: ko,
                useMemo: ko,
                useReducer: ko,
                useRef: ko,
                useState: ko,
                useDebugValue: ko,
                useDeferredValue: ko,
                useTransition: ko,
                useMutableSource: ko,
                useSyncExternalStore: ko,
                useId: ko,
                unstable_isNewReconciler: !1
            },
                ll = {
                    readContext: Ei,
                    useCallback: function (e, t) {
                        return Co().memoizedState = [e, void 0 === t ? null : t], e
                    },
                    useContext: Ei,
                    useEffect: Ho,
                    useImperativeHandle: function (e, t, n) {
                        return n = null !== n && void 0 !== n ? n.concat([e]) : null, Bo(4194308, 4, Xo.bind(null, t, e), n)
                    },
                    useLayoutEffect: function (e, t) {
                        return Bo(4194308, 4, e, t)
                    },
                    useInsertionEffect: function (e, t) {
                        return Bo(4, 2, e, t)
                    },
                    useMemo: function (e, t) {
                        var n = Co();
                        return t = void 0 === t ? null : t, e = e(), n.memoizedState = [e, t], e
                    },
                    useReducer: function (e, t, n) {
                        var r = Co();
                        return t = void 0 !== n ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                            pending: null,
                            interleaved: null,
                            lanes: 0,
                            dispatch: null,
                            lastRenderedReducer: e,
                            lastRenderedState: t
                        }, r.queue = e, e = e.dispatch = tl.bind(null, mo, e), [r.memoizedState, e]
                    },
                    useRef: function (e) {
                        return e = {
                            current: e
                        }, Co().memoizedState = e
                    },
                    useState: Do,
                    useDebugValue: Yo,
                    useDeferredValue: function (e) {
                        return Co().memoizedState = e
                    },
                    useTransition: function () {
                        var e = Do(!1),
                            t = e[0];
                        return e = Zo.bind(null, e[1]), Co().memoizedState = e, [t, e]
                    },
                    useMutableSource: function () { },
                    useSyncExternalStore: function (e, t, n) {
                        var r = mo,
                            a = Co();
                        if (ai) {
                            if (void 0 === n) throw Error(i(407));
                            n = n()
                        } else {
                            if (n = t(), null === Pu) throw Error(i(349));
                            0 !== (30 & ho) || Ao(r, t, n)
                        }
                        a.memoizedState = n;
                        var o = {
                            value: n,
                            getSnapshot: t
                        };
                        return a.queue = o, Ho(Lo.bind(null, r, o, e), [e]), r.flags |= 2048, Fo(9, Oo.bind(null, r, o, n, t), void 0, null), n
                    },
                    useId: function () {
                        var e = Co(),
                            t = Pu.identifierPrefix;
                        if (ai) {
                            var n = $a;
                            t = ":" + t + "R" + (n = (Ka & ~(1 << 32 - ot(Ka) - 1)).toString(32) + n), 0 < (n = wo++) && (t += "H" + n.toString(32)), t += ":"
                        } else t = ":" + t + "r" + (n = xo++).toString(32) + ":";
                        return e.memoizedState = t
                    },
                    unstable_isNewReconciler: !1
                },
                ul = {
                    readContext: Ei,
                    useCallback: Ko,
                    useContext: Ei,
                    useEffect: Wo,
                    useImperativeHandle: qo,
                    useInsertionEffect: Qo,
                    useLayoutEffect: Go,
                    useMemo: $o,
                    useReducer: To,
                    useRef: Uo,
                    useState: function () {
                        return To(jo)
                    },
                    useDebugValue: Yo,
                    useDeferredValue: function (e) {
                        return Jo(No(), vo.memoizedState, e)
                    },
                    useTransition: function () {
                        return [To(jo)[0], No().memoizedState]
                    },
                    useMutableSource: zo,
                    useSyncExternalStore: Mo,
                    useId: el,
                    unstable_isNewReconciler: !1
                },
                sl = {
                    readContext: Ei,
                    useCallback: Ko,
                    useContext: Ei,
                    useEffect: Wo,
                    useImperativeHandle: qo,
                    useInsertionEffect: Qo,
                    useLayoutEffect: Go,
                    useMemo: $o,
                    useReducer: Po,
                    useRef: Uo,
                    useState: function () {
                        return Po(jo)
                    },
                    useDebugValue: Yo,
                    useDeferredValue: function (e) {
                        var t = No();
                        return null === vo ? t.memoizedState = e : Jo(t, vo.memoizedState, e)
                    },
                    useTransition: function () {
                        return [Po(jo)[0], No().memoizedState]
                    },
                    useMutableSource: zo,
                    useSyncExternalStore: Mo,
                    useId: el,
                    unstable_isNewReconciler: !1
                };

            function cl(e, t) {
                try {
                    var n = "",
                        r = t;
                    do {
                        n += B(r), r = r.return
                    } while (r);
                    var a = n
                } catch (i) {
                    a = "\nError generating stack: " + i.message + "\n" + i.stack
                }
                return {
                    value: e,
                    source: t,
                    stack: a,
                    digest: null
                }
            }

            function dl(e, t, n) {
                return {
                    value: e,
                    source: null,
                    stack: null != n ? n : null,
                    digest: null != t ? t : null
                }
            }

            function fl(e, t) {
                try {
                    console.error(t.value)
                } catch (n) {
                    setTimeout((function () {
                        throw n
                    }))
                }
            }
            var pl = "function" === typeof WeakMap ? WeakMap : Map;

            function hl(e, t, n) {
                (n = Ai(-1, n)).tag = 3, n.payload = {
                    element: null
                };
                var r = t.value;
                return n.callback = function () {
                    Qu || (Qu = !0, Gu = r), fl(0, t)
                }, n
            }

            function ml(e, t, n) {
                (n = Ai(-1, n)).tag = 3;
                var r = e.type.getDerivedStateFromError;
                if ("function" === typeof r) {
                    var a = t.value;
                    n.payload = function () {
                        return r(a)
                    }, n.callback = function () {
                        fl(0, t)
                    }
                }
                var i = e.stateNode;
                return null !== i && "function" === typeof i.componentDidCatch && (n.callback = function () {
                    fl(0, t), "function" !== typeof r && (null === Xu ? Xu = new Set([this]) : Xu.add(this));
                    var e = t.stack;
                    this.componentDidCatch(t.value, {
                        componentStack: null !== e ? e : ""
                    })
                }), n
            }

            function vl(e, t, n) {
                var r = e.pingCache;
                if (null === r) {
                    r = e.pingCache = new pl;
                    var a = new Set;
                    r.set(t, a)
                } else void 0 === (a = r.get(t)) && (a = new Set, r.set(t, a));
                a.has(n) || (a.add(n), e = Cs.bind(null, e, t, n), t.then(e, e))
            }

            function gl(e) {
                do {
                    var t;
                    if ((t = 13 === e.tag) && (t = null === (t = e.memoizedState) || null !== t.dehydrated), t) return e;
                    e = e.return
                } while (null !== e);
                return null
            }

            function yl(e, t, n, r, a) {
                return 0 === (1 & e.mode) ? (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, 1 === n.tag && (null === n.alternate ? n.tag = 17 : ((t = Ai(-1, 1)).tag = 2, Oi(n, t, 1))), n.lanes |= 1), e) : (e.flags |= 65536, e.lanes = a, e)
            }
            var bl = w.ReactCurrentOwner,
                wl = !1;

            function xl(e, t, n, r) {
                t.child = null === e ? $i(t, null, n, r) : Ki(t, e.child, n, r)
            }

            function kl(e, t, n, r, a) {
                n = n.render;
                var i = t.ref;
                return _i(t, a), r = _o(e, t, n, r, i, a), n = Eo(), null === e || wl ? (ai && n && ei(t), t.flags |= 1, xl(e, t, r, a), t.child) : (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a, Ql(e, t, a))
            }

            function Sl(e, t, n, r, a) {
                if (null === e) {
                    var i = n.type;
                    return "function" !== typeof i || As(i) || void 0 !== i.defaultProps || null !== n.compare || void 0 !== n.defaultProps ? ((e = Ls(n.type, null, r, t, t.mode, a)).ref = t.ref, e.return = t, t.child = e) : (t.tag = 15, t.type = i, _l(e, t, i, r, a))
                }
                if (i = e.child, 0 === (e.lanes & a)) {
                    var o = i.memoizedProps;
                    if ((n = null !== (n = n.compare) ? n : ur)(o, r) && e.ref === t.ref) return Ql(e, t, a)
                }
                return t.flags |= 1, (e = Os(i, r)).ref = t.ref, e.return = t, t.child = e
            }

            function _l(e, t, n, r, a) {
                if (null !== e) {
                    var i = e.memoizedProps;
                    if (ur(i, r) && e.ref === t.ref) {
                        if (wl = !1, t.pendingProps = r = i, 0 === (e.lanes & a)) return t.lanes = e.lanes, Ql(e, t, a);
                        0 !== (131072 & e.flags) && (wl = !0)
                    }
                }
                return Nl(e, t, n, r, a)
            }

            function El(e, t, n) {
                var r = t.pendingProps,
                    a = r.children,
                    i = null !== e ? e.memoizedState : null;
                if ("hidden" === r.mode)
                    if (0 === (1 & t.mode)) t.memoizedState = {
                        baseLanes: 0,
                        cachePool: null,
                        transitions: null
                    }, Ca(Ou, Au), Au |= n;
                    else {
                        if (0 === (1073741824 & n)) return e = null !== i ? i.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                            baseLanes: e,
                            cachePool: null,
                            transitions: null
                        }, t.updateQueue = null, Ca(Ou, Au), Au |= e, null;
                        t.memoizedState = {
                            baseLanes: 0,
                            cachePool: null,
                            transitions: null
                        }, r = null !== i ? i.baseLanes : n, Ca(Ou, Au), Au |= r
                    }
                else null !== i ? (r = i.baseLanes | n, t.memoizedState = null) : r = n, Ca(Ou, Au), Au |= r;
                return xl(e, t, a, n), t.child
            }

            function Cl(e, t) {
                var n = t.ref;
                (null === e && null !== n || null !== e && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
            }

            function Nl(e, t, n, r, a) {
                var i = Ma(n) ? Pa : ja.current;
                return i = za(t, i), _i(t, a), n = _o(e, t, n, r, i, a), r = Eo(), null === e || wl ? (ai && r && ei(t), t.flags |= 1, xl(e, t, n, a), t.child) : (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a, Ql(e, t, a))
            }

            function jl(e, t, n, r, a) {
                if (Ma(n)) {
                    var i = !0;
                    Ra(t)
                } else i = !1;
                if (_i(t, a), null === t.stateNode) Wl(e, t), Hi(t, n, r), Qi(t, n, r, a), r = !0;
                else if (null === e) {
                    var o = t.stateNode,
                        l = t.memoizedProps;
                    o.props = l;
                    var u = o.context,
                        s = n.contextType;
                    "object" === typeof s && null !== s ? s = Ei(s) : s = za(t, s = Ma(n) ? Pa : ja.current);
                    var c = n.getDerivedStateFromProps,
                        d = "function" === typeof c || "function" === typeof o.getSnapshotBeforeUpdate;
                    d || "function" !== typeof o.UNSAFE_componentWillReceiveProps && "function" !== typeof o.componentWillReceiveProps || (l !== r || u !== s) && Wi(t, o, r, s), Pi = !1;
                    var f = t.memoizedState;
                    o.state = f, Ii(t, r, o, a), u = t.memoizedState, l !== r || f !== u || Ta.current || Pi ? ("function" === typeof c && (Ui(t, n, c, r), u = t.memoizedState), (l = Pi || Vi(t, n, l, r, f, u, s)) ? (d || "function" !== typeof o.UNSAFE_componentWillMount && "function" !== typeof o.componentWillMount || ("function" === typeof o.componentWillMount && o.componentWillMount(), "function" === typeof o.UNSAFE_componentWillMount && o.UNSAFE_componentWillMount()), "function" === typeof o.componentDidMount && (t.flags |= 4194308)) : ("function" === typeof o.componentDidMount && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = u), o.props = r, o.state = u, o.context = s, r = l) : ("function" === typeof o.componentDidMount && (t.flags |= 4194308), r = !1)
                } else {
                    o = t.stateNode, Mi(e, t), l = t.memoizedProps, s = t.type === t.elementType ? l : vi(t.type, l), o.props = s, d = t.pendingProps, f = o.context, "object" === typeof (u = n.contextType) && null !== u ? u = Ei(u) : u = za(t, u = Ma(n) ? Pa : ja.current);
                    var p = n.getDerivedStateFromProps;
                    (c = "function" === typeof p || "function" === typeof o.getSnapshotBeforeUpdate) || "function" !== typeof o.UNSAFE_componentWillReceiveProps && "function" !== typeof o.componentWillReceiveProps || (l !== d || f !== u) && Wi(t, o, r, u), Pi = !1, f = t.memoizedState, o.state = f, Ii(t, r, o, a);
                    var h = t.memoizedState;
                    l !== d || f !== h || Ta.current || Pi ? ("function" === typeof p && (Ui(t, n, p, r), h = t.memoizedState), (s = Pi || Vi(t, n, s, r, f, h, u) || !1) ? (c || "function" !== typeof o.UNSAFE_componentWillUpdate && "function" !== typeof o.componentWillUpdate || ("function" === typeof o.componentWillUpdate && o.componentWillUpdate(r, h, u), "function" === typeof o.UNSAFE_componentWillUpdate && o.UNSAFE_componentWillUpdate(r, h, u)), "function" === typeof o.componentDidUpdate && (t.flags |= 4), "function" === typeof o.getSnapshotBeforeUpdate && (t.flags |= 1024)) : ("function" !== typeof o.componentDidUpdate || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" !== typeof o.getSnapshotBeforeUpdate || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = h), o.props = r, o.state = h, o.context = u, r = s) : ("function" !== typeof o.componentDidUpdate || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" !== typeof o.getSnapshotBeforeUpdate || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
                }
                return Tl(e, t, n, r, i, a)
            }

            function Tl(e, t, n, r, a, i) {
                Cl(e, t);
                var o = 0 !== (128 & t.flags);
                if (!r && !o) return a && Ia(t, n, !1), Ql(e, t, i);
                r = t.stateNode, bl.current = t;
                var l = o && "function" !== typeof n.getDerivedStateFromError ? null : r.render();
                return t.flags |= 1, null !== e && o ? (t.child = Ki(t, e.child, null, i), t.child = Ki(t, null, l, i)) : xl(e, t, l, i), t.memoizedState = r.state, a && Ia(t, n, !0), t.child
            }

            function Pl(e) {
                var t = e.stateNode;
                t.pendingContext ? Oa(0, t.pendingContext, t.pendingContext !== t.context) : t.context && Oa(0, t.context, !1), ro(e, t.containerInfo)
            }

            function zl(e, t, n, r, a) {
                return pi(), hi(a), t.flags |= 256, xl(e, t, n, r), t.child
            }
            var Ml, Al, Ol, Ll, Rl = {
                dehydrated: null,
                treeContext: null,
                retryLane: 0
            };

            function Il(e) {
                return {
                    baseLanes: e,
                    cachePool: null,
                    transitions: null
                }
            }

            function Dl(e, t, n) {
                var r, a = t.pendingProps,
                    o = lo.current,
                    l = !1,
                    u = 0 !== (128 & t.flags);
                if ((r = u) || (r = (null === e || null !== e.memoizedState) && 0 !== (2 & o)), r ? (l = !0, t.flags &= -129) : null !== e && null === e.memoizedState || (o |= 1), Ca(lo, 1 & o), null === e) return si(t), null !== (e = t.memoizedState) && null !== (e = e.dehydrated) ? (0 === (1 & t.mode) ? t.lanes = 1 : "$!" === e.data ? t.lanes = 8 : t.lanes = 1073741824, null) : (u = a.children, e = a.fallback, l ? (a = t.mode, l = t.child, u = {
                    mode: "hidden",
                    children: u
                }, 0 === (1 & a) && null !== l ? (l.childLanes = 0, l.pendingProps = u) : l = Is(u, a, 0, null), e = Rs(e, a, n, null), l.return = t, e.return = t, l.sibling = e, t.child = l, t.child.memoizedState = Il(n), t.memoizedState = Rl, e) : Fl(t, u));
                if (null !== (o = e.memoizedState) && null !== (r = o.dehydrated)) return function (e, t, n, r, a, o, l) {
                    if (n) return 256 & t.flags ? (t.flags &= -257, Ul(e, t, l, r = dl(Error(i(422))))) : null !== t.memoizedState ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, a = t.mode, r = Is({
                        mode: "visible",
                        children: r.children
                    }, a, 0, null), (o = Rs(o, a, l, null)).flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, 0 !== (1 & t.mode) && Ki(t, e.child, null, l), t.child.memoizedState = Il(l), t.memoizedState = Rl, o);
                    if (0 === (1 & t.mode)) return Ul(e, t, l, null);
                    if ("$!" === a.data) {
                        if (r = a.nextSibling && a.nextSibling.dataset) var u = r.dgst;
                        return r = u, Ul(e, t, l, r = dl(o = Error(i(419)), r, void 0))
                    }
                    if (u = 0 !== (l & e.childLanes), wl || u) {
                        if (null !== (r = Pu)) {
                            switch (l & -l) {
                                case 4:
                                    a = 2;
                                    break;
                                case 16:
                                    a = 8;
                                    break;
                                case 64:
                                case 128:
                                case 256:
                                case 512:
                                case 1024:
                                case 2048:
                                case 4096:
                                case 8192:
                                case 16384:
                                case 32768:
                                case 65536:
                                case 131072:
                                case 262144:
                                case 524288:
                                case 1048576:
                                case 2097152:
                                case 4194304:
                                case 8388608:
                                case 16777216:
                                case 33554432:
                                case 67108864:
                                    a = 32;
                                    break;
                                case 536870912:
                                    a = 268435456;
                                    break;
                                default:
                                    a = 0
                            }
                            0 !== (a = 0 !== (a & (r.suspendedLanes | l)) ? 0 : a) && a !== o.retryLane && (o.retryLane = a, Ti(e, a), rs(r, e, a, -1))
                        }
                        return vs(), Ul(e, t, l, r = dl(Error(i(421))))
                    }
                    return "$?" === a.data ? (t.flags |= 128, t.child = e.child, t = js.bind(null, e), a._reactRetry = t, null) : (e = o.treeContext, ri = sa(a.nextSibling), ni = t, ai = !0, ii = null, null !== e && (Xa[qa++] = Ka, Xa[qa++] = $a, Xa[qa++] = Ya, Ka = e.id, $a = e.overflow, Ya = t), t = Fl(t, r.children), t.flags |= 4096, t)
                }(e, t, u, a, r, o, n);
                if (l) {
                    l = a.fallback, u = t.mode, r = (o = e.child).sibling;
                    var s = {
                        mode: "hidden",
                        children: a.children
                    };
                    return 0 === (1 & u) && t.child !== o ? ((a = t.child).childLanes = 0, a.pendingProps = s, t.deletions = null) : (a = Os(o, s)).subtreeFlags = 14680064 & o.subtreeFlags, null !== r ? l = Os(r, l) : (l = Rs(l, u, n, null)).flags |= 2, l.return = t, a.return = t, a.sibling = l, t.child = a, a = l, l = t.child, u = null === (u = e.child.memoizedState) ? Il(n) : {
                        baseLanes: u.baseLanes | n,
                        cachePool: null,
                        transitions: u.transitions
                    }, l.memoizedState = u, l.childLanes = e.childLanes & ~n, t.memoizedState = Rl, a
                }
                return e = (l = e.child).sibling, a = Os(l, {
                    mode: "visible",
                    children: a.children
                }), 0 === (1 & t.mode) && (a.lanes = n), a.return = t, a.sibling = null, null !== e && (null === (n = t.deletions) ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = a, t.memoizedState = null, a
            }

            function Fl(e, t) {
                return (t = Is({
                    mode: "visible",
                    children: t
                }, e.mode, 0, null)).return = e, e.child = t
            }

            function Ul(e, t, n, r) {
                return null !== r && hi(r), Ki(t, e.child, null, n), (e = Fl(t, t.pendingProps.children)).flags |= 2, t.memoizedState = null, e
            }

            function Bl(e, t, n) {
                e.lanes |= t;
                var r = e.alternate;
                null !== r && (r.lanes |= t), Si(e.return, t, n)
            }

            function Vl(e, t, n, r, a) {
                var i = e.memoizedState;
                null === i ? e.memoizedState = {
                    isBackwards: t,
                    rendering: null,
                    renderingStartTime: 0,
                    last: r,
                    tail: n,
                    tailMode: a
                } : (i.isBackwards = t, i.rendering = null, i.renderingStartTime = 0, i.last = r, i.tail = n, i.tailMode = a)
            }

            function Hl(e, t, n) {
                var r = t.pendingProps,
                    a = r.revealOrder,
                    i = r.tail;
                if (xl(e, t, r.children, n), 0 !== (2 & (r = lo.current))) r = 1 & r | 2, t.flags |= 128;
                else {
                    if (null !== e && 0 !== (128 & e.flags)) e: for (e = t.child; null !== e;) {
                        if (13 === e.tag) null !== e.memoizedState && Bl(e, n, t);
                        else if (19 === e.tag) Bl(e, n, t);
                        else if (null !== e.child) {
                            e.child.return = e, e = e.child;
                            continue
                        }
                        if (e === t) break e;
                        for (; null === e.sibling;) {
                            if (null === e.return || e.return === t) break e;
                            e = e.return
                        }
                        e.sibling.return = e.return, e = e.sibling
                    }
                    r &= 1
                }
                if (Ca(lo, r), 0 === (1 & t.mode)) t.memoizedState = null;
                else switch (a) {
                    case "forwards":
                        for (n = t.child, a = null; null !== n;) null !== (e = n.alternate) && null === uo(e) && (a = n), n = n.sibling;
                        null === (n = a) ? (a = t.child, t.child = null) : (a = n.sibling, n.sibling = null), Vl(t, !1, a, n, i);
                        break;
                    case "backwards":
                        for (n = null, a = t.child, t.child = null; null !== a;) {
                            if (null !== (e = a.alternate) && null === uo(e)) {
                                t.child = a;
                                break
                            }
                            e = a.sibling, a.sibling = n, n = a, a = e
                        }
                        Vl(t, !0, n, null, i);
                        break;
                    case "together":
                        Vl(t, !1, null, null, void 0);
                        break;
                    default:
                        t.memoizedState = null
                }
                return t.child
            }

            function Wl(e, t) {
                0 === (1 & t.mode) && null !== e && (e.alternate = null, t.alternate = null, t.flags |= 2)
            }

            function Ql(e, t, n) {
                if (null !== e && (t.dependencies = e.dependencies), Iu |= t.lanes, 0 === (n & t.childLanes)) return null;
                if (null !== e && t.child !== e.child) throw Error(i(153));
                if (null !== t.child) {
                    for (n = Os(e = t.child, e.pendingProps), t.child = n, n.return = t; null !== e.sibling;) e = e.sibling, (n = n.sibling = Os(e, e.pendingProps)).return = t;
                    n.sibling = null
                }
                return t.child
            }

            function Gl(e, t) {
                if (!ai) switch (e.tailMode) {
                    case "hidden":
                        t = e.tail;
                        for (var n = null; null !== t;) null !== t.alternate && (n = t), t = t.sibling;
                        null === n ? e.tail = null : n.sibling = null;
                        break;
                    case "collapsed":
                        n = e.tail;
                        for (var r = null; null !== n;) null !== n.alternate && (r = n), n = n.sibling;
                        null === r ? t || null === e.tail ? e.tail = null : e.tail.sibling = null : r.sibling = null
                }
            }

            function Xl(e) {
                var t = null !== e.alternate && e.alternate.child === e.child,
                    n = 0,
                    r = 0;
                if (t)
                    for (var a = e.child; null !== a;) n |= a.lanes | a.childLanes, r |= 14680064 & a.subtreeFlags, r |= 14680064 & a.flags, a.return = e, a = a.sibling;
                else
                    for (a = e.child; null !== a;) n |= a.lanes | a.childLanes, r |= a.subtreeFlags, r |= a.flags, a.return = e, a = a.sibling;
                return e.subtreeFlags |= r, e.childLanes = n, t
            }

            function ql(e, t, n) {
                var r = t.pendingProps;
                switch (ti(t), t.tag) {
                    case 2:
                    case 16:
                    case 15:
                    case 0:
                    case 11:
                    case 7:
                    case 8:
                    case 12:
                    case 9:
                    case 14:
                        return Xl(t), null;
                    case 1:
                    case 17:
                        return Ma(t.type) && Aa(), Xl(t), null;
                    case 3:
                        return r = t.stateNode, ao(), Ea(Ta), Ea(ja), co(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), null !== e && null !== e.child || (di(t) ? t.flags |= 4 : null === e || e.memoizedState.isDehydrated && 0 === (256 & t.flags) || (t.flags |= 1024, null !== ii && (ls(ii), ii = null))), Al(e, t), Xl(t), null;
                    case 5:
                        oo(t);
                        var a = no(to.current);
                        if (n = t.type, null !== e && null != t.stateNode) Ol(e, t, n, r, a), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
                        else {
                            if (!r) {
                                if (null === t.stateNode) throw Error(i(166));
                                return Xl(t), null
                            }
                            if (e = no(Zi.current), di(t)) {
                                r = t.stateNode, n = t.type;
                                var o = t.memoizedProps;
                                switch (r[fa] = t, r[pa] = o, e = 0 !== (1 & t.mode), n) {
                                    case "dialog":
                                        Fr("cancel", r), Fr("close", r);
                                        break;
                                    case "iframe":
                                    case "object":
                                    case "embed":
                                        Fr("load", r);
                                        break;
                                    case "video":
                                    case "audio":
                                        for (a = 0; a < Lr.length; a++) Fr(Lr[a], r);
                                        break;
                                    case "source":
                                        Fr("error", r);
                                        break;
                                    case "img":
                                    case "image":
                                    case "link":
                                        Fr("error", r), Fr("load", r);
                                        break;
                                    case "details":
                                        Fr("toggle", r);
                                        break;
                                    case "input":
                                        K(r, o), Fr("invalid", r);
                                        break;
                                    case "select":
                                        r._wrapperState = {
                                            wasMultiple: !!o.multiple
                                        }, Fr("invalid", r);
                                        break;
                                    case "textarea":
                                        ae(r, o), Fr("invalid", r)
                                }
                                for (var u in ye(n, o), a = null, o)
                                    if (o.hasOwnProperty(u)) {
                                        var s = o[u];
                                        "children" === u ? "string" === typeof s ? r.textContent !== s && (!0 !== o.suppressHydrationWarning && Jr(r.textContent, s, e), a = ["children", s]) : "number" === typeof s && r.textContent !== "" + s && (!0 !== o.suppressHydrationWarning && Jr(r.textContent, s, e), a = ["children", "" + s]) : l.hasOwnProperty(u) && null != s && "onScroll" === u && Fr("scroll", r)
                                    } switch (n) {
                                        case "input":
                                            G(r), Z(r, o, !0);
                                            break;
                                        case "textarea":
                                            G(r), oe(r);
                                            break;
                                        case "select":
                                        case "option":
                                            break;
                                        default:
                                            "function" === typeof o.onClick && (r.onclick = Zr)
                                    }
                                r = a, t.updateQueue = r, null !== r && (t.flags |= 4)
                            } else {
                                u = 9 === a.nodeType ? a : a.ownerDocument, "http://www.w3.org/1999/xhtml" === e && (e = le(n)), "http://www.w3.org/1999/xhtml" === e ? "script" === n ? ((e = u.createElement("div")).innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : "string" === typeof r.is ? e = u.createElement(n, {
                                    is: r.is
                                }) : (e = u.createElement(n), "select" === n && (u = e, r.multiple ? u.multiple = !0 : r.size && (u.size = r.size))) : e = u.createElementNS(e, n), e[fa] = t, e[pa] = r, Ml(e, t, !1, !1), t.stateNode = e;
                                e: {
                                    switch (u = be(n, r), n) {
                                        case "dialog":
                                            Fr("cancel", e), Fr("close", e), a = r;
                                            break;
                                        case "iframe":
                                        case "object":
                                        case "embed":
                                            Fr("load", e), a = r;
                                            break;
                                        case "video":
                                        case "audio":
                                            for (a = 0; a < Lr.length; a++) Fr(Lr[a], e);
                                            a = r;
                                            break;
                                        case "source":
                                            Fr("error", e), a = r;
                                            break;
                                        case "img":
                                        case "image":
                                        case "link":
                                            Fr("error", e), Fr("load", e), a = r;
                                            break;
                                        case "details":
                                            Fr("toggle", e), a = r;
                                            break;
                                        case "input":
                                            K(e, r), a = Y(e, r), Fr("invalid", e);
                                            break;
                                        case "option":
                                        default:
                                            a = r;
                                            break;
                                        case "select":
                                            e._wrapperState = {
                                                wasMultiple: !!r.multiple
                                            }, a = I({}, r, {
                                                value: void 0
                                            }), Fr("invalid", e);
                                            break;
                                        case "textarea":
                                            ae(e, r), a = re(e, r), Fr("invalid", e)
                                    }
                                    for (o in ye(n, a), s = a)
                                        if (s.hasOwnProperty(o)) {
                                            var c = s[o];
                                            "style" === o ? ve(e, c) : "dangerouslySetInnerHTML" === o ? null != (c = c ? c.__html : void 0) && de(e, c) : "children" === o ? "string" === typeof c ? ("textarea" !== n || "" !== c) && fe(e, c) : "number" === typeof c && fe(e, "" + c) : "suppressContentEditableWarning" !== o && "suppressHydrationWarning" !== o && "autoFocus" !== o && (l.hasOwnProperty(o) ? null != c && "onScroll" === o && Fr("scroll", e) : null != c && b(e, o, c, u))
                                        } switch (n) {
                                            case "input":
                                                G(e), Z(e, r, !1);
                                                break;
                                            case "textarea":
                                                G(e), oe(e);
                                                break;
                                            case "option":
                                                null != r.value && e.setAttribute("value", "" + W(r.value));
                                                break;
                                            case "select":
                                                e.multiple = !!r.multiple, null != (o = r.value) ? ne(e, !!r.multiple, o, !1) : null != r.defaultValue && ne(e, !!r.multiple, r.defaultValue, !0);
                                                break;
                                            default:
                                                "function" === typeof a.onClick && (e.onclick = Zr)
                                        }
                                    switch (n) {
                                        case "button":
                                        case "input":
                                        case "select":
                                        case "textarea":
                                            r = !!r.autoFocus;
                                            break e;
                                        case "img":
                                            r = !0;
                                            break e;
                                        default:
                                            r = !1
                                    }
                                }
                                r && (t.flags |= 4)
                            }
                            null !== t.ref && (t.flags |= 512, t.flags |= 2097152)
                        }
                        return Xl(t), null;
                    case 6:
                        if (e && null != t.stateNode) Ll(e, t, e.memoizedProps, r);
                        else {
                            if ("string" !== typeof r && null === t.stateNode) throw Error(i(166));
                            if (n = no(to.current), no(Zi.current), di(t)) {
                                if (r = t.stateNode, n = t.memoizedProps, r[fa] = t, (o = r.nodeValue !== n) && null !== (e = ni)) switch (e.tag) {
                                    case 3:
                                        Jr(r.nodeValue, n, 0 !== (1 & e.mode));
                                        break;
                                    case 5:
                                        !0 !== e.memoizedProps.suppressHydrationWarning && Jr(r.nodeValue, n, 0 !== (1 & e.mode))
                                }
                                o && (t.flags |= 4)
                            } else (r = (9 === n.nodeType ? n : n.ownerDocument).createTextNode(r))[fa] = t, t.stateNode = r
                        }
                        return Xl(t), null;
                    case 13:
                        if (Ea(lo), r = t.memoizedState, null === e || null !== e.memoizedState && null !== e.memoizedState.dehydrated) {
                            if (ai && null !== ri && 0 !== (1 & t.mode) && 0 === (128 & t.flags)) fi(), pi(), t.flags |= 98560, o = !1;
                            else if (o = di(t), null !== r && null !== r.dehydrated) {
                                if (null === e) {
                                    if (!o) throw Error(i(318));
                                    if (!(o = null !== (o = t.memoizedState) ? o.dehydrated : null)) throw Error(i(317));
                                    o[fa] = t
                                } else pi(), 0 === (128 & t.flags) && (t.memoizedState = null), t.flags |= 4;
                                Xl(t), o = !1
                            } else null !== ii && (ls(ii), ii = null), o = !0;
                            if (!o) return 65536 & t.flags ? t : null
                        }
                        return 0 !== (128 & t.flags) ? (t.lanes = n, t) : ((r = null !== r) !== (null !== e && null !== e.memoizedState) && r && (t.child.flags |= 8192, 0 !== (1 & t.mode) && (null === e || 0 !== (1 & lo.current) ? 0 === Lu && (Lu = 3) : vs())), null !== t.updateQueue && (t.flags |= 4), Xl(t), null);
                    case 4:
                        return ao(), Al(e, t), null === e && Vr(t.stateNode.containerInfo), Xl(t), null;
                    case 10:
                        return ki(t.type._context), Xl(t), null;
                    case 19:
                        if (Ea(lo), null === (o = t.memoizedState)) return Xl(t), null;
                        if (r = 0 !== (128 & t.flags), null === (u = o.rendering))
                            if (r) Gl(o, !1);
                            else {
                                if (0 !== Lu || null !== e && 0 !== (128 & e.flags))
                                    for (e = t.child; null !== e;) {
                                        if (null !== (u = uo(e))) {
                                            for (t.flags |= 128, Gl(o, !1), null !== (r = u.updateQueue) && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; null !== n;) e = r, (o = n).flags &= 14680066, null === (u = o.alternate) ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = u.childLanes, o.lanes = u.lanes, o.child = u.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = u.memoizedProps, o.memoizedState = u.memoizedState, o.updateQueue = u.updateQueue, o.type = u.type, e = u.dependencies, o.dependencies = null === e ? null : {
                                                lanes: e.lanes,
                                                firstContext: e.firstContext
                                            }), n = n.sibling;
                                            return Ca(lo, 1 & lo.current | 2), t.child
                                        }
                                        e = e.sibling
                                    }
                                null !== o.tail && $e() > Hu && (t.flags |= 128, r = !0, Gl(o, !1), t.lanes = 4194304)
                            }
                        else {
                            if (!r)
                                if (null !== (e = uo(u))) {
                                    if (t.flags |= 128, r = !0, null !== (n = e.updateQueue) && (t.updateQueue = n, t.flags |= 4), Gl(o, !0), null === o.tail && "hidden" === o.tailMode && !u.alternate && !ai) return Xl(t), null
                                } else 2 * $e() - o.renderingStartTime > Hu && 1073741824 !== n && (t.flags |= 128, r = !0, Gl(o, !1), t.lanes = 4194304);
                            o.isBackwards ? (u.sibling = t.child, t.child = u) : (null !== (n = o.last) ? n.sibling = u : t.child = u, o.last = u)
                        }
                        return null !== o.tail ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = $e(), t.sibling = null, n = lo.current, Ca(lo, r ? 1 & n | 2 : 1 & n), t) : (Xl(t), null);
                    case 22:
                    case 23:
                        return fs(), r = null !== t.memoizedState, null !== e && null !== e.memoizedState !== r && (t.flags |= 8192), r && 0 !== (1 & t.mode) ? 0 !== (1073741824 & Au) && (Xl(t), 6 & t.subtreeFlags && (t.flags |= 8192)) : Xl(t), null;
                    case 24:
                    case 25:
                        return null
                }
                throw Error(i(156, t.tag))
            }

            function Yl(e, t) {
                switch (ti(t), t.tag) {
                    case 1:
                        return Ma(t.type) && Aa(), 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
                    case 3:
                        return ao(), Ea(Ta), Ea(ja), co(), 0 !== (65536 & (e = t.flags)) && 0 === (128 & e) ? (t.flags = -65537 & e | 128, t) : null;
                    case 5:
                        return oo(t), null;
                    case 13:
                        if (Ea(lo), null !== (e = t.memoizedState) && null !== e.dehydrated) {
                            if (null === t.alternate) throw Error(i(340));
                            pi()
                        }
                        return 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
                    case 19:
                        return Ea(lo), null;
                    case 4:
                        return ao(), null;
                    case 10:
                        return ki(t.type._context), null;
                    case 22:
                    case 23:
                        return fs(), null;
                    default:
                        return null
                }
            }
            Ml = function (e, t) {
                for (var n = t.child; null !== n;) {
                    if (5 === n.tag || 6 === n.tag) e.appendChild(n.stateNode);
                    else if (4 !== n.tag && null !== n.child) {
                        n.child.return = n, n = n.child;
                        continue
                    }
                    if (n === t) break;
                    for (; null === n.sibling;) {
                        if (null === n.return || n.return === t) return;
                        n = n.return
                    }
                    n.sibling.return = n.return, n = n.sibling
                }
            }, Al = function () { }, Ol = function (e, t, n, r) {
                var a = e.memoizedProps;
                if (a !== r) {
                    e = t.stateNode, no(Zi.current);
                    var i, o = null;
                    switch (n) {
                        case "input":
                            a = Y(e, a), r = Y(e, r), o = [];
                            break;
                        case "select":
                            a = I({}, a, {
                                value: void 0
                            }), r = I({}, r, {
                                value: void 0
                            }), o = [];
                            break;
                        case "textarea":
                            a = re(e, a), r = re(e, r), o = [];
                            break;
                        default:
                            "function" !== typeof a.onClick && "function" === typeof r.onClick && (e.onclick = Zr)
                    }
                    for (c in ye(n, r), n = null, a)
                        if (!r.hasOwnProperty(c) && a.hasOwnProperty(c) && null != a[c])
                            if ("style" === c) {
                                var u = a[c];
                                for (i in u) u.hasOwnProperty(i) && (n || (n = {}), n[i] = "")
                            } else "dangerouslySetInnerHTML" !== c && "children" !== c && "suppressContentEditableWarning" !== c && "suppressHydrationWarning" !== c && "autoFocus" !== c && (l.hasOwnProperty(c) ? o || (o = []) : (o = o || []).push(c, null));
                    for (c in r) {
                        var s = r[c];
                        if (u = null != a ? a[c] : void 0, r.hasOwnProperty(c) && s !== u && (null != s || null != u))
                            if ("style" === c)
                                if (u) {
                                    for (i in u) !u.hasOwnProperty(i) || s && s.hasOwnProperty(i) || (n || (n = {}), n[i] = "");
                                    for (i in s) s.hasOwnProperty(i) && u[i] !== s[i] && (n || (n = {}), n[i] = s[i])
                                } else n || (o || (o = []), o.push(c, n)), n = s;
                            else "dangerouslySetInnerHTML" === c ? (s = s ? s.__html : void 0, u = u ? u.__html : void 0, null != s && u !== s && (o = o || []).push(c, s)) : "children" === c ? "string" !== typeof s && "number" !== typeof s || (o = o || []).push(c, "" + s) : "suppressContentEditableWarning" !== c && "suppressHydrationWarning" !== c && (l.hasOwnProperty(c) ? (null != s && "onScroll" === c && Fr("scroll", e), o || u === s || (o = [])) : (o = o || []).push(c, s))
                    }
                    n && (o = o || []).push("style", n);
                    var c = o;
                    (t.updateQueue = c) && (t.flags |= 4)
                }
            }, Ll = function (e, t, n, r) {
                n !== r && (t.flags |= 4)
            };
            var Kl = !1,
                $l = !1,
                Jl = "function" === typeof WeakSet ? WeakSet : Set,
                Zl = null;

            function eu(e, t) {
                var n = e.ref;
                if (null !== n)
                    if ("function" === typeof n) try {
                        n(null)
                    } catch (r) {
                        Es(e, t, r)
                    } else n.current = null
            }

            function tu(e, t, n) {
                try {
                    n()
                } catch (r) {
                    Es(e, t, r)
                }
            }
            var nu = !1;

            function ru(e, t, n) {
                var r = t.updateQueue;
                if (null !== (r = null !== r ? r.lastEffect : null)) {
                    var a = r = r.next;
                    do {
                        if ((a.tag & e) === e) {
                            var i = a.destroy;
                            a.destroy = void 0, void 0 !== i && tu(t, n, i)
                        }
                        a = a.next
                    } while (a !== r)
                }
            }

            function au(e, t) {
                if (null !== (t = null !== (t = t.updateQueue) ? t.lastEffect : null)) {
                    var n = t = t.next;
                    do {
                        if ((n.tag & e) === e) {
                            var r = n.create;
                            n.destroy = r()
                        }
                        n = n.next
                    } while (n !== t)
                }
            }

            function iu(e) {
                var t = e.ref;
                if (null !== t) {
                    var n = e.stateNode;
                    e.tag, e = n, "function" === typeof t ? t(e) : t.current = e
                }
            }

            function ou(e) {
                var t = e.alternate;
                null !== t && (e.alternate = null, ou(t)), e.child = null, e.deletions = null, e.sibling = null, 5 === e.tag && (null !== (t = e.stateNode) && (delete t[fa], delete t[pa], delete t[ma], delete t[va], delete t[ga])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
            }

            function lu(e) {
                return 5 === e.tag || 3 === e.tag || 4 === e.tag
            }

            function uu(e) {
                e: for (; ;) {
                    for (; null === e.sibling;) {
                        if (null === e.return || lu(e.return)) return null;
                        e = e.return
                    }
                    for (e.sibling.return = e.return, e = e.sibling; 5 !== e.tag && 6 !== e.tag && 18 !== e.tag;) {
                        if (2 & e.flags) continue e;
                        if (null === e.child || 4 === e.tag) continue e;
                        e.child.return = e, e = e.child
                    }
                    if (!(2 & e.flags)) return e.stateNode
                }
            }

            function su(e, t, n) {
                var r = e.tag;
                if (5 === r || 6 === r) e = e.stateNode, t ? 8 === n.nodeType ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (8 === n.nodeType ? (t = n.parentNode).insertBefore(e, n) : (t = n).appendChild(e), null !== (n = n._reactRootContainer) && void 0 !== n || null !== t.onclick || (t.onclick = Zr));
                else if (4 !== r && null !== (e = e.child))
                    for (su(e, t, n), e = e.sibling; null !== e;) su(e, t, n), e = e.sibling
            }

            function cu(e, t, n) {
                var r = e.tag;
                if (5 === r || 6 === r) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
                else if (4 !== r && null !== (e = e.child))
                    for (cu(e, t, n), e = e.sibling; null !== e;) cu(e, t, n), e = e.sibling
            }
            var du = null,
                fu = !1;

            function pu(e, t, n) {
                for (n = n.child; null !== n;) hu(e, t, n), n = n.sibling
            }

            function hu(e, t, n) {
                if (it && "function" === typeof it.onCommitFiberUnmount) try {
                    it.onCommitFiberUnmount(at, n)
                } catch (l) { }
                switch (n.tag) {
                    case 5:
                        $l || eu(n, t);
                    case 6:
                        var r = du,
                            a = fu;
                        du = null, pu(e, t, n), fu = a, null !== (du = r) && (fu ? (e = du, n = n.stateNode, 8 === e.nodeType ? e.parentNode.removeChild(n) : e.removeChild(n)) : du.removeChild(n.stateNode));
                        break;
                    case 18:
                        null !== du && (fu ? (e = du, n = n.stateNode, 8 === e.nodeType ? ua(e.parentNode, n) : 1 === e.nodeType && ua(e, n), Vt(e)) : ua(du, n.stateNode));
                        break;
                    case 4:
                        r = du, a = fu, du = n.stateNode.containerInfo, fu = !0, pu(e, t, n), du = r, fu = a;
                        break;
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                        if (!$l && (null !== (r = n.updateQueue) && null !== (r = r.lastEffect))) {
                            a = r = r.next;
                            do {
                                var i = a,
                                    o = i.destroy;
                                i = i.tag, void 0 !== o && (0 !== (2 & i) || 0 !== (4 & i)) && tu(n, t, o), a = a.next
                            } while (a !== r)
                        }
                        pu(e, t, n);
                        break;
                    case 1:
                        if (!$l && (eu(n, t), "function" === typeof (r = n.stateNode).componentWillUnmount)) try {
                            r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
                        } catch (l) {
                            Es(n, t, l)
                        }
                        pu(e, t, n);
                        break;
                    case 21:
                        pu(e, t, n);
                        break;
                    case 22:
                        1 & n.mode ? ($l = (r = $l) || null !== n.memoizedState, pu(e, t, n), $l = r) : pu(e, t, n);
                        break;
                    default:
                        pu(e, t, n)
                }
            }

            function mu(e) {
                var t = e.updateQueue;
                if (null !== t) {
                    e.updateQueue = null;
                    var n = e.stateNode;
                    null === n && (n = e.stateNode = new Jl), t.forEach((function (t) {
                        var r = Ts.bind(null, e, t);
                        n.has(t) || (n.add(t), t.then(r, r))
                    }))
                }
            }

            function vu(e, t) {
                var n = t.deletions;
                if (null !== n)
                    for (var r = 0; r < n.length; r++) {
                        var a = n[r];
                        try {
                            var o = e,
                                l = t,
                                u = l;
                            e: for (; null !== u;) {
                                switch (u.tag) {
                                    case 5:
                                        du = u.stateNode, fu = !1;
                                        break e;
                                    case 3:
                                    case 4:
                                        du = u.stateNode.containerInfo, fu = !0;
                                        break e
                                }
                                u = u.return
                            }
                            if (null === du) throw Error(i(160));
                            hu(o, l, a), du = null, fu = !1;
                            var s = a.alternate;
                            null !== s && (s.return = null), a.return = null
                        } catch (c) {
                            Es(a, t, c)
                        }
                    }
                if (12854 & t.subtreeFlags)
                    for (t = t.child; null !== t;) gu(t, e), t = t.sibling
            }

            function gu(e, t) {
                var n = e.alternate,
                    r = e.flags;
                switch (e.tag) {
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                        if (vu(t, e), yu(e), 4 & r) {
                            try {
                                ru(3, e, e.return), au(3, e)
                            } catch (v) {
                                Es(e, e.return, v)
                            }
                            try {
                                ru(5, e, e.return)
                            } catch (v) {
                                Es(e, e.return, v)
                            }
                        }
                        break;
                    case 1:
                        vu(t, e), yu(e), 512 & r && null !== n && eu(n, n.return);
                        break;
                    case 5:
                        if (vu(t, e), yu(e), 512 & r && null !== n && eu(n, n.return), 32 & e.flags) {
                            var a = e.stateNode;
                            try {
                                fe(a, "")
                            } catch (v) {
                                Es(e, e.return, v)
                            }
                        }
                        if (4 & r && null != (a = e.stateNode)) {
                            var o = e.memoizedProps,
                                l = null !== n ? n.memoizedProps : o,
                                u = e.type,
                                s = e.updateQueue;
                            if (e.updateQueue = null, null !== s) try {
                                "input" === u && "radio" === o.type && null != o.name && $(a, o), be(u, l);
                                var c = be(u, o);
                                for (l = 0; l < s.length; l += 2) {
                                    var d = s[l],
                                        f = s[l + 1];
                                    "style" === d ? ve(a, f) : "dangerouslySetInnerHTML" === d ? de(a, f) : "children" === d ? fe(a, f) : b(a, d, f, c)
                                }
                                switch (u) {
                                    case "input":
                                        J(a, o);
                                        break;
                                    case "textarea":
                                        ie(a, o);
                                        break;
                                    case "select":
                                        var p = a._wrapperState.wasMultiple;
                                        a._wrapperState.wasMultiple = !!o.multiple;
                                        var h = o.value;
                                        null != h ? ne(a, !!o.multiple, h, !1) : p !== !!o.multiple && (null != o.defaultValue ? ne(a, !!o.multiple, o.defaultValue, !0) : ne(a, !!o.multiple, o.multiple ? [] : "", !1))
                                }
                                a[pa] = o
                            } catch (v) {
                                Es(e, e.return, v)
                            }
                        }
                        break;
                    case 6:
                        if (vu(t, e), yu(e), 4 & r) {
                            if (null === e.stateNode) throw Error(i(162));
                            a = e.stateNode, o = e.memoizedProps;
                            try {
                                a.nodeValue = o
                            } catch (v) {
                                Es(e, e.return, v)
                            }
                        }
                        break;
                    case 3:
                        if (vu(t, e), yu(e), 4 & r && null !== n && n.memoizedState.isDehydrated) try {
                            Vt(t.containerInfo)
                        } catch (v) {
                            Es(e, e.return, v)
                        }
                        break;
                    case 4:
                    default:
                        vu(t, e), yu(e);
                        break;
                    case 13:
                        vu(t, e), yu(e), 8192 & (a = e.child).flags && (o = null !== a.memoizedState, a.stateNode.isHidden = o, !o || null !== a.alternate && null !== a.alternate.memoizedState || (Vu = $e())), 4 & r && mu(e);
                        break;
                    case 22:
                        if (d = null !== n && null !== n.memoizedState, 1 & e.mode ? ($l = (c = $l) || d, vu(t, e), $l = c) : vu(t, e), yu(e), 8192 & r) {
                            if (c = null !== e.memoizedState, (e.stateNode.isHidden = c) && !d && 0 !== (1 & e.mode))
                                for (Zl = e, d = e.child; null !== d;) {
                                    for (f = Zl = d; null !== Zl;) {
                                        switch (h = (p = Zl).child, p.tag) {
                                            case 0:
                                            case 11:
                                            case 14:
                                            case 15:
                                                ru(4, p, p.return);
                                                break;
                                            case 1:
                                                eu(p, p.return);
                                                var m = p.stateNode;
                                                if ("function" === typeof m.componentWillUnmount) {
                                                    r = p, n = p.return;
                                                    try {
                                                        t = r, m.props = t.memoizedProps, m.state = t.memoizedState, m.componentWillUnmount()
                                                    } catch (v) {
                                                        Es(r, n, v)
                                                    }
                                                }
                                                break;
                                            case 5:
                                                eu(p, p.return);
                                                break;
                                            case 22:
                                                if (null !== p.memoizedState) {
                                                    ku(f);
                                                    continue
                                                }
                                        }
                                        null !== h ? (h.return = p, Zl = h) : ku(f)
                                    }
                                    d = d.sibling
                                }
                            e: for (d = null, f = e; ;) {
                                if (5 === f.tag) {
                                    if (null === d) {
                                        d = f;
                                        try {
                                            a = f.stateNode, c ? "function" === typeof (o = a.style).setProperty ? o.setProperty("display", "none", "important") : o.display = "none" : (u = f.stateNode, l = void 0 !== (s = f.memoizedProps.style) && null !== s && s.hasOwnProperty("display") ? s.display : null, u.style.display = me("display", l))
                                        } catch (v) {
                                            Es(e, e.return, v)
                                        }
                                    }
                                } else if (6 === f.tag) {
                                    if (null === d) try {
                                        f.stateNode.nodeValue = c ? "" : f.memoizedProps
                                    } catch (v) {
                                        Es(e, e.return, v)
                                    }
                                } else if ((22 !== f.tag && 23 !== f.tag || null === f.memoizedState || f === e) && null !== f.child) {
                                    f.child.return = f, f = f.child;
                                    continue
                                }
                                if (f === e) break e;
                                for (; null === f.sibling;) {
                                    if (null === f.return || f.return === e) break e;
                                    d === f && (d = null), f = f.return
                                }
                                d === f && (d = null), f.sibling.return = f.return, f = f.sibling
                            }
                        }
                        break;
                    case 19:
                        vu(t, e), yu(e), 4 & r && mu(e);
                    case 21:
                }
            }

            function yu(e) {
                var t = e.flags;
                if (2 & t) {
                    try {
                        e: {
                            for (var n = e.return; null !== n;) {
                                if (lu(n)) {
                                    var r = n;
                                    break e
                                }
                                n = n.return
                            }
                            throw Error(i(160))
                        }
                        switch (r.tag) {
                            case 5:
                                var a = r.stateNode;
                                32 & r.flags && (fe(a, ""), r.flags &= -33), cu(e, uu(e), a);
                                break;
                            case 3:
                            case 4:
                                var o = r.stateNode.containerInfo;
                                su(e, uu(e), o);
                                break;
                            default:
                                throw Error(i(161))
                        }
                    }
                    catch (l) {
                        Es(e, e.return, l)
                    }
                    e.flags &= -3
                }
                4096 & t && (e.flags &= -4097)
            }

            function bu(e, t, n) {
                Zl = e, wu(e, t, n)
            }

            function wu(e, t, n) {
                for (var r = 0 !== (1 & e.mode); null !== Zl;) {
                    var a = Zl,
                        i = a.child;
                    if (22 === a.tag && r) {
                        var o = null !== a.memoizedState || Kl;
                        if (!o) {
                            var l = a.alternate,
                                u = null !== l && null !== l.memoizedState || $l;
                            l = Kl;
                            var s = $l;
                            if (Kl = o, ($l = u) && !s)
                                for (Zl = a; null !== Zl;) u = (o = Zl).child, 22 === o.tag && null !== o.memoizedState ? Su(a) : null !== u ? (u.return = o, Zl = u) : Su(a);
                            for (; null !== i;) Zl = i, wu(i, t, n), i = i.sibling;
                            Zl = a, Kl = l, $l = s
                        }
                        xu(e)
                    } else 0 !== (8772 & a.subtreeFlags) && null !== i ? (i.return = a, Zl = i) : xu(e)
                }
            }

            function xu(e) {
                for (; null !== Zl;) {
                    var t = Zl;
                    if (0 !== (8772 & t.flags)) {
                        var n = t.alternate;
                        try {
                            if (0 !== (8772 & t.flags)) switch (t.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    $l || au(5, t);
                                    break;
                                case 1:
                                    var r = t.stateNode;
                                    if (4 & t.flags && !$l)
                                        if (null === n) r.componentDidMount();
                                        else {
                                            var a = t.elementType === t.type ? n.memoizedProps : vi(t.type, n.memoizedProps);
                                            r.componentDidUpdate(a, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                                        } var o = t.updateQueue;
                                    null !== o && Di(t, o, r);
                                    break;
                                case 3:
                                    var l = t.updateQueue;
                                    if (null !== l) {
                                        if (n = null, null !== t.child) switch (t.child.tag) {
                                            case 5:
                                            case 1:
                                                n = t.child.stateNode
                                        }
                                        Di(t, l, n)
                                    }
                                    break;
                                case 5:
                                    var u = t.stateNode;
                                    if (null === n && 4 & t.flags) {
                                        n = u;
                                        var s = t.memoizedProps;
                                        switch (t.type) {
                                            case "button":
                                            case "input":
                                            case "select":
                                            case "textarea":
                                                s.autoFocus && n.focus();
                                                break;
                                            case "img":
                                                s.src && (n.src = s.src)
                                        }
                                    }
                                    break;
                                case 6:
                                case 4:
                                case 12:
                                case 19:
                                case 17:
                                case 21:
                                case 22:
                                case 23:
                                case 25:
                                    break;
                                case 13:
                                    if (null === t.memoizedState) {
                                        var c = t.alternate;
                                        if (null !== c) {
                                            var d = c.memoizedState;
                                            if (null !== d) {
                                                var f = d.dehydrated;
                                                null !== f && Vt(f)
                                            }
                                        }
                                    }
                                    break;
                                default:
                                    throw Error(i(163))
                            }
                            $l || 512 & t.flags && iu(t)
                        } catch (p) {
                            Es(t, t.return, p)
                        }
                    }
                    if (t === e) {
                        Zl = null;
                        break
                    }
                    if (null !== (n = t.sibling)) {
                        n.return = t.return, Zl = n;
                        break
                    }
                    Zl = t.return
                }
            }

            function ku(e) {
                for (; null !== Zl;) {
                    var t = Zl;
                    if (t === e) {
                        Zl = null;
                        break
                    }
                    var n = t.sibling;
                    if (null !== n) {
                        n.return = t.return, Zl = n;
                        break
                    }
                    Zl = t.return
                }
            }

            function Su(e) {
                for (; null !== Zl;) {
                    var t = Zl;
                    try {
                        switch (t.tag) {
                            case 0:
                            case 11:
                            case 15:
                                var n = t.return;
                                try {
                                    au(4, t)
                                } catch (u) {
                                    Es(t, n, u)
                                }
                                break;
                            case 1:
                                var r = t.stateNode;
                                if ("function" === typeof r.componentDidMount) {
                                    var a = t.return;
                                    try {
                                        r.componentDidMount()
                                    } catch (u) {
                                        Es(t, a, u)
                                    }
                                }
                                var i = t.return;
                                try {
                                    iu(t)
                                } catch (u) {
                                    Es(t, i, u)
                                }
                                break;
                            case 5:
                                var o = t.return;
                                try {
                                    iu(t)
                                } catch (u) {
                                    Es(t, o, u)
                                }
                        }
                    } catch (u) {
                        Es(t, t.return, u)
                    }
                    if (t === e) {
                        Zl = null;
                        break
                    }
                    var l = t.sibling;
                    if (null !== l) {
                        l.return = t.return, Zl = l;
                        break
                    }
                    Zl = t.return
                }
            }
            var _u, Eu = Math.ceil,
                Cu = w.ReactCurrentDispatcher,
                Nu = w.ReactCurrentOwner,
                ju = w.ReactCurrentBatchConfig,
                Tu = 0,
                Pu = null,
                zu = null,
                Mu = 0,
                Au = 0,
                Ou = _a(0),
                Lu = 0,
                Ru = null,
                Iu = 0,
                Du = 0,
                Fu = 0,
                Uu = null,
                Bu = null,
                Vu = 0,
                Hu = 1 / 0,
                Wu = null,
                Qu = !1,
                Gu = null,
                Xu = null,
                qu = !1,
                Yu = null,
                Ku = 0,
                $u = 0,
                Ju = null,
                Zu = -1,
                es = 0;

            function ts() {
                return 0 !== (6 & Tu) ? $e() : -1 !== Zu ? Zu : Zu = $e()
            }

            function ns(e) {
                return 0 === (1 & e.mode) ? 1 : 0 !== (2 & Tu) && 0 !== Mu ? Mu & -Mu : null !== mi.transition ? (0 === es && (es = mt()), es) : 0 !== (e = bt) ? e : e = void 0 === (e = window.event) ? 16 : Kt(e.type)
            }

            function rs(e, t, n, r) {
                if (50 < $u) throw $u = 0, Ju = null, Error(i(185));
                gt(e, n, r), 0 !== (2 & Tu) && e === Pu || (e === Pu && (0 === (2 & Tu) && (Du |= n), 4 === Lu && us(e, Mu)), as(e, r), 1 === n && 0 === Tu && 0 === (1 & t.mode) && (Hu = $e() + 500, Fa && Va()))
            }

            function as(e, t) {
                var n = e.callbackNode;
                ! function (e, t) {
                    for (var n = e.suspendedLanes, r = e.pingedLanes, a = e.expirationTimes, i = e.pendingLanes; 0 < i;) {
                        var o = 31 - ot(i),
                            l = 1 << o,
                            u = a[o]; - 1 === u ? 0 !== (l & n) && 0 === (l & r) || (a[o] = pt(l, t)) : u <= t && (e.expiredLanes |= l), i &= ~l
                    }
                }(e, t);
                var r = ft(e, e === Pu ? Mu : 0);
                if (0 === r) null !== n && qe(n), e.callbackNode = null, e.callbackPriority = 0;
                else if (t = r & -r, e.callbackPriority !== t) {
                    if (null != n && qe(n), 1 === t) 0 === e.tag ? function (e) {
                        Fa = !0, Ba(e)
                    }(ss.bind(null, e)) : Ba(ss.bind(null, e)), oa((function () {
                        0 === (6 & Tu) && Va()
                    })), n = null;
                    else {
                        switch (wt(r)) {
                            case 1:
                                n = Ze;
                                break;
                            case 4:
                                n = et;
                                break;
                            case 16:
                            default:
                                n = tt;
                                break;
                            case 536870912:
                                n = rt
                        }
                        n = Ps(n, is.bind(null, e))
                    }
                    e.callbackPriority = t, e.callbackNode = n
                }
            }

            function is(e, t) {
                if (Zu = -1, es = 0, 0 !== (6 & Tu)) throw Error(i(327));
                var n = e.callbackNode;
                if (Ss() && e.callbackNode !== n) return null;
                var r = ft(e, e === Pu ? Mu : 0);
                if (0 === r) return null;
                if (0 !== (30 & r) || 0 !== (r & e.expiredLanes) || t) t = gs(e, r);
                else {
                    t = r;
                    var a = Tu;
                    Tu |= 2;
                    var o = ms();
                    for (Pu === e && Mu === t || (Wu = null, Hu = $e() + 500, ps(e, t)); ;) try {
                        bs();
                        break
                    } catch (u) {
                        hs(e, u)
                    }
                    xi(), Cu.current = o, Tu = a, null !== zu ? t = 0 : (Pu = null, Mu = 0, t = Lu)
                }
                if (0 !== t) {
                    if (2 === t && (0 !== (a = ht(e)) && (r = a, t = os(e, a))), 1 === t) throw n = Ru, ps(e, 0), us(e, r), as(e, $e()), n;
                    if (6 === t) us(e, r);
                    else {
                        if (a = e.current.alternate, 0 === (30 & r) && ! function (e) {
                            for (var t = e; ;) {
                                if (16384 & t.flags) {
                                    var n = t.updateQueue;
                                    if (null !== n && null !== (n = n.stores))
                                        for (var r = 0; r < n.length; r++) {
                                            var a = n[r],
                                                i = a.getSnapshot;
                                            a = a.value;
                                            try {
                                                if (!lr(i(), a)) return !1
                                            } catch (l) {
                                                return !1
                                            }
                                        }
                                }
                                if (n = t.child, 16384 & t.subtreeFlags && null !== n) n.return = t, t = n;
                                else {
                                    if (t === e) break;
                                    for (; null === t.sibling;) {
                                        if (null === t.return || t.return === e) return !0;
                                        t = t.return
                                    }
                                    t.sibling.return = t.return, t = t.sibling
                                }
                            }
                            return !0
                        }(a) && (2 === (t = gs(e, r)) && (0 !== (o = ht(e)) && (r = o, t = os(e, o))), 1 === t)) throw n = Ru, ps(e, 0), us(e, r), as(e, $e()), n;
                        switch (e.finishedWork = a, e.finishedLanes = r, t) {
                            case 0:
                            case 1:
                                throw Error(i(345));
                            case 2:
                            case 5:
                                ks(e, Bu, Wu);
                                break;
                            case 3:
                                if (us(e, r), (130023424 & r) === r && 10 < (t = Vu + 500 - $e())) {
                                    if (0 !== ft(e, 0)) break;
                                    if (((a = e.suspendedLanes) & r) !== r) {
                                        ts(), e.pingedLanes |= e.suspendedLanes & a;
                                        break
                                    }
                                    e.timeoutHandle = ra(ks.bind(null, e, Bu, Wu), t);
                                    break
                                }
                                ks(e, Bu, Wu);
                                break;
                            case 4:
                                if (us(e, r), (4194240 & r) === r) break;
                                for (t = e.eventTimes, a = -1; 0 < r;) {
                                    var l = 31 - ot(r);
                                    o = 1 << l, (l = t[l]) > a && (a = l), r &= ~o
                                }
                                if (r = a, 10 < (r = (120 > (r = $e() - r) ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * Eu(r / 1960)) - r)) {
                                    e.timeoutHandle = ra(ks.bind(null, e, Bu, Wu), r);
                                    break
                                }
                                ks(e, Bu, Wu);
                                break;
                            default:
                                throw Error(i(329))
                        }
                    }
                }
                return as(e, $e()), e.callbackNode === n ? is.bind(null, e) : null
            }

            function os(e, t) {
                var n = Uu;
                return e.current.memoizedState.isDehydrated && (ps(e, t).flags |= 256), 2 !== (e = gs(e, t)) && (t = Bu, Bu = n, null !== t && ls(t)), e
            }

            function ls(e) {
                null === Bu ? Bu = e : Bu.push.apply(Bu, e)
            }

            function us(e, t) {
                for (t &= ~Fu, t &= ~Du, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
                    var n = 31 - ot(t),
                        r = 1 << n;
                    e[n] = -1, t &= ~r
                }
            }

            function ss(e) {
                if (0 !== (6 & Tu)) throw Error(i(327));
                Ss();
                var t = ft(e, 0);
                if (0 === (1 & t)) return as(e, $e()), null;
                var n = gs(e, t);
                if (0 !== e.tag && 2 === n) {
                    var r = ht(e);
                    0 !== r && (t = r, n = os(e, r))
                }
                if (1 === n) throw n = Ru, ps(e, 0), us(e, t), as(e, $e()), n;
                if (6 === n) throw Error(i(345));
                return e.finishedWork = e.current.alternate, e.finishedLanes = t, ks(e, Bu, Wu), as(e, $e()), null
            }

            function cs(e, t) {
                var n = Tu;
                Tu |= 1;
                try {
                    return e(t)
                } finally {
                    0 === (Tu = n) && (Hu = $e() + 500, Fa && Va())
                }
            }

            function ds(e) {
                null !== Yu && 0 === Yu.tag && 0 === (6 & Tu) && Ss();
                var t = Tu;
                Tu |= 1;
                var n = ju.transition,
                    r = bt;
                try {
                    if (ju.transition = null, bt = 1, e) return e()
                } finally {
                    bt = r, ju.transition = n, 0 === (6 & (Tu = t)) && Va()
                }
            }

            function fs() {
                Au = Ou.current, Ea(Ou)
            }

            function ps(e, t) {
                e.finishedWork = null, e.finishedLanes = 0;
                var n = e.timeoutHandle;
                if (-1 !== n && (e.timeoutHandle = -1, aa(n)), null !== zu)
                    for (n = zu.return; null !== n;) {
                        var r = n;
                        switch (ti(r), r.tag) {
                            case 1:
                                null !== (r = r.type.childContextTypes) && void 0 !== r && Aa();
                                break;
                            case 3:
                                ao(), Ea(Ta), Ea(ja), co();
                                break;
                            case 5:
                                oo(r);
                                break;
                            case 4:
                                ao();
                                break;
                            case 13:
                            case 19:
                                Ea(lo);
                                break;
                            case 10:
                                ki(r.type._context);
                                break;
                            case 22:
                            case 23:
                                fs()
                        }
                        n = n.return
                    }
                if (Pu = e, zu = e = Os(e.current, null), Mu = Au = t, Lu = 0, Ru = null, Fu = Du = Iu = 0, Bu = Uu = null, null !== Ci) {
                    for (t = 0; t < Ci.length; t++)
                        if (null !== (r = (n = Ci[t]).interleaved)) {
                            n.interleaved = null;
                            var a = r.next,
                                i = n.pending;
                            if (null !== i) {
                                var o = i.next;
                                i.next = a, r.next = o
                            }
                            n.pending = r
                        } Ci = null
                }
                return e
            }

            function hs(e, t) {
                for (; ;) {
                    var n = zu;
                    try {
                        if (xi(), fo.current = ol, yo) {
                            for (var r = mo.memoizedState; null !== r;) {
                                var a = r.queue;
                                null !== a && (a.pending = null), r = r.next
                            }
                            yo = !1
                        }
                        if (ho = 0, go = vo = mo = null, bo = !1, wo = 0, Nu.current = null, null === n || null === n.return) {
                            Lu = 1, Ru = t, zu = null;
                            break
                        }
                        e: {
                            var o = e,
                                l = n.return,
                                u = n,
                                s = t;
                            if (t = Mu, u.flags |= 32768, null !== s && "object" === typeof s && "function" === typeof s.then) {
                                var c = s,
                                    d = u,
                                    f = d.tag;
                                if (0 === (1 & d.mode) && (0 === f || 11 === f || 15 === f)) {
                                    var p = d.alternate;
                                    p ? (d.updateQueue = p.updateQueue, d.memoizedState = p.memoizedState, d.lanes = p.lanes) : (d.updateQueue = null, d.memoizedState = null)
                                }
                                var h = gl(l);
                                if (null !== h) {
                                    h.flags &= -257, yl(h, l, u, 0, t), 1 & h.mode && vl(o, c, t), s = c;
                                    var m = (t = h).updateQueue;
                                    if (null === m) {
                                        var v = new Set;
                                        v.add(s), t.updateQueue = v
                                    } else m.add(s);
                                    break e
                                }
                                if (0 === (1 & t)) {
                                    vl(o, c, t), vs();
                                    break e
                                }
                                s = Error(i(426))
                            } else if (ai && 1 & u.mode) {
                                var g = gl(l);
                                if (null !== g) {
                                    0 === (65536 & g.flags) && (g.flags |= 256), yl(g, l, u, 0, t), hi(cl(s, u));
                                    break e
                                }
                            }
                            o = s = cl(s, u),
                                4 !== Lu && (Lu = 2),
                                null === Uu ? Uu = [o] : Uu.push(o),
                                o = l; do {
                                    switch (o.tag) {
                                        case 3:
                                            o.flags |= 65536, t &= -t, o.lanes |= t, Ri(o, hl(0, s, t));
                                            break e;
                                        case 1:
                                            u = s;
                                            var y = o.type,
                                                b = o.stateNode;
                                            if (0 === (128 & o.flags) && ("function" === typeof y.getDerivedStateFromError || null !== b && "function" === typeof b.componentDidCatch && (null === Xu || !Xu.has(b)))) {
                                                o.flags |= 65536, t &= -t, o.lanes |= t, Ri(o, ml(o, u, t));
                                                break e
                                            }
                                    }
                                    o = o.return
                                } while (null !== o)
                        }
                        xs(n)
                    } catch (w) {
                        t = w, zu === n && null !== n && (zu = n = n.return);
                        continue
                    }
                    break
                }
            }

            function ms() {
                var e = Cu.current;
                return Cu.current = ol, null === e ? ol : e
            }

            function vs() {
                0 !== Lu && 3 !== Lu && 2 !== Lu || (Lu = 4), null === Pu || 0 === (268435455 & Iu) && 0 === (268435455 & Du) || us(Pu, Mu)
            }

            function gs(e, t) {
                var n = Tu;
                Tu |= 2;
                var r = ms();
                for (Pu === e && Mu === t || (Wu = null, ps(e, t)); ;) try {
                    ys();
                    break
                } catch (a) {
                    hs(e, a)
                }
                if (xi(), Tu = n, Cu.current = r, null !== zu) throw Error(i(261));
                return Pu = null, Mu = 0, Lu
            }

            function ys() {
                for (; null !== zu;) ws(zu)
            }

            function bs() {
                for (; null !== zu && !Ye();) ws(zu)
            }

            function ws(e) {
                var t = _u(e.alternate, e, Au);
                e.memoizedProps = e.pendingProps, null === t ? xs(e) : zu = t, Nu.current = null
            }

            function xs(e) {
                var t = e;
                do {
                    var n = t.alternate;
                    if (e = t.return, 0 === (32768 & t.flags)) {
                        if (null !== (n = ql(n, t, Au))) return void (zu = n)
                    } else {
                        if (null !== (n = Yl(n, t))) return n.flags &= 32767, void (zu = n);
                        if (null === e) return Lu = 6, void (zu = null);
                        e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null
                    }
                    if (null !== (t = t.sibling)) return void (zu = t);
                    zu = t = e
                } while (null !== t);
                0 === Lu && (Lu = 5)
            }

            function ks(e, t, n) {
                var r = bt,
                    a = ju.transition;
                try {
                    ju.transition = null, bt = 1,
                        function (e, t, n, r) {
                            do {
                                Ss()
                            } while (null !== Yu);
                            if (0 !== (6 & Tu)) throw Error(i(327));
                            n = e.finishedWork;
                            var a = e.finishedLanes;
                            if (null === n) return null;
                            if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(i(177));
                            e.callbackNode = null, e.callbackPriority = 0;
                            var o = n.lanes | n.childLanes;
                            if (function (e, t) {
                                var n = e.pendingLanes & ~t;
                                e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
                                var r = e.eventTimes;
                                for (e = e.expirationTimes; 0 < n;) {
                                    var a = 31 - ot(n),
                                        i = 1 << a;
                                    t[a] = 0, r[a] = -1, e[a] = -1, n &= ~i
                                }
                            }(e, o), e === Pu && (zu = Pu = null, Mu = 0), 0 === (2064 & n.subtreeFlags) && 0 === (2064 & n.flags) || qu || (qu = !0, Ps(tt, (function () {
                                return Ss(), null
                            }))), o = 0 !== (15990 & n.flags), 0 !== (15990 & n.subtreeFlags) || o) {
                                o = ju.transition, ju.transition = null;
                                var l = bt;
                                bt = 1;
                                var u = Tu;
                                Tu |= 4, Nu.current = null,
                                    function (e, t) {
                                        if (ea = Wt, pr(e = fr())) {
                                            if ("selectionStart" in e) var n = {
                                                start: e.selectionStart,
                                                end: e.selectionEnd
                                            };
                                            else e: {
                                                var r = (n = (n = e.ownerDocument) && n.defaultView || window).getSelection && n.getSelection();
                                                if (r && 0 !== r.rangeCount) {
                                                    n = r.anchorNode;
                                                    var a = r.anchorOffset,
                                                        o = r.focusNode;
                                                    r = r.focusOffset;
                                                    try {
                                                        n.nodeType, o.nodeType
                                                    } catch (x) {
                                                        n = null;
                                                        break e
                                                    }
                                                    var l = 0,
                                                        u = -1,
                                                        s = -1,
                                                        c = 0,
                                                        d = 0,
                                                        f = e,
                                                        p = null;
                                                    t: for (; ;) {
                                                        for (var h; f !== n || 0 !== a && 3 !== f.nodeType || (u = l + a), f !== o || 0 !== r && 3 !== f.nodeType || (s = l + r), 3 === f.nodeType && (l += f.nodeValue.length), null !== (h = f.firstChild);) p = f, f = h;
                                                        for (; ;) {
                                                            if (f === e) break t;
                                                            if (p === n && ++c === a && (u = l), p === o && ++d === r && (s = l), null !== (h = f.nextSibling)) break;
                                                            p = (f = p).parentNode
                                                        }
                                                        f = h
                                                    }
                                                    n = -1 === u || -1 === s ? null : {
                                                        start: u,
                                                        end: s
                                                    }
                                                } else n = null
                                            }
                                            n = n || {
                                                start: 0,
                                                end: 0
                                            }
                                        } else n = null;
                                        for (ta = {
                                            focusedElem: e,
                                            selectionRange: n
                                        }, Wt = !1, Zl = t; null !== Zl;)
                                            if (e = (t = Zl).child, 0 !== (1028 & t.subtreeFlags) && null !== e) e.return = t, Zl = e;
                                            else
                                                for (; null !== Zl;) {
                                                    t = Zl;
                                                    try {
                                                        var m = t.alternate;
                                                        if (0 !== (1024 & t.flags)) switch (t.tag) {
                                                            case 0:
                                                            case 11:
                                                            case 15:
                                                            case 5:
                                                            case 6:
                                                            case 4:
                                                            case 17:
                                                                break;
                                                            case 1:
                                                                if (null !== m) {
                                                                    var v = m.memoizedProps,
                                                                        g = m.memoizedState,
                                                                        y = t.stateNode,
                                                                        b = y.getSnapshotBeforeUpdate(t.elementType === t.type ? v : vi(t.type, v), g);
                                                                    y.__reactInternalSnapshotBeforeUpdate = b
                                                                }
                                                                break;
                                                            case 3:
                                                                var w = t.stateNode.containerInfo;
                                                                1 === w.nodeType ? w.textContent = "" : 9 === w.nodeType && w.documentElement && w.removeChild(w.documentElement);
                                                                break;
                                                            default:
                                                                throw Error(i(163))
                                                        }
                                                    } catch (x) {
                                                        Es(t, t.return, x)
                                                    }
                                                    if (null !== (e = t.sibling)) {
                                                        e.return = t.return, Zl = e;
                                                        break
                                                    }
                                                    Zl = t.return
                                                }
                                        m = nu, nu = !1
                                    }(e, n), gu(n, e), hr(ta), Wt = !!ea, ta = ea = null, e.current = n, bu(n, e, a), Ke(), Tu = u, bt = l, ju.transition = o
                            } else e.current = n;
                            if (qu && (qu = !1, Yu = e, Ku = a), o = e.pendingLanes, 0 === o && (Xu = null), function (e) {
                                if (it && "function" === typeof it.onCommitFiberRoot) try {
                                    it.onCommitFiberRoot(at, e, void 0, 128 === (128 & e.current.flags))
                                } catch (t) { }
                            }(n.stateNode), as(e, $e()), null !== t)
                                for (r = e.onRecoverableError, n = 0; n < t.length; n++) a = t[n], r(a.value, {
                                    componentStack: a.stack,
                                    digest: a.digest
                                });
                            if (Qu) throw Qu = !1, e = Gu, Gu = null, e;
                            0 !== (1 & Ku) && 0 !== e.tag && Ss(), o = e.pendingLanes, 0 !== (1 & o) ? e === Ju ? $u++ : ($u = 0, Ju = e) : $u = 0, Va()
                        }(e, t, n, r)
                } finally {
                    ju.transition = a, bt = r
                }
                return null
            }

            function Ss() {
                if (null !== Yu) {
                    var e = wt(Ku),
                        t = ju.transition,
                        n = bt;
                    try {
                        if (ju.transition = null, bt = 16 > e ? 16 : e, null === Yu) var r = !1;
                        else {
                            if (e = Yu, Yu = null, Ku = 0, 0 !== (6 & Tu)) throw Error(i(331));
                            var a = Tu;
                            for (Tu |= 4, Zl = e.current; null !== Zl;) {
                                var o = Zl,
                                    l = o.child;
                                if (0 !== (16 & Zl.flags)) {
                                    var u = o.deletions;
                                    if (null !== u) {
                                        for (var s = 0; s < u.length; s++) {
                                            var c = u[s];
                                            for (Zl = c; null !== Zl;) {
                                                var d = Zl;
                                                switch (d.tag) {
                                                    case 0:
                                                    case 11:
                                                    case 15:
                                                        ru(8, d, o)
                                                }
                                                var f = d.child;
                                                if (null !== f) f.return = d, Zl = f;
                                                else
                                                    for (; null !== Zl;) {
                                                        var p = (d = Zl).sibling,
                                                            h = d.return;
                                                        if (ou(d), d === c) {
                                                            Zl = null;
                                                            break
                                                        }
                                                        if (null !== p) {
                                                            p.return = h, Zl = p;
                                                            break
                                                        }
                                                        Zl = h
                                                    }
                                            }
                                        }
                                        var m = o.alternate;
                                        if (null !== m) {
                                            var v = m.child;
                                            if (null !== v) {
                                                m.child = null;
                                                do {
                                                    var g = v.sibling;
                                                    v.sibling = null, v = g
                                                } while (null !== v)
                                            }
                                        }
                                        Zl = o
                                    }
                                }
                                if (0 !== (2064 & o.subtreeFlags) && null !== l) l.return = o, Zl = l;
                                else e: for (; null !== Zl;) {
                                    if (0 !== (2048 & (o = Zl).flags)) switch (o.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            ru(9, o, o.return)
                                    }
                                    var y = o.sibling;
                                    if (null !== y) {
                                        y.return = o.return, Zl = y;
                                        break e
                                    }
                                    Zl = o.return
                                }
                            }
                            var b = e.current;
                            for (Zl = b; null !== Zl;) {
                                var w = (l = Zl).child;
                                if (0 !== (2064 & l.subtreeFlags) && null !== w) w.return = l, Zl = w;
                                else e: for (l = b; null !== Zl;) {
                                    if (0 !== (2048 & (u = Zl).flags)) try {
                                        switch (u.tag) {
                                            case 0:
                                            case 11:
                                            case 15:
                                                au(9, u)
                                        }
                                    } catch (k) {
                                        Es(u, u.return, k)
                                    }
                                    if (u === l) {
                                        Zl = null;
                                        break e
                                    }
                                    var x = u.sibling;
                                    if (null !== x) {
                                        x.return = u.return, Zl = x;
                                        break e
                                    }
                                    Zl = u.return
                                }
                            }
                            if (Tu = a, Va(), it && "function" === typeof it.onPostCommitFiberRoot) try {
                                it.onPostCommitFiberRoot(at, e)
                            } catch (k) { }
                            r = !0
                        }
                        return r
                    } finally {
                        bt = n, ju.transition = t
                    }
                }
                return !1
            }

            function _s(e, t, n) {
                e = Oi(e, t = hl(0, t = cl(n, t), 1), 1), t = ts(), null !== e && (gt(e, 1, t), as(e, t))
            }

            function Es(e, t, n) {
                if (3 === e.tag) _s(e, e, n);
                else
                    for (; null !== t;) {
                        if (3 === t.tag) {
                            _s(t, e, n);
                            break
                        }
                        if (1 === t.tag) {
                            var r = t.stateNode;
                            if ("function" === typeof t.type.getDerivedStateFromError || "function" === typeof r.componentDidCatch && (null === Xu || !Xu.has(r))) {
                                t = Oi(t, e = ml(t, e = cl(n, e), 1), 1), e = ts(), null !== t && (gt(t, 1, e), as(t, e));
                                break
                            }
                        }
                        t = t.return
                    }
            }

            function Cs(e, t, n) {
                var r = e.pingCache;
                null !== r && r.delete(t), t = ts(), e.pingedLanes |= e.suspendedLanes & n, Pu === e && (Mu & n) === n && (4 === Lu || 3 === Lu && (130023424 & Mu) === Mu && 500 > $e() - Vu ? ps(e, 0) : Fu |= n), as(e, t)
            }

            function Ns(e, t) {
                0 === t && (0 === (1 & e.mode) ? t = 1 : (t = ct, 0 === (130023424 & (ct <<= 1)) && (ct = 4194304)));
                var n = ts();
                null !== (e = Ti(e, t)) && (gt(e, t, n), as(e, n))
            }

            function js(e) {
                var t = e.memoizedState,
                    n = 0;
                null !== t && (n = t.retryLane), Ns(e, n)
            }

            function Ts(e, t) {
                var n = 0;
                switch (e.tag) {
                    case 13:
                        var r = e.stateNode,
                            a = e.memoizedState;
                        null !== a && (n = a.retryLane);
                        break;
                    case 19:
                        r = e.stateNode;
                        break;
                    default:
                        throw Error(i(314))
                }
                null !== r && r.delete(t), Ns(e, n)
            }

            function Ps(e, t) {
                return Xe(e, t)
            }

            function zs(e, t, n, r) {
                this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
            }

            function Ms(e, t, n, r) {
                return new zs(e, t, n, r)
            }

            function As(e) {
                return !(!(e = e.prototype) || !e.isReactComponent)
            }

            function Os(e, t) {
                var n = e.alternate;
                return null === n ? ((n = Ms(e.tag, t, e.key, e.mode)).elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = 14680064 & e.flags, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = null === t ? null : {
                    lanes: t.lanes,
                    firstContext: t.firstContext
                }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
            }

            function Ls(e, t, n, r, a, o) {
                var l = 2;
                if (r = e, "function" === typeof e) As(e) && (l = 1);
                else if ("string" === typeof e) l = 5;
                else e: switch (e) {
                    case S:
                        return Rs(n.children, a, o, t);
                    case _:
                        l = 8, a |= 8;
                        break;
                    case E:
                        return (e = Ms(12, n, t, 2 | a)).elementType = E, e.lanes = o, e;
                    case T:
                        return (e = Ms(13, n, t, a)).elementType = T, e.lanes = o, e;
                    case P:
                        return (e = Ms(19, n, t, a)).elementType = P, e.lanes = o, e;
                    case A:
                        return Is(n, a, o, t);
                    default:
                        if ("object" === typeof e && null !== e) switch (e.$$typeof) {
                            case C:
                                l = 10;
                                break e;
                            case N:
                                l = 9;
                                break e;
                            case j:
                                l = 11;
                                break e;
                            case z:
                                l = 14;
                                break e;
                            case M:
                                l = 16, r = null;
                                break e
                        }
                        throw Error(i(130, null == e ? e : typeof e, ""))
                }
                return (t = Ms(l, n, t, a)).elementType = e, t.type = r, t.lanes = o, t
            }

            function Rs(e, t, n, r) {
                return (e = Ms(7, e, r, t)).lanes = n, e
            }

            function Is(e, t, n, r) {
                return (e = Ms(22, e, r, t)).elementType = A, e.lanes = n, e.stateNode = {
                    isHidden: !1
                }, e
            }

            function Ds(e, t, n) {
                return (e = Ms(6, e, null, t)).lanes = n, e
            }

            function Fs(e, t, n) {
                return (t = Ms(4, null !== e.children ? e.children : [], e.key, t)).lanes = n, t.stateNode = {
                    containerInfo: e.containerInfo,
                    pendingChildren: null,
                    implementation: e.implementation
                }, t
            }

            function Us(e, t, n, r, a) {
                this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = vt(0), this.expirationTimes = vt(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = vt(0), this.identifierPrefix = r, this.onRecoverableError = a, this.mutableSourceEagerHydrationData = null
            }

            function Bs(e, t, n, r, a, i, o, l, u) {
                return e = new Us(e, t, n, l, u), 1 === t ? (t = 1, !0 === i && (t |= 8)) : t = 0, i = Ms(3, null, null, t), e.current = i, i.stateNode = e, i.memoizedState = {
                    element: r,
                    isDehydrated: n,
                    cache: null,
                    transitions: null,
                    pendingSuspenseBoundaries: null
                }, zi(i), e
            }

            function Vs(e) {
                if (!e) return Na;
                e: {
                    if (Ve(e = e._reactInternals) !== e || 1 !== e.tag) throw Error(i(170));
                    var t = e; do {
                        switch (t.tag) {
                            case 3:
                                t = t.stateNode.context;
                                break e;
                            case 1:
                                if (Ma(t.type)) {
                                    t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                                    break e
                                }
                        }
                        t = t.return
                    } while (null !== t);
                    throw Error(i(171))
                }
                if (1 === e.tag) {
                    var n = e.type;
                    if (Ma(n)) return La(e, n, t)
                }
                return t
            }

            function Hs(e, t, n, r, a, i, o, l, u) {
                return (e = Bs(n, r, !0, e, 0, i, 0, l, u)).context = Vs(null), n = e.current, (i = Ai(r = ts(), a = ns(n))).callback = void 0 !== t && null !== t ? t : null, Oi(n, i, a), e.current.lanes = a, gt(e, a, r), as(e, r), e
            }

            function Ws(e, t, n, r) {
                var a = t.current,
                    i = ts(),
                    o = ns(a);
                return n = Vs(n), null === t.context ? t.context = n : t.pendingContext = n, (t = Ai(i, o)).payload = {
                    element: e
                }, null !== (r = void 0 === r ? null : r) && (t.callback = r), null !== (e = Oi(a, t, o)) && (rs(e, a, o, i), Li(e, a, o)), o
            }

            function Qs(e) {
                return (e = e.current).child ? (e.child.tag, e.child.stateNode) : null
            }

            function Gs(e, t) {
                if (null !== (e = e.memoizedState) && null !== e.dehydrated) {
                    var n = e.retryLane;
                    e.retryLane = 0 !== n && n < t ? n : t
                }
            }

            function Xs(e, t) {
                Gs(e, t), (e = e.alternate) && Gs(e, t)
            }
            _u = function (e, t, n) {
                if (null !== e)
                    if (e.memoizedProps !== t.pendingProps || Ta.current) wl = !0;
                    else {
                        if (0 === (e.lanes & n) && 0 === (128 & t.flags)) return wl = !1,
                            function (e, t, n) {
                                switch (t.tag) {
                                    case 3:
                                        Pl(t), pi();
                                        break;
                                    case 5:
                                        io(t);
                                        break;
                                    case 1:
                                        Ma(t.type) && Ra(t);
                                        break;
                                    case 4:
                                        ro(t, t.stateNode.containerInfo);
                                        break;
                                    case 10:
                                        var r = t.type._context,
                                            a = t.memoizedProps.value;
                                        Ca(gi, r._currentValue), r._currentValue = a;
                                        break;
                                    case 13:
                                        if (null !== (r = t.memoizedState)) return null !== r.dehydrated ? (Ca(lo, 1 & lo.current), t.flags |= 128, null) : 0 !== (n & t.child.childLanes) ? Dl(e, t, n) : (Ca(lo, 1 & lo.current), null !== (e = Ql(e, t, n)) ? e.sibling : null);
                                        Ca(lo, 1 & lo.current);
                                        break;
                                    case 19:
                                        if (r = 0 !== (n & t.childLanes), 0 !== (128 & e.flags)) {
                                            if (r) return Hl(e, t, n);
                                            t.flags |= 128
                                        }
                                        if (null !== (a = t.memoizedState) && (a.rendering = null, a.tail = null, a.lastEffect = null), Ca(lo, lo.current), r) break;
                                        return null;
                                    case 22:
                                    case 23:
                                        return t.lanes = 0, El(e, t, n)
                                }
                                return Ql(e, t, n)
                            }(e, t, n);
                        wl = 0 !== (131072 & e.flags)
                    }
                else wl = !1, ai && 0 !== (1048576 & t.flags) && Za(t, Ga, t.index);
                switch (t.lanes = 0, t.tag) {
                    case 2:
                        var r = t.type;
                        Wl(e, t), e = t.pendingProps;
                        var a = za(t, ja.current);
                        _i(t, n), a = _o(null, t, r, e, a, n);
                        var o = Eo();
                        return t.flags |= 1, "object" === typeof a && null !== a && "function" === typeof a.render && void 0 === a.$$typeof ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Ma(r) ? (o = !0, Ra(t)) : o = !1, t.memoizedState = null !== a.state && void 0 !== a.state ? a.state : null, zi(t), a.updater = Bi, t.stateNode = a, a._reactInternals = t, Qi(t, r, e, n), t = Tl(null, t, r, !0, o, n)) : (t.tag = 0, ai && o && ei(t), xl(null, t, a, n), t = t.child), t;
                    case 16:
                        r = t.elementType;
                        e: {
                            switch (Wl(e, t), e = t.pendingProps, r = (a = r._init)(r._payload), t.type = r, a = t.tag = function (e) {
                                if ("function" === typeof e) return As(e) ? 1 : 0;
                                if (void 0 !== e && null !== e) {
                                    if ((e = e.$$typeof) === j) return 11;
                                    if (e === z) return 14
                                }
                                return 2
                            }(r), e = vi(r, e), a) {
                                case 0:
                                    t = Nl(null, t, r, e, n);
                                    break e;
                                case 1:
                                    t = jl(null, t, r, e, n);
                                    break e;
                                case 11:
                                    t = kl(null, t, r, e, n);
                                    break e;
                                case 14:
                                    t = Sl(null, t, r, vi(r.type, e), n);
                                    break e
                            }
                            throw Error(i(306, r, ""))
                        }
                        return t;
                    case 0:
                        return r = t.type, a = t.pendingProps, Nl(e, t, r, a = t.elementType === r ? a : vi(r, a), n);
                    case 1:
                        return r = t.type, a = t.pendingProps, jl(e, t, r, a = t.elementType === r ? a : vi(r, a), n);
                    case 3:
                        e: {
                            if (Pl(t), null === e) throw Error(i(387)); r = t.pendingProps,
                                a = (o = t.memoizedState).element,
                                Mi(e, t),
                                Ii(t, r, null, n);
                            var l = t.memoizedState;
                            if (r = l.element, o.isDehydrated) {
                                if (o = {
                                    element: r,
                                    isDehydrated: !1,
                                    cache: l.cache,
                                    pendingSuspenseBoundaries: l.pendingSuspenseBoundaries,
                                    transitions: l.transitions
                                }, t.updateQueue.baseState = o, t.memoizedState = o, 256 & t.flags) {
                                    t = zl(e, t, r, n, a = cl(Error(i(423)), t));
                                    break e
                                }
                                if (r !== a) {
                                    t = zl(e, t, r, n, a = cl(Error(i(424)), t));
                                    break e
                                }
                                for (ri = sa(t.stateNode.containerInfo.firstChild), ni = t, ai = !0, ii = null, n = $i(t, null, r, n), t.child = n; n;) n.flags = -3 & n.flags | 4096, n = n.sibling
                            } else {
                                if (pi(), r === a) {
                                    t = Ql(e, t, n);
                                    break e
                                }
                                xl(e, t, r, n)
                            }
                            t = t.child
                        }
                        return t;
                    case 5:
                        return io(t), null === e && si(t), r = t.type, a = t.pendingProps, o = null !== e ? e.memoizedProps : null, l = a.children, na(r, a) ? l = null : null !== o && na(r, o) && (t.flags |= 32), Cl(e, t), xl(e, t, l, n), t.child;
                    case 6:
                        return null === e && si(t), null;
                    case 13:
                        return Dl(e, t, n);
                    case 4:
                        return ro(t, t.stateNode.containerInfo), r = t.pendingProps, null === e ? t.child = Ki(t, null, r, n) : xl(e, t, r, n), t.child;
                    case 11:
                        return r = t.type, a = t.pendingProps, kl(e, t, r, a = t.elementType === r ? a : vi(r, a), n);
                    case 7:
                        return xl(e, t, t.pendingProps, n), t.child;
                    case 8:
                    case 12:
                        return xl(e, t, t.pendingProps.children, n), t.child;
                    case 10:
                        e: {
                            if (r = t.type._context, a = t.pendingProps, o = t.memoizedProps, l = a.value, Ca(gi, r._currentValue), r._currentValue = l, null !== o)
                                if (lr(o.value, l)) {
                                    if (o.children === a.children && !Ta.current) {
                                        t = Ql(e, t, n);
                                        break e
                                    }
                                } else
                                    for (null !== (o = t.child) && (o.return = t); null !== o;) {
                                        var u = o.dependencies;
                                        if (null !== u) {
                                            l = o.child;
                                            for (var s = u.firstContext; null !== s;) {
                                                if (s.context === r) {
                                                    if (1 === o.tag) {
                                                        (s = Ai(-1, n & -n)).tag = 2;
                                                        var c = o.updateQueue;
                                                        if (null !== c) {
                                                            var d = (c = c.shared).pending;
                                                            null === d ? s.next = s : (s.next = d.next, d.next = s), c.pending = s
                                                        }
                                                    }
                                                    o.lanes |= n, null !== (s = o.alternate) && (s.lanes |= n), Si(o.return, n, t), u.lanes |= n;
                                                    break
                                                }
                                                s = s.next
                                            }
                                        } else if (10 === o.tag) l = o.type === t.type ? null : o.child;
                                        else if (18 === o.tag) {
                                            if (null === (l = o.return)) throw Error(i(341));
                                            l.lanes |= n, null !== (u = l.alternate) && (u.lanes |= n), Si(l, n, t), l = o.sibling
                                        } else l = o.child;
                                        if (null !== l) l.return = o;
                                        else
                                            for (l = o; null !== l;) {
                                                if (l === t) {
                                                    l = null;
                                                    break
                                                }
                                                if (null !== (o = l.sibling)) {
                                                    o.return = l.return, l = o;
                                                    break
                                                }
                                                l = l.return
                                            }
                                        o = l
                                    }
                            xl(e, t, a.children, n),
                                t = t.child
                        }
                        return t;
                    case 9:
                        return a = t.type, r = t.pendingProps.children, _i(t, n), r = r(a = Ei(a)), t.flags |= 1, xl(e, t, r, n), t.child;
                    case 14:
                        return a = vi(r = t.type, t.pendingProps), Sl(e, t, r, a = vi(r.type, a), n);
                    case 15:
                        return _l(e, t, t.type, t.pendingProps, n);
                    case 17:
                        return r = t.type, a = t.pendingProps, a = t.elementType === r ? a : vi(r, a), Wl(e, t), t.tag = 1, Ma(r) ? (e = !0, Ra(t)) : e = !1, _i(t, n), Hi(t, r, a), Qi(t, r, a, n), Tl(null, t, r, !0, e, n);
                    case 19:
                        return Hl(e, t, n);
                    case 22:
                        return El(e, t, n)
                }
                throw Error(i(156, t.tag))
            };
            var qs = "function" === typeof reportError ? reportError : function (e) {
                console.error(e)
            };

            function Ys(e) {
                this._internalRoot = e
            }

            function Ks(e) {
                this._internalRoot = e
            }

            function $s(e) {
                return !(!e || 1 !== e.nodeType && 9 !== e.nodeType && 11 !== e.nodeType)
            }

            function Js(e) {
                return !(!e || 1 !== e.nodeType && 9 !== e.nodeType && 11 !== e.nodeType && (8 !== e.nodeType || " react-mount-point-unstable " !== e.nodeValue))
            }

            function Zs() { }

            function ec(e, t, n, r, a) {
                var i = n._reactRootContainer;
                if (i) {
                    var o = i;
                    if ("function" === typeof a) {
                        var l = a;
                        a = function () {
                            var e = Qs(o);
                            l.call(e)
                        }
                    }
                    Ws(t, o, e, a)
                } else o = function (e, t, n, r, a) {
                    if (a) {
                        if ("function" === typeof r) {
                            var i = r;
                            r = function () {
                                var e = Qs(o);
                                i.call(e)
                            }
                        }
                        var o = Hs(t, r, e, 0, null, !1, 0, "", Zs);
                        return e._reactRootContainer = o, e[ha] = o.current, Vr(8 === e.nodeType ? e.parentNode : e), ds(), o
                    }
                    for (; a = e.lastChild;) e.removeChild(a);
                    if ("function" === typeof r) {
                        var l = r;
                        r = function () {
                            var e = Qs(u);
                            l.call(e)
                        }
                    }
                    var u = Bs(e, 0, !1, null, 0, !1, 0, "", Zs);
                    return e._reactRootContainer = u, e[ha] = u.current, Vr(8 === e.nodeType ? e.parentNode : e), ds((function () {
                        Ws(t, u, n, r)
                    })), u
                }(n, t, e, a, r);
                return Qs(o)
            }
            Ks.prototype.render = Ys.prototype.render = function (e) {
                var t = this._internalRoot;
                if (null === t) throw Error(i(409));
                Ws(e, t, null, null)
            }, Ks.prototype.unmount = Ys.prototype.unmount = function () {
                var e = this._internalRoot;
                if (null !== e) {
                    this._internalRoot = null;
                    var t = e.containerInfo;
                    ds((function () {
                        Ws(null, e, null, null)
                    })), t[ha] = null
                }
            }, Ks.prototype.unstable_scheduleHydration = function (e) {
                if (e) {
                    var t = _t();
                    e = {
                        blockedOn: null,
                        target: e,
                        priority: t
                    };
                    for (var n = 0; n < At.length && 0 !== t && t < At[n].priority; n++);
                    At.splice(n, 0, e), 0 === n && It(e)
                }
            }, xt = function (e) {
                switch (e.tag) {
                    case 3:
                        var t = e.stateNode;
                        if (t.current.memoizedState.isDehydrated) {
                            var n = dt(t.pendingLanes);
                            0 !== n && (yt(t, 1 | n), as(t, $e()), 0 === (6 & Tu) && (Hu = $e() + 500, Va()))
                        }
                        break;
                    case 13:
                        ds((function () {
                            var t = Ti(e, 1);
                            if (null !== t) {
                                var n = ts();
                                rs(t, e, 1, n)
                            }
                        })), Xs(e, 1)
                }
            }, kt = function (e) {
                if (13 === e.tag) {
                    var t = Ti(e, 134217728);
                    if (null !== t) rs(t, e, 134217728, ts());
                    Xs(e, 134217728)
                }
            }, St = function (e) {
                if (13 === e.tag) {
                    var t = ns(e),
                        n = Ti(e, t);
                    if (null !== n) rs(n, e, t, ts());
                    Xs(e, t)
                }
            }, _t = function () {
                return bt
            }, Et = function (e, t) {
                var n = bt;
                try {
                    return bt = e, t()
                } finally {
                    bt = n
                }
            }, ke = function (e, t, n) {
                switch (t) {
                    case "input":
                        if (J(e, n), t = n.name, "radio" === n.type && null != t) {
                            for (n = e; n.parentNode;) n = n.parentNode;
                            for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                                var r = n[t];
                                if (r !== e && r.form === e.form) {
                                    var a = xa(r);
                                    if (!a) throw Error(i(90));
                                    X(r), J(r, a)
                                }
                            }
                        }
                        break;
                    case "textarea":
                        ie(e, n);
                        break;
                    case "select":
                        null != (t = n.value) && ne(e, !!n.multiple, t, !1)
                }
            }, je = cs, Te = ds;
            var tc = {
                usingClientEntryPoint: !1,
                Events: [ba, wa, xa, Ce, Ne, cs]
            },
                nc = {
                    findFiberByHostInstance: ya,
                    bundleType: 0,
                    version: "18.2.0",
                    rendererPackageName: "react-dom"
                },
                rc = {
                    bundleType: nc.bundleType,
                    version: nc.version,
                    rendererPackageName: nc.rendererPackageName,
                    rendererConfig: nc.rendererConfig,
                    overrideHookState: null,
                    overrideHookStateDeletePath: null,
                    overrideHookStateRenamePath: null,
                    overrideProps: null,
                    overridePropsDeletePath: null,
                    overridePropsRenamePath: null,
                    setErrorHandler: null,
                    setSuspenseHandler: null,
                    scheduleUpdate: null,
                    currentDispatcherRef: w.ReactCurrentDispatcher,
                    findHostInstanceByFiber: function (e) {
                        return null === (e = Qe(e)) ? null : e.stateNode
                    },
                    findFiberByHostInstance: nc.findFiberByHostInstance || function () {
                        return null
                    },
                    findHostInstancesForRefresh: null,
                    scheduleRefresh: null,
                    scheduleRoot: null,
                    setRefreshHandler: null,
                    getCurrentFiber: null,
                    reconcilerVersion: "18.2.0-next-9e3b772b8-20220608"
                };
            if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
                var ac = __REACT_DEVTOOLS_GLOBAL_HOOK__;
                if (!ac.isDisabled && ac.supportsFiber) try {
                    at = ac.inject(rc), it = ac
                } catch (ce) { }
            }
            t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = tc, t.createPortal = function (e, t) {
                var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
                if (!$s(t)) throw Error(i(200));
                return function (e, t, n) {
                    var r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
                    return {
                        $$typeof: k,
                        key: null == r ? null : "" + r,
                        children: e,
                        containerInfo: t,
                        implementation: n
                    }
                }(e, t, null, n)
            }, t.createRoot = function (e, t) {
                if (!$s(e)) throw Error(i(299));
                var n = !1,
                    r = "",
                    a = qs;
                return null !== t && void 0 !== t && (!0 === t.unstable_strictMode && (n = !0), void 0 !== t.identifierPrefix && (r = t.identifierPrefix), void 0 !== t.onRecoverableError && (a = t.onRecoverableError)), t = Bs(e, 1, !1, null, 0, n, 0, r, a), e[ha] = t.current, Vr(8 === e.nodeType ? e.parentNode : e), new Ys(t)
            }, t.findDOMNode = function (e) {
                if (null == e) return null;
                if (1 === e.nodeType) return e;
                var t = e._reactInternals;
                if (void 0 === t) {
                    if ("function" === typeof e.render) throw Error(i(188));
                    throw e = Object.keys(e).join(","), Error(i(268, e))
                }
                return e = null === (e = Qe(t)) ? null : e.stateNode
            }, t.flushSync = function (e) {
                return ds(e)
            }, t.hydrate = function (e, t, n) {
                if (!Js(t)) throw Error(i(200));
                return ec(null, e, t, !0, n)
            }, t.hydrateRoot = function (e, t, n) {
                if (!$s(e)) throw Error(i(405));
                var r = null != n && n.hydratedSources || null,
                    a = !1,
                    o = "",
                    l = qs;
                if (null !== n && void 0 !== n && (!0 === n.unstable_strictMode && (a = !0), void 0 !== n.identifierPrefix && (o = n.identifierPrefix), void 0 !== n.onRecoverableError && (l = n.onRecoverableError)), t = Hs(t, null, e, 1, null != n ? n : null, a, 0, o, l), e[ha] = t.current, Vr(e), r)
                    for (e = 0; e < r.length; e++) a = (a = (n = r[e])._getVersion)(n._source), null == t.mutableSourceEagerHydrationData ? t.mutableSourceEagerHydrationData = [n, a] : t.mutableSourceEagerHydrationData.push(n, a);
                return new Ks(t)
            }, t.render = function (e, t, n) {
                if (!Js(t)) throw Error(i(200));
                return ec(null, e, t, !1, n)
            }, t.unmountComponentAtNode = function (e) {
                if (!Js(e)) throw Error(i(40));
                return !!e._reactRootContainer && (ds((function () {
                    ec(null, null, e, !1, (function () {
                        e._reactRootContainer = null, e[ha] = null
                    }))
                })), !0)
            }, t.unstable_batchedUpdates = cs, t.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
                if (!Js(n)) throw Error(i(200));
                if (null == e || void 0 === e._reactInternals) throw Error(i(38));
                return ec(e, t, n, !1, r)
            }, t.version = "18.2.0-next-9e3b772b8-20220608"
        },
        250: function (e, t, n) {
            "use strict";
            var r = n(164);
            t.createRoot = r.createRoot, t.hydrateRoot = r.hydrateRoot
        },
        164: function (e, t, n) {
            "use strict";
            ! function e() {
                if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE) try {
                    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)
                } catch (t) {
                    console.error(t)
                }
            }(), e.exports = n(463)
        },
        374: function (e, t, n) {
            "use strict";
            var r = n(791),
                a = Symbol.for("react.element"),
                i = Symbol.for("react.fragment"),
                o = Object.prototype.hasOwnProperty,
                l = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                u = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function s(e, t, n) {
                var r, i = {},
                    s = null,
                    c = null;
                for (r in void 0 !== n && (s = "" + n), void 0 !== t.key && (s = "" + t.key), void 0 !== t.ref && (c = t.ref), t) o.call(t, r) && !u.hasOwnProperty(r) && (i[r] = t[r]);
                if (e && e.defaultProps)
                    for (r in t = e.defaultProps) void 0 === i[r] && (i[r] = t[r]);
                return {
                    $$typeof: a,
                    type: e,
                    key: s,
                    ref: c,
                    props: i,
                    _owner: l.current
                }
            }
            t.Fragment = i, t.jsx = s, t.jsxs = s
        },
        117: function (e, t) {
            "use strict";
            var n = Symbol.for("react.element"),
                r = Symbol.for("react.portal"),
                a = Symbol.for("react.fragment"),
                i = Symbol.for("react.strict_mode"),
                o = Symbol.for("react.profiler"),
                l = Symbol.for("react.provider"),
                u = Symbol.for("react.context"),
                s = Symbol.for("react.forward_ref"),
                c = Symbol.for("react.suspense"),
                d = Symbol.for("react.memo"),
                f = Symbol.for("react.lazy"),
                p = Symbol.iterator;
            var h = {
                isMounted: function () {
                    return !1
                },
                enqueueForceUpdate: function () { },
                enqueueReplaceState: function () { },
                enqueueSetState: function () { }
            },
                m = Object.assign,
                v = {};

            function g(e, t, n) {
                this.props = e, this.context = t, this.refs = v, this.updater = n || h
            }

            function y() { }

            function b(e, t, n) {
                this.props = e, this.context = t, this.refs = v, this.updater = n || h
            }
            g.prototype.isReactComponent = {}, g.prototype.setState = function (e, t) {
                if ("object" !== typeof e && "function" !== typeof e && null != e) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
                this.updater.enqueueSetState(this, e, t, "setState")
            }, g.prototype.forceUpdate = function (e) {
                this.updater.enqueueForceUpdate(this, e, "forceUpdate")
            }, y.prototype = g.prototype;
            var w = b.prototype = new y;
            w.constructor = b, m(w, g.prototype), w.isPureReactComponent = !0;
            var x = Array.isArray,
                k = Object.prototype.hasOwnProperty,
                S = {
                    current: null
                },
                _ = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function E(e, t, r) {
                var a, i = {},
                    o = null,
                    l = null;
                if (null != t)
                    for (a in void 0 !== t.ref && (l = t.ref), void 0 !== t.key && (o = "" + t.key), t) k.call(t, a) && !_.hasOwnProperty(a) && (i[a] = t[a]);
                var u = arguments.length - 2;
                if (1 === u) i.children = r;
                else if (1 < u) {
                    for (var s = Array(u), c = 0; c < u; c++) s[c] = arguments[c + 2];
                    i.children = s
                }
                if (e && e.defaultProps)
                    for (a in u = e.defaultProps) void 0 === i[a] && (i[a] = u[a]);
                return {
                    $$typeof: n,
                    type: e,
                    key: o,
                    ref: l,
                    props: i,
                    _owner: S.current
                }
            }

            function C(e) {
                return "object" === typeof e && null !== e && e.$$typeof === n
            }
            var N = /\/+/g;

            function j(e, t) {
                return "object" === typeof e && null !== e && null != e.key ? function (e) {
                    var t = {
                        "=": "=0",
                        ":": "=2"
                    };
                    return "$" + e.replace(/[=:]/g, (function (e) {
                        return t[e]
                    }))
                }("" + e.key) : t.toString(36)
            }

            function T(e, t, a, i, o) {
                var l = typeof e;
                "undefined" !== l && "boolean" !== l || (e = null);
                var u = !1;
                if (null === e) u = !0;
                else switch (l) {
                    case "string":
                    case "number":
                        u = !0;
                        break;
                    case "object":
                        switch (e.$$typeof) {
                            case n:
                            case r:
                                u = !0
                        }
                }
                if (u) return o = o(u = e), e = "" === i ? "." + j(u, 0) : i, x(o) ? (a = "", null != e && (a = e.replace(N, "$&/") + "/"), T(o, t, a, "", (function (e) {
                    return e
                }))) : null != o && (C(o) && (o = function (e, t) {
                    return {
                        $$typeof: n,
                        type: e.type,
                        key: t,
                        ref: e.ref,
                        props: e.props,
                        _owner: e._owner
                    }
                }(o, a + (!o.key || u && u.key === o.key ? "" : ("" + o.key).replace(N, "$&/") + "/") + e)), t.push(o)), 1;
                if (u = 0, i = "" === i ? "." : i + ":", x(e))
                    for (var s = 0; s < e.length; s++) {
                        var c = i + j(l = e[s], s);
                        u += T(l, t, a, c, o)
                    } else if (c = function (e) {
                        return null === e || "object" !== typeof e ? null : "function" === typeof (e = p && e[p] || e["@@iterator"]) ? e : null
                    }(e), "function" === typeof c)
                    for (e = c.call(e), s = 0; !(l = e.next()).done;) u += T(l = l.value, t, a, c = i + j(l, s++), o);
                else if ("object" === l) throw t = String(e), Error("Objects are not valid as a React child (found: " + ("[object Object]" === t ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
                return u
            }

            function P(e, t, n) {
                if (null == e) return e;
                var r = [],
                    a = 0;
                return T(e, r, "", "", (function (e) {
                    return t.call(n, e, a++)
                })), r
            }

            function z(e) {
                if (-1 === e._status) {
                    var t = e._result;
                    (t = t()).then((function (t) {
                        0 !== e._status && -1 !== e._status || (e._status = 1, e._result = t)
                    }), (function (t) {
                        0 !== e._status && -1 !== e._status || (e._status = 2, e._result = t)
                    })), -1 === e._status && (e._status = 0, e._result = t)
                }
                if (1 === e._status) return e._result.default;
                throw e._result
            }
            var M = {
                current: null
            },
                A = {
                    transition: null
                },
                O = {
                    ReactCurrentDispatcher: M,
                    ReactCurrentBatchConfig: A,
                    ReactCurrentOwner: S
                };
            t.Children = {
                map: P,
                forEach: function (e, t, n) {
                    P(e, (function () {
                        t.apply(this, arguments)
                    }), n)
                },
                count: function (e) {
                    var t = 0;
                    return P(e, (function () {
                        t++
                    })), t
                },
                toArray: function (e) {
                    return P(e, (function (e) {
                        return e
                    })) || []
                },
                only: function (e) {
                    if (!C(e)) throw Error("React.Children.only expected to receive a single React element child.");
                    return e
                }
            }, t.Component = g, t.Fragment = a, t.Profiler = o, t.PureComponent = b, t.StrictMode = i, t.Suspense = c, t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = O, t.cloneElement = function (e, t, r) {
                if (null === e || void 0 === e) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
                var a = m({}, e.props),
                    i = e.key,
                    o = e.ref,
                    l = e._owner;
                if (null != t) {
                    if (void 0 !== t.ref && (o = t.ref, l = S.current), void 0 !== t.key && (i = "" + t.key), e.type && e.type.defaultProps) var u = e.type.defaultProps;
                    for (s in t) k.call(t, s) && !_.hasOwnProperty(s) && (a[s] = void 0 === t[s] && void 0 !== u ? u[s] : t[s])
                }
                var s = arguments.length - 2;
                if (1 === s) a.children = r;
                else if (1 < s) {
                    u = Array(s);
                    for (var c = 0; c < s; c++) u[c] = arguments[c + 2];
                    a.children = u
                }
                return {
                    $$typeof: n,
                    type: e.type,
                    key: i,
                    ref: o,
                    props: a,
                    _owner: l
                }
            }, t.createContext = function (e) {
                return (e = {
                    $$typeof: u,
                    _currentValue: e,
                    _currentValue2: e,
                    _threadCount: 0,
                    Provider: null,
                    Consumer: null,
                    _defaultValue: null,
                    _globalName: null
                }).Provider = {
                    $$typeof: l,
                    _context: e
                }, e.Consumer = e
            }, t.createElement = E, t.createFactory = function (e) {
                var t = E.bind(null, e);
                return t.type = e, t
            }, t.createRef = function () {
                return {
                    current: null
                }
            }, t.forwardRef = function (e) {
                return {
                    $$typeof: s,
                    render: e
                }
            }, t.isValidElement = C, t.lazy = function (e) {
                return {
                    $$typeof: f,
                    _payload: {
                        _status: -1,
                        _result: e
                    },
                    _init: z
                }
            }, t.memo = function (e, t) {
                return {
                    $$typeof: d,
                    type: e,
                    compare: void 0 === t ? null : t
                }
            }, t.startTransition = function (e) {
                var t = A.transition;
                A.transition = {};
                try {
                    e()
                } finally {
                    A.transition = t
                }
            }, t.unstable_act = function () {
                throw Error("act(...) is not supported in production builds of React.")
            }, t.useCallback = function (e, t) {
                return M.current.useCallback(e, t)
            }, t.useContext = function (e) {
                return M.current.useContext(e)
            }, t.useDebugValue = function () { }, t.useDeferredValue = function (e) {
                return M.current.useDeferredValue(e)
            }, t.useEffect = function (e, t) {
                return M.current.useEffect(e, t)
            }, t.useId = function () {
                return M.current.useId()
            }, t.useImperativeHandle = function (e, t, n) {
                return M.current.useImperativeHandle(e, t, n)
            }, t.useInsertionEffect = function (e, t) {
                return M.current.useInsertionEffect(e, t)
            }, t.useLayoutEffect = function (e, t) {
                return M.current.useLayoutEffect(e, t)
            }, t.useMemo = function (e, t) {
                return M.current.useMemo(e, t)
            }, t.useReducer = function (e, t, n) {
                return M.current.useReducer(e, t, n)
            }, t.useRef = function (e) {
                return M.current.useRef(e)
            }, t.useState = function (e) {
                return M.current.useState(e)
            }, t.useSyncExternalStore = function (e, t, n) {
                return M.current.useSyncExternalStore(e, t, n)
            }, t.useTransition = function () {
                return M.current.useTransition()
            }, t.version = "18.2.0"
        },
        791: function (e, t, n) {
            "use strict";
            e.exports = n(117)
        },
        184: function (e, t, n) {
            "use strict";
            e.exports = n(374)
        },
        813: function (e, t) {
            "use strict";

            function n(e, t) {
                var n = e.length;
                e.push(t);
                e: for (; 0 < n;) {
                    var r = n - 1 >>> 1,
                        a = e[r];
                    if (!(0 < i(a, t))) break e;
                    e[r] = t, e[n] = a, n = r
                }
            }

            function r(e) {
                return 0 === e.length ? null : e[0]
            }

            function a(e) {
                if (0 === e.length) return null;
                var t = e[0],
                    n = e.pop();
                if (n !== t) {
                    e[0] = n;
                    e: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
                        var l = 2 * (r + 1) - 1,
                            u = e[l],
                            s = l + 1,
                            c = e[s];
                        if (0 > i(u, n)) s < a && 0 > i(c, u) ? (e[r] = c, e[s] = n, r = s) : (e[r] = u, e[l] = n, r = l);
                        else {
                            if (!(s < a && 0 > i(c, n))) break e;
                            e[r] = c, e[s] = n, r = s
                        }
                    }
                }
                return t
            }

            function i(e, t) {
                var n = e.sortIndex - t.sortIndex;
                return 0 !== n ? n : e.id - t.id
            }
            if ("object" === typeof performance && "function" === typeof performance.now) {
                var o = performance;
                t.unstable_now = function () {
                    return o.now()
                }
            } else {
                var l = Date,
                    u = l.now();
                t.unstable_now = function () {
                    return l.now() - u
                }
            }
            var s = [],
                c = [],
                d = 1,
                f = null,
                p = 3,
                h = !1,
                m = !1,
                v = !1,
                g = "function" === typeof setTimeout ? setTimeout : null,
                y = "function" === typeof clearTimeout ? clearTimeout : null,
                b = "undefined" !== typeof setImmediate ? setImmediate : null;

            function w(e) {
                for (var t = r(c); null !== t;) {
                    if (null === t.callback) a(c);
                    else {
                        if (!(t.startTime <= e)) break;
                        a(c), t.sortIndex = t.expirationTime, n(s, t)
                    }
                    t = r(c)
                }
            }

            function x(e) {
                if (v = !1, w(e), !m)
                    if (null !== r(s)) m = !0, A(k);
                    else {
                        var t = r(c);
                        null !== t && O(x, t.startTime - e)
                    }
            }

            function k(e, n) {
                m = !1, v && (v = !1, y(C), C = -1), h = !0;
                var i = p;
                try {
                    for (w(n), f = r(s); null !== f && (!(f.expirationTime > n) || e && !T());) {
                        var o = f.callback;
                        if ("function" === typeof o) {
                            f.callback = null, p = f.priorityLevel;
                            var l = o(f.expirationTime <= n);
                            n = t.unstable_now(), "function" === typeof l ? f.callback = l : f === r(s) && a(s), w(n)
                        } else a(s);
                        f = r(s)
                    }
                    if (null !== f) var u = !0;
                    else {
                        var d = r(c);
                        null !== d && O(x, d.startTime - n), u = !1
                    }
                    return u
                } finally {
                    f = null, p = i, h = !1
                }
            }
            "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
            var S, _ = !1,
                E = null,
                C = -1,
                N = 5,
                j = -1;

            function T() {
                return !(t.unstable_now() - j < N)
            }

            function P() {
                if (null !== E) {
                    var e = t.unstable_now();
                    j = e;
                    var n = !0;
                    try {
                        n = E(!0, e)
                    } finally {
                        n ? S() : (_ = !1, E = null)
                    }
                } else _ = !1
            }
            if ("function" === typeof b) S = function () {
                b(P)
            };
            else if ("undefined" !== typeof MessageChannel) {
                var z = new MessageChannel,
                    M = z.port2;
                z.port1.onmessage = P, S = function () {
                    M.postMessage(null)
                }
            } else S = function () {
                g(P, 0)
            };

            function A(e) {
                E = e, _ || (_ = !0, S())
            }

            function O(e, n) {
                C = g((function () {
                    e(t.unstable_now())
                }), n)
            }
            t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function (e) {
                e.callback = null
            }, t.unstable_continueExecution = function () {
                m || h || (m = !0, A(k))
            }, t.unstable_forceFrameRate = function (e) {
                0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : N = 0 < e ? Math.floor(1e3 / e) : 5
            }, t.unstable_getCurrentPriorityLevel = function () {
                return p
            }, t.unstable_getFirstCallbackNode = function () {
                return r(s)
            }, t.unstable_next = function (e) {
                switch (p) {
                    case 1:
                    case 2:
                    case 3:
                        var t = 3;
                        break;
                    default:
                        t = p
                }
                var n = p;
                p = t;
                try {
                    return e()
                } finally {
                    p = n
                }
            }, t.unstable_pauseExecution = function () { }, t.unstable_requestPaint = function () { }, t.unstable_runWithPriority = function (e, t) {
                switch (e) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    default:
                        e = 3
                }
                var n = p;
                p = e;
                try {
                    return t()
                } finally {
                    p = n
                }
            }, t.unstable_scheduleCallback = function (e, a, i) {
                var o = t.unstable_now();
                switch ("object" === typeof i && null !== i ? i = "number" === typeof (i = i.delay) && 0 < i ? o + i : o : i = o, e) {
                    case 1:
                        var l = -1;
                        break;
                    case 2:
                        l = 250;
                        break;
                    case 5:
                        l = 1073741823;
                        break;
                    case 4:
                        l = 1e4;
                        break;
                    default:
                        l = 5e3
                }
                return e = {
                    id: d++,
                    callback: a,
                    priorityLevel: e,
                    startTime: i,
                    expirationTime: l = i + l,
                    sortIndex: -1
                }, i > o ? (e.sortIndex = i, n(c, e), null === r(s) && e === r(c) && (v ? (y(C), C = -1) : v = !0, O(x, i - o))) : (e.sortIndex = l, n(s, e), m || h || (m = !0, A(k))), e
            }, t.unstable_shouldYield = T, t.unstable_wrapCallback = function (e) {
                var t = p;
                return function () {
                    var n = p;
                    p = t;
                    try {
                        return e.apply(this, arguments)
                    } finally {
                        p = n
                    }
                }
            }
        },
        296: function (e, t, n) {
            "use strict";
            e.exports = n(813)
        },
        480: function (e, t, n) {
            var r = n(115).default,
                a = n(588).default,
                i = n(808).default,
                o = n(655).default,
                l = n(389).default,
                u = n(690).default,
                s = n(728).default;
            "undefined" != typeof self && self, e.exports = function () {
                "use strict";
                var e = {
                    d: function (t, n) {
                        for (var r in n) e.o(n, r) && !e.o(t, r) && Object.defineProperty(t, r, {
                            enumerable: !0,
                            get: n[r]
                        })
                    },
                    o: function (e, t) {
                        return Object.prototype.hasOwnProperty.call(e, t)
                    },
                    r: function (e) {
                        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                            value: "Module"
                        }), Object.defineProperty(e, "__esModule", {
                            value: !0
                        })
                    }
                },
                    t = {};

                function n(e) {
                    for (; e.children && e.children.length > 0;) n(e.children[0]), e.remove(e.children[0]);
                    e.geometry && e.geometry.dispose(), e.material && (Object.keys(e.material).forEach((function (t) {
                        e.material[t] && null !== e.material[t] && "function" == typeof e.material[t].dispose && e.material[t].dispose()
                    })), e.material.dispose())
                }
                e.r(t), e.d(t, {
                    default: function () {
                        return b
                    }
                }), Number.prototype.clamp = function (e, t) {
                    return Math.min(Math.max(this, e), t)
                };
                var c = "object" == typeof window,
                    d = c && window.THREE || {};
                c && !window.VANTA && (window.VANTA = {});
                var f = c && window.VANTA || {};
                f.register = function (e, t) {
                    return f[e] = function (e) {
                        return new t(e)
                    }
                }, f.version = "0.5.24";
                var p = function () {
                    return Array.prototype.unshift.call(arguments, "[VANTA]"), console.error.apply(this, arguments)
                };
                f.VantaBase = function () {
                    function e() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        if (u(this, e), !c) return !1;
                        f.current = this, this.windowMouseMoveWrapper = this.windowMouseMoveWrapper.bind(this), this.windowTouchWrapper = this.windowTouchWrapper.bind(this), this.windowGyroWrapper = this.windowGyroWrapper.bind(this), this.resize = this.resize.bind(this), this.animationLoop = this.animationLoop.bind(this), this.restart = this.restart.bind(this);
                        var n, r, a = "function" == typeof this.getDefaultOptions ? this.getDefaultOptions() : this.defaultOptions;
                        if (this.options = Object.assign({
                            mouseControls: !0,
                            touchControls: !0,
                            gyroControls: !1,
                            minHeight: 200,
                            minWidth: 200,
                            scale: 1,
                            scaleMobile: 1
                        }, a), (t instanceof HTMLElement || "string" == typeof t) && (t = {
                            el: t
                        }), Object.assign(this.options, t), this.options.THREE && (d = this.options.THREE), this.el = this.options.el, null == this.el) p('Instance needs "el" param!');
                        else if (!(this.options.el instanceof HTMLElement)) {
                            var i = this.el;
                            if (this.el = (n = i, document.querySelector(n)), !this.el) return void p("Cannot find element", i)
                        }
                        this.prepareEl(), this.initThree(), this.setSize();
                        try {
                            this.init()
                        } catch (t) {
                            return p("Init error", t), this.renderer && this.renderer.domElement && this.el.removeChild(this.renderer.domElement), void (this.options.backgroundColor && (console.log("[VANTA] Falling back to backgroundColor"), this.el.style.background = (r = this.options.backgroundColor, "number" == typeof r ? "#" + ("00000" + r.toString(16)).slice(-6) : r)))
                        }
                        this.initMouse(), this.resize(), this.animationLoop();
                        var o = window.addEventListener;
                        o("resize", this.resize), window.requestAnimationFrame(this.resize), this.options.mouseControls && (o("scroll", this.windowMouseMoveWrapper), o("mousemove", this.windowMouseMoveWrapper)), this.options.touchControls && (o("touchstart", this.windowTouchWrapper), o("touchmove", this.windowTouchWrapper)), this.options.gyroControls && o("deviceorientation", this.windowGyroWrapper)
                    }
                    return s(e, [{
                        key: "setOptions",
                        value: function () {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            Object.assign(this.options, e), this.triggerMouseMove()
                        }
                    }, {
                        key: "prepareEl",
                        value: function () {
                            var e, t;
                            if ("undefined" != typeof Node && Node.TEXT_NODE)
                                for (e = 0; e < this.el.childNodes.length; e++) {
                                    var n = this.el.childNodes[e];
                                    if (n.nodeType === Node.TEXT_NODE) {
                                        var r = document.createElement("span");
                                        r.textContent = n.textContent, n.parentElement.insertBefore(r, n), n.remove()
                                    }
                                }
                            for (e = 0; e < this.el.children.length; e++) t = this.el.children[e], "static" === getComputedStyle(t).position && (t.style.position = "relative"), "auto" === getComputedStyle(t).zIndex && (t.style.zIndex = 1);
                            "static" === getComputedStyle(this.el).position && (this.el.style.position = "relative")
                        }
                    }, {
                        key: "applyCanvasStyles",
                        value: function (e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            Object.assign(e.style, {
                                position: "absolute",
                                zIndex: 0,
                                top: 0,
                                left: 0,
                                background: ""
                            }), Object.assign(e.style, t), e.classList.add("vanta-canvas")
                        }
                    }, {
                        key: "initThree",
                        value: function () {
                            d.WebGLRenderer ? (this.renderer = new d.WebGLRenderer({
                                alpha: !0,
                                antialias: !0
                            }), this.el.appendChild(this.renderer.domElement), this.applyCanvasStyles(this.renderer.domElement), isNaN(this.options.backgroundAlpha) && (this.options.backgroundAlpha = 1), this.scene = new d.Scene) : console.warn("[VANTA] No THREE defined on window")
                        }
                    }, {
                        key: "getCanvasElement",
                        value: function () {
                            return this.renderer ? this.renderer.domElement : this.p5renderer ? this.p5renderer.canvas : void 0
                        }
                    }, {
                        key: "getCanvasRect",
                        value: function () {
                            var e = this.getCanvasElement();
                            return !!e && e.getBoundingClientRect()
                        }
                    }, {
                        key: "windowMouseMoveWrapper",
                        value: function (e) {
                            var t = this.getCanvasRect();
                            if (!t) return !1;
                            var n = e.clientX - t.left,
                                r = e.clientY - t.top;
                            n >= 0 && r >= 0 && n <= t.width && r <= t.height && (this.mouseX = n, this.mouseY = r, this.options.mouseEase || this.triggerMouseMove(n, r))
                        }
                    }, {
                        key: "windowTouchWrapper",
                        value: function (e) {
                            var t = this.getCanvasRect();
                            if (!t) return !1;
                            if (1 === e.touches.length) {
                                var n = e.touches[0].clientX - t.left,
                                    r = e.touches[0].clientY - t.top;
                                n >= 0 && r >= 0 && n <= t.width && r <= t.height && (this.mouseX = n, this.mouseY = r, this.options.mouseEase || this.triggerMouseMove(n, r))
                            }
                        }
                    }, {
                        key: "windowGyroWrapper",
                        value: function (e) {
                            var t = this.getCanvasRect();
                            if (!t) return !1;
                            var n = Math.round(2 * e.alpha) - t.left,
                                r = Math.round(2 * e.beta) - t.top;
                            n >= 0 && r >= 0 && n <= t.width && r <= t.height && (this.mouseX = n, this.mouseY = r, this.options.mouseEase || this.triggerMouseMove(n, r))
                        }
                    }, {
                        key: "triggerMouseMove",
                        value: function (e, t) {
                            void 0 === e && void 0 === t && (this.options.mouseEase ? (e = this.mouseEaseX, t = this.mouseEaseY) : (e = this.mouseX, t = this.mouseY)), this.uniforms && (this.uniforms.iMouse.value.x = e / this.scale, this.uniforms.iMouse.value.y = t / this.scale);
                            var n = e / this.width,
                                r = t / this.height;
                            "function" == typeof this.onMouseMove && this.onMouseMove(n, r)
                        }
                    }, {
                        key: "setSize",
                        value: function () {
                            this.scale || (this.scale = 1), "undefined" != typeof navigator && (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 600) && this.options.scaleMobile ? this.scale = this.options.scaleMobile : this.options.scale && (this.scale = this.options.scale), this.width = Math.max(this.el.offsetWidth, this.options.minWidth), this.height = Math.max(this.el.offsetHeight, this.options.minHeight)
                        }
                    }, {
                        key: "initMouse",
                        value: function () {
                            (!this.mouseX && !this.mouseY || this.mouseX === this.options.minWidth / 2 && this.mouseY === this.options.minHeight / 2) && (this.mouseX = this.width / 2, this.mouseY = this.height / 2, this.triggerMouseMove(this.mouseX, this.mouseY))
                        }
                    }, {
                        key: "resize",
                        value: function () {
                            this.setSize(), this.camera && (this.camera.aspect = this.width / this.height, "function" == typeof this.camera.updateProjectionMatrix && this.camera.updateProjectionMatrix()), this.renderer && (this.renderer.setSize(this.width, this.height), this.renderer.setPixelRatio(window.devicePixelRatio / this.scale)), "function" == typeof this.onResize && this.onResize()
                        }
                    }, {
                        key: "isOnScreen",
                        value: function () {
                            var e = this.el.offsetHeight,
                                t = this.el.getBoundingClientRect(),
                                n = window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop,
                                r = t.top + n;
                            return r - window.innerHeight <= n && n <= r + e
                        }
                    }, {
                        key: "animationLoop",
                        value: function () {
                            this.t || (this.t = 0), this.t2 || (this.t2 = 0);
                            var e = performance.now();
                            if (this.prevNow) {
                                var t = (e - this.prevNow) / (1e3 / 60);
                                t = Math.max(.2, Math.min(t, 5)), this.t += t, this.t2 += (this.options.speed || 1) * t, this.uniforms && (this.uniforms.iTime.value = .016667 * this.t2)
                            }
                            return this.prevNow = e, this.options.mouseEase && (this.mouseEaseX = this.mouseEaseX || this.mouseX || 0, this.mouseEaseY = this.mouseEaseY || this.mouseY || 0, Math.abs(this.mouseEaseX - this.mouseX) + Math.abs(this.mouseEaseY - this.mouseY) > .1 && (this.mouseEaseX += .05 * (this.mouseX - this.mouseEaseX), this.mouseEaseY += .05 * (this.mouseY - this.mouseEaseY), this.triggerMouseMove(this.mouseEaseX, this.mouseEaseY))), (this.isOnScreen() || this.options.forceAnimate) && ("function" == typeof this.onUpdate && this.onUpdate(), this.scene && this.camera && (this.renderer.render(this.scene, this.camera), this.renderer.setClearColor(this.options.backgroundColor, this.options.backgroundAlpha)), this.fps && this.fps.update && this.fps.update(), "function" == typeof this.afterRender && this.afterRender()), this.req = window.requestAnimationFrame(this.animationLoop)
                        }
                    }, {
                        key: "restart",
                        value: function () {
                            if (this.scene)
                                for (; this.scene.children.length;) this.scene.remove(this.scene.children[0]);
                            "function" == typeof this.onRestart && this.onRestart(), this.init()
                        }
                    }, {
                        key: "init",
                        value: function () {
                            "function" == typeof this.onInit && this.onInit()
                        }
                    }, {
                        key: "destroy",
                        value: function () {
                            "function" == typeof this.onDestroy && this.onDestroy();
                            var e = window.removeEventListener;
                            e("touchstart", this.windowTouchWrapper), e("touchmove", this.windowTouchWrapper), e("scroll", this.windowMouseMoveWrapper), e("mousemove", this.windowMouseMoveWrapper), e("deviceorientation", this.windowGyroWrapper), e("resize", this.resize), window.cancelAnimationFrame(this.req);
                            var t = this.scene;
                            t && t.children && n(t), this.renderer && (this.renderer.domElement && this.el.removeChild(this.renderer.domElement), this.renderer = null, this.scene = null), f.current === this && (f.current = null)
                        }
                    }]), e
                }();
                var h = f.VantaBase,
                    m = "object" == typeof window && window.THREE,
                    v = function (e) {
                        o(n, e);
                        var t = l(n);

                        function n(e) {
                            var a;
                            return u(this, n), (m = e.THREE || m).Color.prototype.toVector = function () {
                                return new m.Vector3(this.r, this.g, this.b)
                            }, (a = t.call(this, e)).updateUniforms = a.updateUniforms.bind(r(a)), a
                        }
                        return s(n, [{
                            key: "init",
                            value: function () {
                                this.mode = "shader", this.uniforms = {
                                    iTime: {
                                        type: "f",
                                        value: 1
                                    },
                                    iResolution: {
                                        type: "v2",
                                        value: new m.Vector2(1, 1)
                                    },
                                    iDpr: {
                                        type: "f",
                                        value: window.devicePixelRatio || 1
                                    },
                                    iMouse: {
                                        type: "v2",
                                        value: new m.Vector2(this.mouseX || 0, this.mouseY || 0)
                                    }
                                }, a(i(n.prototype), "init", this).call(this), this.fragmentShader && this.initBasicShader()
                            }
                        }, {
                            key: "setOptions",
                            value: function (e) {
                                a(i(n.prototype), "setOptions", this).call(this, e), this.updateUniforms()
                            }
                        }, {
                            key: "initBasicShader",
                            value: function () {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.fragmentShader,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.vertexShader;
                                t || (t = "uniform float uTime;\nuniform vec2 uResolution;\nvoid main() {\n  gl_Position = vec4( position, 1.0 );\n}"), this.updateUniforms(), "function" == typeof this.valuesChanger && this.valuesChanger();
                                var n = new m.ShaderMaterial({
                                    uniforms: this.uniforms,
                                    vertexShader: t,
                                    fragmentShader: e
                                }),
                                    r = this.options.texturePath;
                                r && (this.uniforms.iTex = {
                                    type: "t",
                                    value: (new m.TextureLoader).load(r)
                                });
                                var a = new m.Mesh(new m.PlaneGeometry(2, 2), n);
                                this.scene.add(a), this.camera = new m.Camera, this.camera.position.z = 1
                            }
                        }, {
                            key: "updateUniforms",
                            value: function () {
                                var e, t, n = {};
                                for (e in this.options) t = this.options[e], -1 !== e.toLowerCase().indexOf("color") ? n[e] = {
                                    type: "v3",
                                    value: new m.Color(t).toVector()
                                } : "number" == typeof t && (n[e] = {
                                    type: "f",
                                    value: t
                                });
                                return Object.assign(this.uniforms, n)
                            }
                        }, {
                            key: "resize",
                            value: function () {
                                a(i(n.prototype), "resize", this).call(this), this.uniforms.iResolution.value.x = this.width / this.scale, this.uniforms.iResolution.value.y = this.height / this.scale
                            }
                        }]), n
                    }(h),
                    g = "object" == typeof window && window.THREE,
                    y = function (e) {
                        o(n, e);
                        var t = l(n);

                        function n(e) {
                            return u(this, n), g = e.THREE || g, t.call(this, e)
                        }
                        return s(n, [{
                            key: "getDefaultOptions",
                            value: function () {
                                return {
                                    baseColor: 6745,
                                    color2: 15918901,
                                    backgroundColor: 1251907,
                                    amplitudeFactor: 1,
                                    ringFactor: 1,
                                    rotationFactor: 1,
                                    xOffset: 0,
                                    yOffset: 0,
                                    size: 1,
                                    speed: 1,
                                    mouseEase: !0,
                                    scaleMobile: 1,
                                    scale: 1
                                }
                            }
                        }, {
                            key: "onInit",
                            value: function () {
                                var e = {
                                    minFilter: g.LinearFilter,
                                    magFilter: g.LinearFilter,
                                    format: g.RGBFormat
                                },
                                    t = this.width * window.devicePixelRatio / this.scale,
                                    n = this.height * window.devicePixelRatio / this.scale;
                                this.bufferTarget = new g.WebGLRenderTarget(t, n, e), this.bufferFeedback = new g.WebGLRenderTarget(t, n, e)
                            }
                        }, {
                            key: "initBasicShader",
                            value: function (e, t) {
                                a(i(n.prototype), "initBasicShader", this).call(this, e, t), this.uniforms.iBuffer = {
                                    type: "t",
                                    value: this.bufferTarget.texture
                                }
                            }
                        }, {
                            key: "onUpdate",
                            value: function () {
                                this.uniforms.iBuffer.value = this.bufferFeedback.texture;
                                var e = this.renderer;
                                e.setRenderTarget(this.bufferTarget), e.render(this.scene, this.camera), e.setRenderTarget(null), e.clear();
                                var t = this.bufferTarget;
                                this.bufferTarget = this.bufferFeedback, this.bufferFeedback = t
                            }
                        }, {
                            key: "onResize",
                            value: function () {
                                if (this.bufferTarget) {
                                    var e = this.width * window.devicePixelRatio / this.scale,
                                        t = this.height * window.devicePixelRatio / this.scale;
                                    this.bufferTarget.setSize(e, t), this.bufferFeedback.setSize(e, t)
                                }
                            }
                        }, {
                            key: "onDestroy",
                            value: function () {
                                this.bufferTarget = null, this.bufferFeedback = null
                            }
                        }]), n
                    }(v),
                    b = f.register("HALO", y);
                return y.prototype.fragmentShader = "uniform vec2 iResolution;\nuniform float iDpr;\nuniform vec2 iMouse;\nuniform float iTime;\n\nuniform float xOffset;\nuniform float yOffset;\nuniform vec3 baseColor;\nuniform vec3 color2;\nuniform vec3 backgroundColor;\nuniform float size;\nuniform float shape;\nuniform float ringFactor;\nuniform float rotationFactor;\nuniform float amplitudeFactor;\n\nuniform sampler2D iBuffer;\nuniform sampler2D iTex;\nconst float PI = 3.14159265359;\n\n// float length2(vec2 p) { return dot(p, p); }\n\n// float noise(vec2 p){\n//   return fract(sin(fract(sin(p.x) * (43.13311)) + p.y) * 31.0011);\n// }\n\n// float worley(vec2 p) {\n//     float d = 1e30;\n//     for (int xo = -1; xo <= 1; ++xo) {\n//         for (int yo = -1; yo <= 1; ++yo) {\n//             vec2 tp = floor(p) + vec2(xo, yo);\n//             d = min(d, length2(p - tp - vec2(noise(tp))));\n//         }\n//     }\n//     vec2 uv = gl_FragCoord.xy / iResolution.xy;\n//     float timeOffset =  0.15 * sin(iTime * 2.0 + 10.0*(uv.x - uv.y));\n//     return 3.0*exp(-4.0*abs(2.0*d - 1.0 + timeOffset));\n// }\n\n// float fworley(vec2 p) {\n//     return sqrt(\n//     1.1 * // light\n//     worley(p*10. + .3 + iTime*.0525) *\n//     sqrt(worley(p * 50. / size + 0.1 + iTime * -0.75)) *\n//     4.1 *\n//     sqrt(sqrt(worley(p * -1. + 9.3))));\n// }\n\nvec4 j2hue(float c) {\n  return .5+.5*cos(6.28*c+vec4(0,-2.1,2.1,0));\n}\n\nvec3 permute(vec3 x) { return mod(((x*34.0)+1.0)*x, 289.0); }\n\nfloat snoise(vec2 v){\n  const vec4 C = vec4(0.211324865405187, 0.366025403784439,\n           -0.577350269189626, 0.024390243902439);\n  vec2 i  = floor(v + dot(v, C.yy) );\n  vec2 x0 = v -   i + dot(i, C.xx);\n  vec2 i1;\n  i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);\n  vec4 x12 = x0.xyxy + C.xxzz;\n  x12.xy -= i1;\n  i = mod(i, 289.0);\n  vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 ))\n  + i.x + vec3(0.0, i1.x, 1.0 ));\n  vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy),\n    dot(x12.zw,x12.zw)), 0.0);\n  m = m*m ;\n  m = m*m ;\n  vec3 x = 2.0 * fract(p * C.www) - 1.0;\n  vec3 h = abs(x) - 0.5;\n  vec3 ox = floor(x + 0.5);\n  vec3 a0 = x - ox;\n  m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );\n  vec3 g;\n  g.x  = a0.x  * x0.x  + h.x  * x0.y;\n  g.yz = a0.yz * x12.xz + h.yz * x12.yw;\n  return 130.0 * dot(m, g);\n}\n\nvec2 sincos( float x ){return vec2(sin(x), cos(x));}\nvec2 rotate2d(vec2 uv, float phi){vec2 t = sincos(phi); return vec2(uv.x*t.y-uv.y*t.x, uv.x*t.x+uv.y*t.y);}\nvec3 rotate3d(vec3 p, vec3 v, float phi){ v = normalize(v); vec2 t = sincos(-phi); float s = t.x, c = t.y, x =-v.x, y =-v.y, z =-v.z; mat4 M = mat4(x*x*(1.-c)+c,x*y*(1.-c)-z*s,x*z*(1.-c)+y*s,0.,y*x*(1.-c)+z*s,y*y*(1.-c)+c,y*z*(1.-c)-x*s,0.,z*x*(1.-c)-y*s,z*y*(1.-c)+x*s,z*z*(1.-c)+c,0.,0.,0.,0.,1.);return (vec4(p,1.)*M).xyz;}\n\n// Classic Perlin 3D Noise\n// by Stefan Gustavson\nvec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}\nvec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}\nvec3 fade(vec3 t) {return t*t*t*(t*(t*6.0-15.0)+10.0);}\nfloat p3d(vec3 P){\n  vec3 Pi0 = floor(P); // Integer part for indexing\n  vec3 Pi1 = Pi0 + vec3(1.0); // Integer part + 1\n  Pi0 = mod(Pi0, 289.0);\n  Pi1 = mod(Pi1, 289.0);\n  vec3 Pf0 = fract(P); // Fractional part for interpolation\n  vec3 Pf1 = Pf0 - vec3(1.0); // Fractional part - 1.0\n  vec4 ix = vec4(Pi0.x, Pi1.x, Pi0.x, Pi1.x);\n  vec4 iy = vec4(Pi0.yy, Pi1.yy);\n  vec4 iz0 = Pi0.zzzz;\n  vec4 iz1 = Pi1.zzzz;\n\n  vec4 ixy = permute(permute(ix) + iy);\n  vec4 ixy0 = permute(ixy + iz0);\n  vec4 ixy1 = permute(ixy + iz1);\n\n  vec4 gx0 = ixy0 / 7.0;\n  vec4 gy0 = fract(floor(gx0) / 7.0) - 0.5;\n  gx0 = fract(gx0);\n  vec4 gz0 = vec4(0.5) - abs(gx0) - abs(gy0);\n  vec4 sz0 = step(gz0, vec4(0.0));\n  gx0 -= sz0 * (step(0.0, gx0) - 0.5);\n  gy0 -= sz0 * (step(0.0, gy0) - 0.5);\n\n  vec4 gx1 = ixy1 / 7.0;\n  vec4 gy1 = fract(floor(gx1) / 7.0) - 0.5;\n  gx1 = fract(gx1);\n  vec4 gz1 = vec4(0.5) - abs(gx1) - abs(gy1);\n  vec4 sz1 = step(gz1, vec4(0.0));\n  gx1 -= sz1 * (step(0.0, gx1) - 0.5);\n  gy1 -= sz1 * (step(0.0, gy1) - 0.5);\n\n  vec3 g000 = vec3(gx0.x,gy0.x,gz0.x);\n  vec3 g100 = vec3(gx0.y,gy0.y,gz0.y);\n  vec3 g010 = vec3(gx0.z,gy0.z,gz0.z);\n  vec3 g110 = vec3(gx0.w,gy0.w,gz0.w);\n  vec3 g001 = vec3(gx1.x,gy1.x,gz1.x);\n  vec3 g101 = vec3(gx1.y,gy1.y,gz1.y);\n  vec3 g011 = vec3(gx1.z,gy1.z,gz1.z);\n  vec3 g111 = vec3(gx1.w,gy1.w,gz1.w);\n\n  vec4 norm0 = taylorInvSqrt(vec4(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));\n  g000 *= norm0.x;\n  g010 *= norm0.y;\n  g100 *= norm0.z;\n  g110 *= norm0.w;\n  vec4 norm1 = taylorInvSqrt(vec4(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));\n  g001 *= norm1.x;\n  g011 *= norm1.y;\n  g101 *= norm1.z;\n  g111 *= norm1.w;\n\n  float n000 = dot(g000, Pf0);\n  float n100 = dot(g100, vec3(Pf1.x, Pf0.yz));\n  float n010 = dot(g010, vec3(Pf0.x, Pf1.y, Pf0.z));\n  float n110 = dot(g110, vec3(Pf1.xy, Pf0.z));\n  float n001 = dot(g001, vec3(Pf0.xy, Pf1.z));\n  float n101 = dot(g101, vec3(Pf1.x, Pf0.y, Pf1.z));\n  float n011 = dot(g011, vec3(Pf0.x, Pf1.yz));\n  float n111 = dot(g111, Pf1);\n\n  vec3 fade_xyz = fade(Pf0);\n  vec4 n_z = mix(vec4(n000, n100, n010, n110), vec4(n001, n101, n011, n111), fade_xyz.z);\n  vec2 n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);\n  float n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x);\n  return 2.2 * n_xyz;\n}\n\n\nvoid main() {\n  vec2 res2 = iResolution.xy * iDpr;\n  vec2 pixel = vec2(gl_FragCoord.xy - 0.5 * res2) / res2.y; // center-origin pixel coord\n  pixel.x -= xOffset * res2.x / res2.y;\n  pixel.y -= yOffset;\n\n  vec2 uv = gl_FragCoord.xy / res2; // 0 to 1\n\n  // float nn1 = snoise(uv * 0.25 + iTime * 0.005 + mixedColor.b * 0.01) * 0.1;\n  // float nn2 = snoise(uv * 0.25 + iTime * 0.005 + mixedColor.b * 0.01 + 1000.) * 0.1;\n  // uv += vec2(nn1, nn2);\n\n  // PERLIN DISTORTION\n  // float noiseScale = 10.;\n  // float timeScale = 0.5;\n  // uv += vec2( p3d(vec3(uv * noiseScale, iTime * timeScale)), p3d(vec3(1000. + uv * noiseScale , iTime * timeScale)) ) * 0.001;\n\n  // uv = rotate2d(uv, 0.001);\n  // pixel = rotate2d(pixel, 0.001);\n\n  vec2 mouse2 = (iMouse * iDpr / res2 - 0.5) * vec2(1.,-1.);\n  vec2 uvBig = (uv - 0.5) * 0.996 + 0.5;\n\n  vec4 oldImage = texture2D(iBuffer, uv);\n  vec3 mixedColor = oldImage.rgb - backgroundColor;\n\n  // float spinDist = 0.002 + 0.002 * sin(iTime * 0.4);\n  float cropDist = 0.01;\n  float cropXOffset = 0.2;\n  float cropYOffset = 0.2;\n  // float cropXOffset = 0.4 + 0.1 * sin(iTime * 0.4);\n  // float cropYOffset = 0.4 + 0.1 * cos(iTime * 0.6);\n\n  vec2 offset = uv + vec2((mixedColor.g - cropXOffset) * cropDist, (mixedColor.r - cropYOffset) * cropDist);\n\n  // float nn = snoise(uv * 10.) * 0.001;\n  // offset += nn;\n\n  float spinDist = 0.001;\n  float spinSpeed = 0.2 + 0.15 * cos(iTime * 0.5);\n  float timeFrac = mod(iTime, 6.5);\n  vec2 offset2 = uvBig + vec2(cos(timeFrac * spinSpeed) * spinDist, sin(timeFrac * spinSpeed) * spinDist);\n\n  mixedColor = texture2D(iBuffer, offset).rgb * 0.4\n    + texture2D(iBuffer, offset2).rgb * 0.6\n    - backgroundColor;\n\n\n  // mixedColor *= .875;\n  float fadeAmt = 0.0015; // fade this amount each frame // 0.002\n  mixedColor = (mixedColor - fadeAmt) * .995;\n\n  // float nn = snoise(uvBig * 10.) * 20.;\n  // mixedColor *= clamp(nn, 0.98, 1.0);\n\n  vec4 spectrum = abs( abs( .95*atan(uv.x, uv.y) -vec4(0,2,4,0) ) -3. )-1.;\n  float angle = atan(pixel.x, pixel.y);\n  float dist = length(pixel - mouse2*0.15) * 8. + sin(iTime) * .01;\n\n  // mixedColor *= pow(1.-dist*0.002, 2.);\n\n\n  // Flowery shapes\n  // float edge = abs(dist * 0.5);\n  float flowerPeaks = .05 * amplitudeFactor * size;\n  float flowerPetals = 7.;\n  float edge = abs((dist + sin(angle * flowerPetals + iTime * 0.5) * sin(iTime * 1.5) * flowerPeaks) * 0.65 / size);\n  // float edge = abs((dist + sin(angle * 4. + iTime * 2.) * sin(iTime * 3.) * 0.75) * 1.);\n\n  // vec4 rainbow = abs( abs( .95*mod(iTime * 1., 2. * PI) - vec4(0,2,4,0) ) -3. )-1.;\n  // vec4 rainbow = vec4(0,2,4,0);\n\n  float colorChangeSpeed = 0.75 + 0.05 * sin(iTime) * 1.5;\n  float rainbowInput = timeFrac * colorChangeSpeed;\n  // NOISE!\n  // float nn = snoise(uv * 0.25 + iTime * 0.005 + mixedColor.b * 0.01) * 20.;\n  // rainbowInput += nn;\n\n  float brightness = 0.7;\n  vec4 rainbow = sqrt(j2hue(cos(rainbowInput))) + vec4(baseColor,0) - 1.0 + brightness;\n  float factor = smoothstep(1., .9, edge) * pow(edge, 2.);\n  vec3 color = rainbow.rgb * smoothstep(1., .9, edge) * pow(edge, 20.);\n  vec4 ring = vec4(\n    backgroundColor + clamp( mixedColor + color, 0., 1.)\n    , 1.0);\n\n  // float t = fworley(uv * u_resolution.xy / 1500.0);\n  // t *= exp(-length2(abs(0.7*uv - 1.0)));\n  // float tExp = pow(t, 2. - t);\n  // vec3 c1 = color1 * (1.0 - t);\n  // vec3 c2 = color2 * tExp;\n  // vec4 cells = vec4(mixedColor * 0.25, 1.) + vec4(pow(t, 1.0 - t) * (c1 + c2), 1.0);\n  // gl_FragColor = clamp(ring + cells * 0.5, 0.0, 1.0);\n\n  // float nn = snoise(uv * 10.) * 0.01; // creepy!\n  gl_FragColor = ring;\n}\n", t
            }()
        },
        115: function (e) {
            e.exports = function (e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        690: function (e) {
            e.exports = function (e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        728: function (e, t, n) {
            var r = n(62);

            function a(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var a = t[n];
                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, r(a.key), a)
                }
            }
            e.exports = function (e, t, n) {
                return t && a(e.prototype, t), n && a(e, n), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), e
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        389: function (e, t, n) {
            var r = n(808),
                a = n(617),
                i = n(993);
            e.exports = function (e) {
                var t = a();
                return function () {
                    var n, a = r(e);
                    if (t) {
                        var o = r(this).constructor;
                        n = Reflect.construct(a, arguments, o)
                    } else n = a.apply(this, arguments);
                    return i(this, n)
                }
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        588: function (e, t, n) {
            var r = n(753);

            function a() {
                return "undefined" !== typeof Reflect && Reflect.get ? (e.exports = a = Reflect.get.bind(), e.exports.__esModule = !0, e.exports.default = e.exports) : (e.exports = a = function (e, t, n) {
                    var a = r(e, t);
                    if (a) {
                        var i = Object.getOwnPropertyDescriptor(a, t);
                        return i.get ? i.get.call(arguments.length < 3 ? e : n) : i.value
                    }
                }, e.exports.__esModule = !0, e.exports.default = e.exports), a.apply(this, arguments)
            }
            e.exports = a, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        808: function (e) {
            function t(n) {
                return e.exports = t = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                }, e.exports.__esModule = !0, e.exports.default = e.exports, t(n)
            }
            e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        655: function (e, t, n) {
            var r = n(15);
            e.exports = function (e, t) {
                if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && r(e, t)
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        617: function (e) {
            e.exports = function () {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function () { }))), !0
                } catch (e) {
                    return !1
                }
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        993: function (e, t, n) {
            var r = n(698).default,
                a = n(115);
            e.exports = function (e, t) {
                if (t && ("object" === r(t) || "function" === typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return a(e)
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        15: function (e) {
            function t(n, r) {
                return e.exports = t = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (e, t) {
                    return e.__proto__ = t, e
                }, e.exports.__esModule = !0, e.exports.default = e.exports, t(n, r)
            }
            e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        753: function (e, t, n) {
            var r = n(808);
            e.exports = function (e, t) {
                for (; !Object.prototype.hasOwnProperty.call(e, t) && null !== (e = r(e)););
                return e
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        36: function (e, t, n) {
            var r = n(698).default;
            e.exports = function (e, t) {
                if ("object" !== r(e) || null === e) return e;
                var n = e[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var a = n.call(e, t || "default");
                    if ("object" !== r(a)) return a;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === t ? String : Number)(e)
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        62: function (e, t, n) {
            var r = n(698).default,
                a = n(36);
            e.exports = function (e) {
                var t = a(e, "string");
                return "symbol" === r(t) ? t : String(t)
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        },
        698: function (e) {
            function t(n) {
                return e.exports = t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
                    return typeof e
                } : function (e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, e.exports.__esModule = !0, e.exports.default = e.exports, t(n)
            }
            e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
        }
    },
        t = {};

    function n(r) {
        var a = t[r];
        if (void 0 !== a) return a.exports;
        var i = t[r] = {
            exports: {}
        };
        return e[r].call(i.exports, i, i.exports, n), i.exports
    }
    n.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return n.d(t, {
            a: t
        }), t
    }, n.d = function (e, t) {
        for (var r in t) n.o(t, r) && !n.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, n.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "/",
        function runner_hood() {
            "use strict";
            var e = n(791),
                t = n(250),
                r = n(945),
                a = n.n(r),
                i = "Heading_headingContainer__AvcTg",
                o = "Heading_backText__30dRh",
                l = "Heading_titleContainer__8pyRZ",
                u = n(184),
                s = function (e) {
                    return (0, u.jsxs)("div", {
                        className: i,
                        children: [(0, u.jsx)("p", {
                            className: l,
                            children: e.children
                        }), (0, u.jsx)("p", {
                            className: o,
                            "data-aos": "fade-up",
                            children: e.backText
                        })]
                    })
                },
                c = n.p + "static/media/Innovation.1e0ec9849d976721e4d1.png",
                d = n.p + "static/media/RGi.dc25115c80178b69e849.png",
                f = n.p + "static/media/JARVIS.a3d3a15e612dbde50d3b.png",
                p = n.p + "static/media/GDGC.0e2789849c896fea372a.png",
                h = n.p + "static/media/coeaiml.4a40142ca5fb69ae2dba.png",
                m = n.p + "static/media/mlsa.8b532b4b6151165023be.png",
                v = "Presenters_rootPresenters__h8t9+",
                g = "Presenters_logoContainer__vljEr",
                y = "Presenters_ghrce__DWjVN",
                b = "Presenters_rgi__QelKt",
                w = "Presenters_coe__tHOpL",
                x = "Presenters_ieee__aNcOX",
                k = "Presenters_jarvis__eE9ga",
                S = "Presenters_gdgc__Qwz6m",
                _ = "Presenters_mlsa__Phlcs",
                E = function () {
                    return (0, u.jsx)("div", {
                        className: v,
                        children: (0, u.jsxs)("div", {
                            className: g,
                            children: [(0, u.jsx)("div", {
                                className: y,
                                children: (0, u.jsx)("img", {
                                    src: c
                                })
                            }), (0, u.jsx)("div", {
                                className: b,
                                children: (0, u.jsx)("img", {
                                    src: d
                                })
                            }), (0, u.jsx)("div", {
                                className: k,
                                children: (0, u.jsx)("img", {
                                    src: f
                                })
                            }), (0, u.jsx)("div", {
                                className: x,
                                children: (0, u.jsx)("img", {
                                    src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOIAAABUCAQAAAA1iiM0AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAHdElNRQfnAxQUNwGjYaCMAAAKXklEQVR42u2da9msKhSAJwIRiGCB8zxEMAIRjEAEIxiBCEQgghFosM4PFRc3BcTZM/OJf/bnRry8sFisC/OC141HBxwECBDAobv1Tn/6uKthChMYcMsMI9CMazkIGEEBgxe81k6wHAoUKBDwAobOTuv5br12OyQoUDA+EGsOAiOkiwBycr1aay4QwyLhBTxynqFr96IeiDUidIbjok9E6xnEZSQ+EG+D2AVCNFbMIcY4RGYPiiBO6DxB1w72bPdAvAPhGUYX4vaXW4ehUZm+9lFsKubCXISLUCUPxM+DqKCsjEUQlT06BHG2Z0entrbn+QMx/+ihvLACiO5VLKHAhLX7B2L+MVdAVFUQSRFE9kDMPTjUFVY4J3brWeagI6vO6l9LV531gXjLfAh2iXBNsVGPYtMKIoXaYrLXiQ/EmyFyqC99JkRsQ8Xa6X4WW2wmp/Yfhsg8K0n6mC5AFMVmN5Mwu4mEWP+TEHuYorqmBglD1NKiL0BUSYhDAqJ6IB5D5BlLhRkmTwheKTrqitrEo+uK2nyTritqO3xX1J8Up13RiJpBWCF7rTxu3WYQeeUSgQF5IH4GRH5JID4QPwBiV+R/2LVEBQJ6+O+PQCQF1h9clwBfZ+ybQmFqtEsDEriz6LgDIrOxM/IDPBEMpmwTgl9X32iK56CgUJSaQC+9Qzt9AQmWCvqf2kBlgR3Ir8sOVsSNXPD541Ad9CTVdJ0YfyL9DyGWGPP8ururnDeXDlaU0SwdtHujxUYkavKvhPgCCgKmG54eQRxOxR3LkMz1JWx9V7IGIOj5ZmtR0hHpsHnyN2uThs7WnO0nHG0cgFpb6FbRtF2/zTRbVAAHZZ9I2wgCBpN9CgPTKuzjdXFEghuTO6MATv/J5tVitbQrrRFmtt0eQZSF4ySui7XzYrDATTWtr0Sio37MnJf7hOA3npMZywIRkQvK62jbpyXJum539VcC22yvkrKnSzjwEER18IH74qn/uj9RBGOUImHOkmM5b+6Nve1QAXGMtpIDcU58A3WgB4TXdC7EdOlq5HNh6Q4g0oPOokFYcSadT6WdDzwiJQl/KoP+Rx1CZCDsR5xWy+0LKEjogSCcMlkXQ+ToyaQTcKKSz/wCDiN0jtbO8yAOhdNsjd0mppkK59VSi5kehWaZ4FNJ1Mf7KEThXZ+GGFdWCAx2Feu+S1gXP9nojD4TiV2fgqd5AV1nTOk8/ynEuV5XujQOY+I0BtGNJ/A/lYgG/PsQ8f+UQSSRLpsHUTktq4gTTQTvGbOnZUEUF5bE9YsLN/RRoOwO/lEQhwOp0h6iOstHSYUa1piISJFI1aea7hLqT+0yoc8Wp2UQjaMBUtQdfYjc+3tCs5xK1C0VpyFErKtOcYiq4cK6JBeDZJkOtNfXd8WGJxSbPIizp9jEFSMfogEJyolKJ/ZeKlE3pdjwhGJzBJE63QtBnLJDCdthnA81XxptYxmX/ekSIw9iqMLNBwJfeefGDHEaAmHRFaa/xAgh6nNxOhSPlLPwxTOhqk7bDrvCnkU1JbpbLcTtTcUBxNGTUfQAogi6hwuRnSz2Q4jDOcSUVikvWPVEcjyazKULgREZmiZnzbgLUo3EvnKSvnezmWtQ2wXhbpx7WVRm/b/RS8YhKFGHrurXbMWyctLKw7q+2a2zQnE32L28e+Jn3r+n+2T2zeID/JpI3dZROlBlhn8eVK9ucgv9c8++LAqyLxOtDAYQwD8mJ+JnIfLDhUD3S69rPQT9r0E880GIH8osUiB/L2Mxz6lrUIzpc3woxDy75/SmPtwV7XtBQGRuOMScCIV+1b83bXL8doj5PgjzBpTqwMfhK05TZs0tPWFLDZgDOyl87+xfG2ChQNymceZDZNk10zmPPwSxLud+yZQS0FckdbLTLVDeA3ERp+abFx1tgp328alAOmmfy+FumqdP1mouRGZzoRiMoGC0HUZYhWxJNaV2ThXrc9AMiDTInuIgQQJHd34dtLznZA0gQXoGDbq+s3C6OYEBpuBsk6woBe8tKfusC1EkHWVxQ/gY9cakIfpe9PTucPGWj5xsIhrS1Ts2sqktRAbvLkMlxDkJUSSiB3Ih8qRpe0i0nHbk9dH3DX00oiXEa0HANWWuhLh8wBhEE4QhTUUQJZIT8SDF0X6lKQlROlqGWa81jltXWoO7aQuRVGVHXSl9NsQZCPK/s6hiwxzBpdEnyoVo0HNNkWi4sGU8nnDQVIc6XAfGGjAN6r5DQWR5NsS6zb2uFJkNUUV9cy7EuG+0BCIO0sB35smWY8IcY9deqluLyMITiO8XqaQhRNEMon/nc6GegqgyMshEa4ikcsVYW3hDiNyKXoWOGohdYiSGLZ9B3DNIMETjtMNbQ6zNG24nUMshAgwwQmfnIWUTXFjhEmO27VHnOTovmGJvOQWRonmfwGTn09nRbburojQFsc3CP3+12ALiJphn1NM3dagE4pRcYuCWDVrlpiDG7NGTI5iVY89tDvF1uJ9+69JVQ+yCua9PzDe5EFkSYtjyeAKRRXXxcLqa74L4TgWHV0PET7nPi8axnvSFFhsRxLyKqKVFe3ajEKJ7hbHv6e4XZK473VvFc18p4tCfSJ2/8M7724cSgWWyX22eNGiTOK0stfFf+x2ptz1ZqmX8RDTiCV2u6D1QHQwgYGhvO/1XGFWLF2nslubIhvrxMQ0tsyt+B6K6nNDwQRDfg/ETR+L2ZOzzEeZsWns/xjsgLj8OVr9bVf9Nu4fnhSKpt0Okq9t0rHScuhrn0bv9QFxtbsXprRBFdEVWcugMiAIU/MQPguVXHW6DOJ56UsoNxDMoGE9MWp86I98IMUzKunuxL4EBg/G2IKY/CTEn97Cm0JP5jNgay54VMwAoL92NrjsxzaBggGUbaYWyGpc9mZbNPcmaFrbbQiXwNaBp61DLr6Cy1Yo8/RLEtM+uvujgDsaai30rx5wYwzzwILreysm7I/HsmtrZjWY3xVHQMIO5HkDxaRBL9wov9ydKJ968C5QVZaEYoJ4Z3KwG5Tni3NXIGio81apzxv9ou5cGA/oXIbYcj3OGP3MZkX3ULI4jW+Rqv+Tg/jiRQdfJIDpGeV2E2X9zWLJ61afnUdVfSqv3czsLlMIzVuiHGzybyis6t+4Qd++/WBcVbmCFH58zru5c81uL/SN9VTVdXPg5TFj5EZ4TakNAo3PrDjEe+sUCiMS2M3yDMtMO4jWQU8GiZkfqQ2SNIOI9cpr4278JYjhqro5CGokwYJfF6Xi6TuQtve3fB3Fbw+lsdYYdWlu2hJVdxem87bcEQqOdICYCA4JIbEC0QfuncgRRozdoGFr/nRB3w7U8tOyc/0CCG/y+jYs9On0PgF9GH3O6xzL+VDQ/Q1tTATYqaDvu5Pc4gu+EiH3jYrV7KJvy1mdpfGE8XJewqaYX+9qZQVXU5K68IKv9DvqXzW7vOfB26DOMCHxnt2mfQToimdqN1dW68aS7ixO38mGGyUbXSHsP11o0PBC/9yCJIMoH4hcdw/dppg/EUC+uc0E/ED/mYIemwAfiVxwymWz34cf/kiEWwrUcEEwAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjMtMDMtMjBUMjA6NTQ6MjUrMDA6MDDLQT2TAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIzLTAzLTIwVDIwOjU0OjI1KzAwOjAwuhyFLwAAAABJRU5ErkJggg=="
                                })
                            }), (0, u.jsx)("div", {
                                className: w,
                                children: (0, u.jsx)("img", {
                                    src: h
                                })
                            }), (0, u.jsx)("div", {
                                className: S,
                                children: (0, u.jsx)("img", {
                                    src: p
                                })
                            }), (0, u.jsx)("div", {
                                className: _,
                                children: (0, u.jsx)("img", {
                                    src: m
                                })
                            })]
                        })
                    })
                },
                C = "About_rootAbout__Xel1M",
                N = "About_contentContainer__Y3xqJ",
                j = "About_content__PN0eG",
                T = "About_images__nYVB-",
                P = function () {
                    return (0, u.jsxs)("div", {
                        className: C,
                        children: [(0, u.jsx)(s, {
                            // backText: "About US",
                            "data-aos": "fade-up",
                            children: "About Us"
                        }), (0, u.jsxs)("div", {
                            className: N,
                            children: [(0, u.jsxs)("div", {
                                className: j,
                                children: [(0, u.jsx)("p", {
                                    children: "Government Polytechnic Nagpur College has successfully organized three exhilarating editions of Enkryptia. Now, we are elated to announce Enkryptia, a blend of AI and games. AI plays a vital role in our lives, and when fused with games, there is no better way to learn it."
                                }), (0, u.jsx)("p", {
                                    children: "Enkryptia is going to be held on October 24 and October 25, 2024, where the junction of games will make you dive deep into the creative, theoretical, applicable, visionary, and innovative ways of implementing Artificial Intelligence."
                                }), (0, u.jsx)("p", {
                                    children: "The event is open to students, professionals, and enthusiasts from various fields such as engineering, computer science, game development, and others."
                                })]
                            }), (0, u.jsx)("div", {
                                className: T,
                                children: (0, u.jsx)("img", {
                                    src: "https://aisummit3.vercel.app/assets/Saly-10.png"
                                })
                            })]
                        })]
                    })
                },
                z = "Glimpses_rootGlimpses__b0N8f",
                M = "Glimpses_imageGallery__C0wev",
                A = "Glimpses_image__Pozbo",
                O = "Glimpses_vertical__Z5+Ti",
                L = "Glimpses_horizontal__Y016U",
                R = "Glimpses_normal__UJXDu",
                I = n.p + "static/media/Innovation.1e0ec9849d976721e4d1.png",
                D = n.p + "static/media/glimpse2.8a0b393f5f265bcde085.jpg",
                F = n.p + "static/media/glimpse3.b567bde41fe7f3fe2d18.jpg",
                U = n.p + "static/media/glimpse4.d2396f3799518fa1387e.jpg",
                B = n.p + "static/media/glimpse5.4e0dfafa694410f0cf4a.jpg",
                V = n.p + "static/media/glimpse6.44a2b1b43636a036dddc.jpg",
                H = n.p + "static/media/glimpse7.c617fc9701f30a399a0c.jpg",
                W = n.p + "static/media/glimpse8.a1db16cbbea8d8d05dc6.jpg",
                Q = n.p + "static/media/glimpse9.3280952be8142ab9e1a8.jpg",
                G = [{
                    url: I,
                    className: L
                }, {
                    url: F,
                    className: L
                }, {
                    url: D,
                    className: O
                }, {
                    url: U,
                    className: R
                }, {
                    url: B,
                    className: L
                }, {
                    url: V,
                    className: O
                }, {
                    url: H,
                    className: R
                }, {
                    url: W,
                    className: R
                }, {
                    url: n.p + "static/media/glimpse10.dae41eec71ad3d1737fa.jpg",
                    className: R
                }, {
                    url: Q,
                    className: L
                }],
                X = function (e) {
                    return (0, u.jsxs)("div", {
                        className: z,
                        children: [(0, u.jsx)(s, {
                            // backText: "Glimpses",
                            children: "Glimpses"
                        }), (0, u.jsx)("div", {
                            className: M,
                            children: G.map((function (e, t) {
                                return (0, u.jsx)("div", {
                                    className: "".concat(A, " ").concat(e.className),
                                    style: {
                                        backgroundImage: "url(".concat(e.url, ")")
                                    }
                                }, e + t)
                            }))
                        }), (0, u.jsx)("div", {
                            id: "timeline"
                        })]
                    })
                };

            function q(e) {
                throw new TypeError('"' + e + '" is read-only')
            }

            function Y(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function K(e, t) {
                return function (e) {
                    if (Array.isArray(e)) return e
                }(e) || function (e, t) {
                    var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var r, a, i, o, l = [],
                            u = !0,
                            s = !1;
                        try {
                            if (i = (n = n.call(e)).next, 0 === t) {
                                if (Object(n) !== n) return;
                                u = !1
                            } else
                                for (; !(u = (r = i.call(n)).done) && (l.push(r.value), l.length !== t); u = !0);
                        } catch (c) {
                            s = !0, a = c
                        } finally {
                            try {
                                if (!u && null != n.return && (o = n.return(), Object(o) !== o)) return
                            } finally {
                                if (s) throw a
                            }
                        }
                        return l
                    }
                }(e, t) || function (e, t) {
                    if (e) {
                        if ("string" === typeof e) return Y(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Y(e, t) : void 0
                    }
                }(e, t) || function () {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            var $ = "Events_rootEvents__tgQcy",
                J = "Events_buttons__EF2RE",
                Z = "Events_button__pkiVo",
                ee = function () {
                    return (0, u.jsx)("div", {
                        children: (0, u.jsx)("div", {
                            id: "content",
                            children: (0, u.jsxs)("ul", {
                                className: "timeline",
                                children: [(0, u.jsxs)("li", {
                                    className: "event",
                                    "data-date": "11:30 AM - 1:00 AM",
                                    "data-aos": "fade-up",
                                    children: [(0, u.jsx)("h3", {
                                        children: "Reporting and Registration"
                                    }), (0, u.jsx)("p", {
                                        // children: "Registration and Working space will be allot in this time  "
                                    })]
                                }), (0, u.jsxs)("li", {
                                    className: "event",
                                    "data-date": "01:00 PM - 2:00 PM",
                                    "data-aos": "fade-up",
                                    children: [(0, u.jsx)("h3", {
                                        children: "Session"
                                    }), (0, u.jsx)("p", {
                                        // children: "All the Instructions and timings will be provided "
                                    })]
                                }), (0, u.jsxs)("li", {
                                    className: "event",
                                    "data-date": "02:00 PM",
                                    "data-aos": "fade-up",
                                    children: [(0, u.jsx)("h3", {
                                        children: "Hackathon Starts"
                                    }), (0, u.jsx)("p", {
                                        // comment
                                        // comment
                                        // comment
                                        // comment
                                        // comment
                                        // comment
                                        // comment
                                        // comment
                                        // comment
                                        // children: "Coding Begins and Timer will be start  "
                                    })]
                                }), (0, u.jsxs)("li", {
                                    className: "event",
                                    "data-date": "5:00 PM",
                                    "data-aos": "fade-up",
                                    children: [(0, u.jsx)("h3", {
                                        children: "Snacks"
                                    }), (0, u.jsx)("p", {
                                        children: " "
                                    })]
                                }), (0, u.jsxs)("li", {
                                    className: "event",
                                    "data-date": "9:00 PM - 10:00 PM",
                                    "data-aos": "fade-up",
                                    children: [(0, u.jsx)("h3", {
                                        children: "Dinner"
                                    }), (0, u.jsx)("p", {
                                        children: ""
                                    })]
                                })]
                            })
                        })
                    })
                },
                te = function ({ num }) {
                    console.log('fucked ups')
                    if (num == 1) {
                        return (0, u.jsx)("div", {
                            children: (0, u.jsx)("div", {
                                id: "content",
                                children: (0, u.jsxs)("ul", {
                                    className: "timeline",
                                    children: [
                                        (0, u.jsxs)("li", {
                                            className: "event",
                                            "data-date": "12:00 AM - 2:00 AM",
                                            "data-aos": "fade-up",
                                            children: [(0, u.jsx)("h3", {
                                                children: "Tea / Coffee"
                                            }), (0, u.jsx)("p", {
                                                children: ""
                                            })]
                                        }), (0, u.jsxs)("li", {
                                            className: "event",
                                            "data-date": "7:00 AM",
                                            "data-aos": "fade-up",
                                            children: [(0, u.jsx)("h3", {
                                                children: "Snacks"
                                            }), (0, u.jsx)("p", {
                                                // children: "Get ready for GoAlgo and Innovation Junction. A junction of games where one will challenge your programming skills whilst the other challenges your innovative skills."
                                            })]
                                        }), (0, u.jsxs)("li", {
                                            className: "event",
                                            "data-date": "10:00 AM",
                                            "data-aos": "fade-up",
                                            children: [(0, u.jsx)("h3", {
                                                children: "Lunch"
                                            }), (0, u.jsx)("p", {
                                                // children: "Get ready for GoAlgo and Innovation Junction. A junction of games where one will challenge your programming skills whilst the other challenges your innovative skills."
                                            })]
                                        }), (0, u.jsxs)("li", {
                                            className: "event",
                                            "data-date": "2:00 PM",
                                            "data-aos": "fade-up",
                                            children: [(0, u.jsx)("h3", {
                                                children: "Code Time Ends"
                                            }), (0, u.jsx)("p", {
                                                // children: "Get ready for GoAlgo and Innovation Junction. A junction of games where one will challenge your programming skills whilst the other challenges your innovative skills."
                                            })]
                                        }), (0, u.jsxs)("li", {
                                            className: "event",
                                            "data-date": "2:00 PM - 3:30 PM",
                                            "data-aos": "",
                                            children: [(0, u.jsx)("h3", {
                                                children: "Solution Presentation"
                                            }), (0, u.jsx)("p", {
                                                // children: "Get ready for GoAlgo and Innovation Junction. A junction of games where one will challenge your programming skills whilst the other challenges your innovative skills."
                                            })]
                                        }), (0, u.jsxs)("li", {
                                            className: "event",
                                            "data-date": "4:00 PM",
                                            "data-aos": "fade-up",
                                            children: [(0, u.jsx)("h3", {
                                                children: "Prize Distribution"
                                            }), (0, u.jsx)("p", {
                                                // children: "Get ready for GoAlgo and Innovation Junction. A junction of games where one will challenge your programming skills whilst the other challenges your innovative skills."
                                            })]
                                        })
                                    ]
                                })
                            })
                        })
                    }
                },
                ne = function ({ num }) {
                    var t = K((0, e.useState)(!1), 2),
                        n = t[0],
                        r = t[1];
                    if (num == 1) {
                        return (0, u.jsxs)("div", {
                            className: $,
                            children: [(0, u.jsx)(s, {
                                // backText: "Timeline",

                                children: "Timeline"
                            }), (0, u.jsxs)("div", {
                                className: J,
                                children: [(0, u.jsx)("div", {
                                    className: Z,
                                    onClick: function () {
                                        r(!1), q("show")
                                    },
                                    children: (0, u.jsxs)("p", {
                                        children: ["24", (0, u.jsx)("sup", {
                                            children: "th"
                                        }), " October"]
                                    })
                                }), (0, u.jsx)("div", {
                                    className: Z,
                                    onClick: function () {
                                        r(!0), q("show")
                                    },
                                    children: (0, u.jsxs)("p", {
                                        children: ["25", (0, u.jsx)("sup", {
                                            children: "th"
                                        }), " October"]
                                    })
                                })]
                            }), n ? (0, u.jsx)(te, { num: prime }) : (0, u.jsx)(ee, {}), (0, u.jsx)("div", {
                                id: "speakers"
                            })]
                        })
                    }
                    else {
                        console.log('sfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaak');
                        return (0, u.jsxs)("div", {
                            className: $,
                            children: [(0, u.jsx)(s, {
                                // backText: "Timeline",

                                children: "Timeline"
                            }), (0, u.jsxs)("div", {
                                className: J,
                                children: [(0, u.jsx)("div", {
                                    className: Z,
                                    onClick: function () {
                                        r(!0), q("show")
                                    },
                                    children: (0, u.jsxs)("p", {
                                        children: ["25", (0, u.jsx)("sup", {
                                            children: "th"
                                        }), " October"]
                                    })
                                })]
                            }), (0, u.jsx)(te, { num: prime })]
                        })
                    }
                },
                re = "Speakers_speakersRoot__GLxi4",
                ae = "Speakers_speakersContainer__yeDBm",
                ie = "Speakers_speakerCard__0mhEY",
                oe = "Speakers_speakerName__D6m3G",
                le = "Speakers_speakerCo__HQLcc",
                ue = "Speakers_speakerURL__szrbn",
                se = [{
                    image: "https://media.licdn.com/dms/image/C5103AQFP6ESvGnmU3A/profile-displayphoto-shrink_400_400/0/1577369922716?e=1684972800&v=beta&t=aGYb-W2P-XJCwapPZl0QZRbs7hyWDaOuw_kFfgyRLdc",
                    name: "Aditya Rane",
                    url: "https://www.linkedin.com/in/aditya-rane/",
                    co: "Google"
                }, {
                    image: "https://media.licdn.com/dms/image/C5603AQGEV-kzawPxjw/profile-displayphoto-shrink_400_400/0/1588602102622?e=1684972800&v=beta&t=9I2VAjrdk2UTm4auncoJMo8Vfsg4gxsubut9LcXNG5Q",
                    name: "Aditya Jyoti Paul",
                    url: "https://www.linkedin.com/in/phreakyphoenix/",
                    co: "ReflectiveAI"
                }, {
                    image: "https://media.licdn.com/dms/image/C4E03AQHy74cQXZU5Nw/profile-displayphoto-shrink_400_400/0/1591702102131?e=1685577600&v=beta&t=f626ajjuV6G7DP3ubH18L_i1Yu1BPVnFKpLrQs8ukaQ",
                    name: "Hemant Kshirsagar",
                    url: "https://www.linkedin.com/in/hemant-kshirsagar-31796279/",
                    co: "Kizora Software"
                }, {
                    image: "https://media.licdn.com/dms/image/D4D03AQFgzlVi276ymw/profile-displayphoto-shrink_400_400/0/1665824209290?e=1685577600&v=beta&t=5jvme2tSsC9crfGCqJO1oVIp30MhN03wLzResyef6I0",
                    name: "Dr Latesh Bhagat ",
                    url: "https://www.linkedin.com/in/dr-latesh-bhagat-malik-b22811a/",
                    co: "Associate Professor, GCOEN"
                }, {
                    image: "https://media.licdn.com/dms/image/C5603AQHA5qCse4ZdrQ/profile-displayphoto-shrink_400_400/0/1658596566056?e=1685577600&v=beta&t=iPDfTUfRJz8Souy-DzhiTp6sfIBtOk89w4ZCykYNlx0",
                    name: "Aditya Bobde",
                    url: "https://www.linkedin.com/in/aditya-bobde/",
                    co: "Research Intern, ISB"
                }],
                ce = function () {
                    return (0, u.jsxs)("div", {
                        className: re,
                        children: [(0, u.jsx)(s, {
                            // backText: "Speakers",
                            children: "Speakers"
                        }), (0, u.jsx)("div", {
                            className: ae,
                            children: se.map((function (e) {
                                return (0, u.jsxs)("div", {
                                    className: ie,
                                    "data-aos": "fade-up",
                                    children: [(0, u.jsx)("img", {
                                        src: e.image,
                                        "data-aos": "fade-up"
                                    }), (0, u.jsx)("p", {
                                        className: oe,
                                        "data-aos": "fade-up",
                                        children: e.name
                                    }), (0, u.jsx)("p", {
                                        className: le,
                                        "data-aos": "fade-up",
                                        children: e.co
                                    }), (0, u.jsx)("p", {
                                        className: ue,
                                        "data-aos": "fade-up",
                                        children: (0, u.jsx)("a", {
                                            href: e.url,
                                            target: "_blank",
                                            children: "Connect with Me"
                                        })
                                    })]
                                })
                            }))
                        }), (0, u.jsx)("div", {
                            id: "events"
                        })]
                    })
                },
                de = n(480),
                fe = n.n(de),
                pe = "AnimatedLanding_main__da+Xy",
                he = "AnimatedLanding_a__BaWlM",
                me = "AnimatedLanding_c__N6-6x",
                ve = "AnimatedLanding_b__W5FW6",
                ge = "AnimatedLanding_contentWrapper__xidPu",
                ye = "AnimatedLanding_imageText__enLuK",
                be = "AnimatedLanding_line2__1gIfL",
                we = "AnimatedLanding_line3__I93L9",
                xe = "AnimatedLanding_regButton__rMNAB",
                ke = {
                    headerRoot: "Header_headerRoot__1Xu87",
                    color: "Header_color__JtqRO",
                    active: "Header_active__0xMci",
                    header: "Header_header__sI0Fg",
                    logo: "Header_logo__8EUO2",
                    headerControls: "Header_headerControls__wkn06",
                    navigation: "Header_navigation__RsJVK"
                },
                Se = window.innerHeight,
                _e = function () {
                    var t = K((0, e.useState)(!1), 2),
                        n = t[0],
                        r = t[1];
                    return (0, e.useEffect)((function () {
                        return window.addEventListener("scroll", (function () {
                            var e = document.documentElement.scrollTop;
                            r(e > 50 && e < Se ? 1 : e > Se ? 2 : 0)
                        })),
                            function () {
                                window.removeEventListener("scroll", (function () { }))
                            }
                    }), []), (0, u.jsxs)("div", {
                        className: "".concat(ke.headerRoot, " ").concat(1 === n ? ke.color : 2 === n ? ke.active : ke.inactive),
                        children: [(0, u.jsxs)("div", {
                            className: ke.header,
                            children: [(0, u.jsx)("div", {
                                className: ke.logo,
                                children: (0, u.jsx)("span", {
                                    children: "Enkryptia"
                                })
                            }), (0, u.jsx)("div", {
                                className: ke.headerControls,
                                children: (0, u.jsx)("div", {
                                    className: ke.navigation,
                                    children: (0, u.jsxs)("ul", {
                                        children: [(0, u.jsx)("li", {
                                            children: (0, u.jsx)("a", {
                                                href: "#speakers",
                                                children: "Speakers"
                                            })
                                        }), (0, u.jsx)("li", {
                                            children: (0, u.jsx)("a", {
                                                href: "https://keepthescore.co/board/sdpdsfxdymqmr/",
                                                target: "_blank",
                                                children: "Leaderboard"
                                            })
                                        }), (0, u.jsx)("li", {
                                            children: (0, u.jsx)("a", {
                                                href: "#timeline",
                                                children: "Timeline"
                                            })
                                        })]
                                    })
                                })
                            })]
                        }), (0, u.jsx)("div", {
                            className: ke.headerSmall
                        })]
                    })
                },
                Ee = function (t) {
                    var n = K((0, e.useState)(null), 2),
                        r = n[0],
                        a = n[1],
                        i = (0, e.useRef)(null);
                    return (0, e.useEffect)((function () {
                        return r || a(fe()({
                            el: i.current,
                            mouseControls: 0,
                            touchControls: 0,
                            gyroControls: 0,
                            minHeight: 10,
                            minWidth: 10,
                            // baseColor: 239087,
                            // backgroundColor: 342454
                        })),
                            function () {
                                r && r.destroy()
                            }
                    }), [r]), (0, u.jsxs)("div", {
                        className: pe,
                        children: [(0, u.jsxs)("div", {
                            id: "ex",
                            className: he,
                            ref: i,
                            children: [(0, u.jsx)("div", {
                                className: me
                            }), (0, u.jsx)(_e, {})]
                        }), (0, u.jsx)("div", {
                            className: ve,
                            children: (0, u.jsxs)("div", {
                                className: ge,
                                children: [(0, u.jsxs)("div", {
                                    className: ye,
                                    children: [(0, u.jsx)("p", {
                                        className: be,
                                        children: "Enkryptia"
                                    }), (0, u.jsx)("p", {
                                        className: we,
                                        children: "21 Oct - 23 Oct"
                                    })]
                                }), (0, u.jsx)("div", {
                                    className: xe,
                                    children: (0, u.jsx)("a", {
                                        href: "https://lu.ma/09lmt81v",
                                        target: "_blank",
                                        children: "Register Now",

                                    })
                                })]
                            })
                        })]
                    })
                },
                Ce = "EventDetails_eventDetailsRoot__ImH9H",
                Ne = "EventDetails_eventsDetailsMain__Xgvk2",
                je = "EventDetails_eventCard__6yeNB",
                Te = "EventDetails_eventImg__-MHa0",
                Pe = "EventDetails_eventTitle__AAlpF",
                ze = "EventDetails_eventDescription__tBs3V",
                Me = n.p + "static/media/Innovation.1e0ec9849d976721e4d1.png",
                Ae = [{
                    id: 1,
                    name: "Scan & Hunt",
                    desc: "Scan & Hunt is an intriguing game that wakes up the detective inside of you as you go on searching answers for the riddles. Each team of three to five members will compete with one another by unravelling the mystery inside of a QR code in three rounds adding more mystery and complexity than the previous rounds.",
                    img: "https://github.com/RajatPetkar/Enkryptia_2k23/blob/main/Events/IMG-20231008-WA0018.jpg",
                    url: "https://github.com/RajatPetkar/Enkryptia_2k23/blob/main/Events/IMG-20231008-WA0018.jpg"
                }, {
                    id: 2,
                    name: "AI Wizard",
                    desc: "A wizard is the one who has magical powers. Are you the Dumbledore of AI? Let's find it out in our exciting game of AI Wizard. A member from each team will be competing with the other teams in three rounds ranging from their creativity in AI, their proficiency in AI to their vision in AI.",
                    img: n.p + "static/media/aiwizard.ad2bf2320ff1851e5598.png",
                    url: "https://github.com/AvinashMohare/AI-Odyssey/blob/main/AI%20Wizard/Rule%20Book.md"
                }, {
                    id: 3,
                    name: "Mindscape",
                    desc: "The most inquisitive competition that will electrify your inventive minds with mind twisting quizzes is here. Each team consisting of three to four members will compete against each other in this competition which will be held in three rounds with each round more exciting and challenging than the previous one.",
                    img: n.p + "static/media/Mindscape.6ffce1ae9260a9f0e60b.jpeg",
                    url: "https://github.com/AvinashMohare/AI-Odyssey/blob/main/Mindscape/Rule%20Book.md"
                }, {
                    id: 4,
                    name: "Smart Playoffs",
                    desc: "Darwin\u2019s theory about survival of the fittest also applies in the tech world where the smartest one is the last of us to survive. The Smart Playoffs is a virtual ethical implication of AI in humans. In this valiant battle, get ready to sharpen your mental ability and problem solving skills, followed by a creative brainstorm showing your photographic and designing skills. At the end, a rapid fire round involving the latest trends in the field of AI.",
                    img: n.p + "static/media/SmartPlayofs.63d3cbef9b90fd2eed84.png",
                    url: "https://github.com/AvinashMohare/AI-Odyssey/blob/main/The%20Smart%20Playoffs/Rule%20Book.md"
                }, {
                    id: 5,
                    name: "Innovation Junction",
                    desc: "Introducing Innovation Junction, the game that promises to unlock your creativity and imagination like never before! Get ready to generate game-changing ideas and tap into your inner innovator with this ultimate idea-generation experience. In this fast-paced game, players will be challenged to come up with innovative solutions to a variety of prompts and scenarios, from business challenges to social issues and beyond. With each round, players will have a limited amount of time to brainstorm and pitch their ideas. ",
                    img: Me,
                    url: "https://github.com/AvinashMohare/AI-Odyssey/blob/main/Innovation%20Junction/Rule%20Book.md"
                }, {
                    id: 6,
                    name: "Go Algo",
                    desc: "This competition is for anyone with a passion for programming and are ready to unleash their programming prowess to take on the ultimate challenge in our thrilling algorithm game! The competition is divided into three rounds where shuffled steps of the algorithm will be provided and one teammate must correct the sequence while the others complete the code. It's a race against the clock, and teamwork is the key to success!",
                    img: n.p + "static/media/GoAlgo.16a38be21d9d648e0958.png",
                    url: "https://github.com/AvinashMohare/AI-Odyssey/blob/main/Go%20Algo/Rule%20Book.md"
                }],
                Oe = function () {
                    return (0, u.jsxs)("div", {
                        className: Ce,
                        children: [(0, u.jsx)(s, {
                            // backText: "Events",
                            children: "Events"
                        }), (0, u.jsx)("div", {
                            className: Ne,
                            children: Ae.map((function (e) {
                                return (0, u.jsx)(u.Fragment, {
                                    children: (0, u.jsx)("a", {
                                        href: e.url,
                                        target: "_blank",
                                        children: (0, u.jsxs)("div", {
                                            className: je,
                                            children: [(0, u.jsx)("img", {
                                                className: Te,
                                                src: e.img
                                            }), (0, u.jsx)("p", {
                                                className: Pe,
                                                children: e.name
                                            }), (0, u.jsx)("p", {
                                                className: ze,
                                                children: e.desc
                                            })]
                                        })
                                    })
                                })
                            }))
                        })]
                    })
                },
                Le = {
                    loading: "LoadingScreen_loading__oFjPX",
                    active: "LoadingScreen_active__KEKef",
                    inactive: "LoadingScreen_inactive__MnjZg",
                    events: "LoadingScreen_events__2Z409"
                };
            var Re = function () {
                var t = ["Hackathon", "Coding", "Programming", "Competition", "Creativity", "Development"],
                    n = K((0, e.useState)(0), 2),
                    r = n[0],
                    a = n[1],
                    i = K((0, e.useState)(!0), 2),
                    o = i[0],
                    l = i[1];
                return (0, e.useEffect)((function () {
                    var e = setTimeout((function () {
                        l(!1)
                    }), 2500);
                    return function () {
                        return clearTimeout(e)
                    }
                }), []), (0, e.useEffect)((function () {
                    var e = setInterval((function () {
                        a((function (e) {
                            return e === t.length - 1 ? 0 : e + 1
                        }))
                    }), 500);
                    return function () {
                        return clearInterval(e)
                    }
                }), [t.length]), (0, u.jsx)("div", {
                    className: "".concat(Le.loading, " ").concat(o ? Le.active : Le.inactive),
                    children: (0, u.jsx)("span", {
                        className: Le.events,
                        children: t[r]
                    })
                })
            };
            var Ie = function () {
                return (0, u.jsx)("footer", {
                    className: "footer",
                    children: (0, u.jsx)("div", {
                        className: "container",
                        children: (0, u.jsxs)("div", {
                            className: "row",
                            children: [(0, u.jsxs)("div", {
                                className: "col-md-4",
                                children: [(0, u.jsx)("h3", {
                                    children: "About Us"
                                }), (0, u.jsx)("p", {
                                    children: "We are elated to announce Enkryptia - a blend of AI and games."
                                }), (0, u.jsx)("p", {
                                    children: "Enkryptia is going to be held on October 24 and October 25, 2024. Here, we will discuss AI and its functions in a fun, creative and innovative manner."
                                })]
                            }), (0, u.jsxs)("div", {
                                className: "col-md-4",
                                children: [(0, u.jsx)("h3", {
                                    children: "Contact Us"
                                }), (0, u.jsx)("p", {
                                    children: "Goverment Polytechnic, Nagpur"
                                })]
                            }), (0, u.jsx)("div", {
                                className: "regButton",
                                children: (0, u.jsx)("a", {
                                    href: "https://lu.ma/09lmt81v",
                                    target: "_blank",
                                    children: "Register Now"
                                })
                            }), (0, u.jsx)("div", {
                                className: "mine",
                                children: (0, u.jsx)("a", {
                                    href: "https://www.linkedin.com/in/rajat-petkar-515416223/",
                                    target: "_blank",
                                    children: "Developed By - Rajat Petkar"
                                })
                            })]
                        })
                    })
                })
            },
                De = function () {
                    return (0, u.jsxs)("div", {
                        className: C,
                        children: [(0, u.jsx)(s, {
                            backText: "AI DEPT",
                            children: "AI Department"
                        }), (0, u.jsxs)("div", {
                            className: N,
                            children: [(0, u.jsxs)("div", {
                                className: j,
                                children: [(0, u.jsx)("p", {
                                    children: "The Department of Artificial Intelligence of G H Raisoni College of Engineering was established in 2019. B.Tech. in Artificial Intelligence is an undergraduate programme with advanced learning solutions, imparting knowledge of advanced innovations like machine learning, often called deep learning and artificial intelligence."
                                }), (0, u.jsx)("p", {
                                    children: "This specialisation is designed to enable students to build intelligent machines, software or applications with a cutting-edge combination of machine learning, analytics and visualisation technologies. This programme discusses AI methods based in different fields, including neural networks, signal processing, Natural Language Processing, and data mining in order to present a unified treatment of machine learning problems and solutions."
                                })]
                            }), (0, u.jsx)("div", {
                                className: T,
                                children: (0, u.jsx)("img", {
                                    src: "https://aisummit3.vercel.app/assets/Saly-19.png"
                                })
                            })]
                        })]
                    })
                },
                Fe = {
                    rootTrailer: "Trailer_rootTrailer__v38YU",
                    videoAndDatetime: "Trailer_videoAndDatetime__o73sb",
                    datetimeContainer: "Trailer_datetimeContainer__qkmEz",
                    eventMetas: "Trailer_eventMetas__xWI4K",
                    date: "Trailer_date__v33N3",
                    time: "Trailer_time__CV4nn",
                    venue: "Trailer_venue__zhtmV",
                    countdownTooltip: "Trailer_countdownTooltip__8yoZT",
                    countdownContainer: "Trailer_countdownContainer__dxRmT",
                    countdownBox: "Trailer_countdownBox__hmIU-",
                    countdownNumber: "Trailer_countdownNumber__T3JdE",
                    countdownText: "Trailer_countdownText__ty0nS",
                    timeSeparator: "Trailer_timeSeparator__EbLR3",
                    active: "Trailer_active__P+WXA",
                    registerBtn: "Trailer_registerBtn__FkRnq",
                    "fade-bg": "Trailer_fade-bg__Z9lcd"
                },
                Ue = function () {
                    var t = (new Date).getTime(),
                        n = new Date("2024-10-23 11:59:00 PM").getTime(),
                        r = K((0, e.useState)(n - t), 2),
                        a = r[0],
                        i = r[1];
                    return (0, e.useEffect)((function () {
                        var e = setInterval((function () {
                            i(n - (new Date).getTime())
                        }), 1e3);
                        return function () {
                            return clearInterval(e)
                        }
                    }), [n]),
                        function () {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                            return {
                                Days: Math.floor(e / 864e5),
                                Hours: Math.floor(e % 864e5 / 36e5),
                                Mins: Math.floor(e % 36e5 / 6e4),
                                Secs: Math.floor(e % 6e4 / 1e3)
                            }
                        }(a)
                },
                Be = function () {
                    var e = Ue(),
                        t = e.Days,
                        n = e.Mins,
                        r = e.Hours,
                        a = e.Secs,
                        i = t <= 0 && t >= -1 && r <= 0 && n <= 0 && a <= 0 ? "On Going Event" : t <= 0 && r <= 0 && n <= 0 && a <= 0 ? "Registration Closed" : "Coming Soon!";
                    return (0, u.jsxs)("div", {
                        className: Fe.rootTrailer,
                        children: [(0, u.jsxs)("div", {
                            className: Fe.videoAndDatetime,
                            children: [(0, u.jsx)("iframe", {
                                width: "560",
                                height: "315",
                                src: "https://www.youtube.com/embed/ofDVYghUvuk",
                                title: "YouTube video player",
                                frameborder: "0",
                                allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
                                allowfullscreen: !0
                            }), (0, u.jsx)("div", {
                                className: Fe.datetimeContainer,
                                "data-aos": "fade-up",
                                children: (0, u.jsxs)("div", {
                                    className: Fe.eventMetas,
                                    children: [(0, u.jsxs)("div", {
                                        className: Fe.date,
                                        "data-aos": "fade-up",
                                        children: [(0, u.jsxs)("svg", {
                                            viewBox: "0 0 24 24",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [(0, u.jsx)("path", {
                                                d: "M7 11C7 10.4477 7.44772 10 8 10C8.55228 10 9 10.4477 9 11C9 11.5523 8.55228 12 8 12C7.44772 12 7 11.5523 7 11Z"
                                            }), (0, u.jsx)("path", {
                                                d: "M7 16C7 15.4477 7.44772 15 8 15C8.55228 15 9 15.4477 9 16C9 16.5523 8.55228 17 8 17C7.44772 17 7 16.5523 7 16Z"
                                            }), (0, u.jsx)("path", {
                                                d: "M11 11C11 10.4477 11.4477 10 12 10C12.5523 10 13 10.4477 13 11C13 11.5523 12.5523 12 12 12C11.4477 12 11 11.5523 11 11Z"
                                            }), (0, u.jsx)("path", {
                                                d: "M11 16C11 15.4477 11.4477 15 12 15C12.5523 15 13 15.4477 13 16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16Z"
                                            }), (0, u.jsx)("path", {
                                                d: "M15 11C15 10.4477 15.4477 10 16 10C16.5523 10 17 10.4477 17 11C17 11.5523 16.5523 12 16 12C15.4477 12 15 11.5523 15 11Z"
                                            }), (0, u.jsx)("path", {
                                                d: "M15 16C15 15.4477 15.4477 15 16 15C16.5523 15 17 15.4477 17 16C17 16.5523 16.5523 17 16 17C15.4477 17 15 16.5523 15 16Z"
                                            }), (0, u.jsx)("path", {
                                                "fill-rule": "evenodd",
                                                "clip-rule": "evenodd",
                                                d: "M8 2C8.55228 2 9 2.44772 9 3V4H15V3C15 2.44772 15.4477 2 16 2C16.5523 2 17 2.44772 17 3V4C19.7614 4 22 6.23858 22 9V17C22 19.7614 19.7614 22 17 22H7C4.23858 22 2 19.7614 2 17V9C2 6.23858 4.23858 4 7 4V3C7 2.44772 7.44772 2 8 2ZM7 6C5.34315 6 4 7.34315 4 9V17C4 18.6569 5.34315 20 7 20H17C18.6569 20 20 18.6569 20 17V9C20 7.34315 18.6569 6 17 6C17 6.55229 16.5523 7 16 7C15.4477 7 15 6.55229 15 6H9C9 6.55229 8.55228 7 8 7C7.44772 7 7 6.55229 7 6Z"
                                            })]
                                        }), (0, u.jsx)("div", {
                                            children: (0, u.jsx)("p", {
                                                children: "24 October - 25 October"
                                            })
                                        })]
                                    }), (0, u.jsxs)("div", {
                                        className: Fe.time,
                                        "data-aos": "fade-up",
                                        children: [(0, u.jsx)("svg", {
                                            viewBox: "0 0 24 24",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: (0, u.jsx)("path", {
                                                d: "M12 8V12L14 14M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z",
                                                stroke: "#ffffff",
                                                "stroke-width": "1.5",
                                                "stroke-linecap": "round",
                                                "stroke-linejoin": "round"
                                            })
                                        }), (0, u.jsx)("div", {
                                            children: (0, u.jsx)("p", {
                                                children: "2 PM - 2 PM (IST) "
                                            })
                                        })]
                                    }), (0, u.jsxs)("div", {
                                        className: Fe.venue,
                                        "data-aos": "fade-up",
                                        children: [(0, u.jsx)("svg", {
                                            viewBox: "0 0 297 297",
                                            children: (0, u.jsx)("path", {
                                                d: "M148.5,0C87.43,0,37.747,49.703,37.747,110.797c0,91.026,99.729,179.905,103.976,183.645 c1.936,1.705,4.356,2.559,6.777,2.559c2.421,0,4.841-0.853,6.778-2.559c4.245-3.739,103.975-92.618,103.975-183.645 C259.253,49.703,209.57,0,148.5,0z M148.5,79.693c16.964,0,30.765,13.953,30.765,31.104c0,17.151-13.801,31.104-30.765,31.104 c-16.964,0-30.765-13.953-30.765-31.104C117.735,93.646,131.536,79.693,148.5,79.693z"
                                            })
                                        }), (0, u.jsx)("div", {
                                            children: (0, u.jsx)("p", {
                                                children: "Government Polytechnic, Nagpur"
                                            })
                                        })]
                                    })]
                                })
                            })]
                        }), (0, u.jsx)("p", {
                            className: Fe.countdownTooltip,
                            "data-aos": "fade-down",
                            children: i
                        }), (0, u.jsx)("div", {
                            className: Fe.countdownContainer,
                            children: Object.keys(e).map((function (t) {
                                return (0, u.jsxs)(u.Fragment, {
                                    children: [(0, u.jsxs)("div", {
                                        className: Fe.countdownBox,
                                        children: [(0, u.jsx)("div", {
                                            className: Fe.countdownNumber,
                                            "data-aos": "fade-down",
                                            children: e[t] >= 0 ? e[t] : 0
                                        }), (0, u.jsx)("div", {
                                            className: Fe.countdownText,
                                            "data-aos": "fade-up",
                                            children: t
                                        })]
                                    }), "Secs" !== t && (0, u.jsx)("div", {
                                        className: "".concat(Fe.timeSeparator, " ").concat(e.seconds % 2 === 0 ? Fe.active : Fe.inactive),
                                        children: ":"
                                    })]
                                })
                            }))
                        }), (0, u.jsx)("div", {
                            className: Fe.registerBtn,
                            "data-aos": "fade-up",
                            children: (0, u.jsx)("button", {
                                children: (0, u.jsx)("a", {
                                    href: "https://lu.ma/09lmt81v",
                                    target: "_blank",
                                    children: "Register Now"
                                })
                            })
                        })]
                    })
                },
                Ve = "Leaderboard_rootLeaderboard__uFmxv",
                He = "Leaderboard_button__oboUL",
                We = function () {
                    return (0, u.jsxs)("div", {
                        className: Ve,
                        children: [(0, u.jsx)("div", {
                            className: He,
                            children: (0, u.jsx)("a", {
                                href: "https://github.com/AvinashMohare/AI-Odyssey/blob/main/README.md",
                                target: "_blank",
                                children: "Instructions"
                            })
                        }), (0, u.jsx)("div", {
                            className: He,
                            children: (0, u.jsx)("a", {
                                href: "https://keepthescore.co/board/sdpdsfxdymqmr/",
                                target: "_blank",
                                children: "Leaderboard"
                            })
                        })]
                    })
                };
            var Qe = function () {
                return (0, e.useEffect)((function () {
                    a().init({
                        duration: 1828.3268,
                        initClassName: "sb-initial-anim",
                        once: !1,
                        mirror: !0,
                        offset: 50,
                        debounceDelay: 100,
                        throttleDelay: 100
                    })
                }), []), (0, u.jsx)("div", {
                    children: (0, u.jsxs)("div", {
                        className: "body",
                        children: [bool ? (0, u.jsx)(Re, {}) : null, (0, u.jsx)(ne, { num: prime }), (0, u.jsx)(Be, {}), (0, u.jsx)(P, {}),]
                    })
                })
            };
            t.createRoot(document.getElementById("root")).render((0, u.jsx)(e.StrictMode, {
                children: (0, u.jsx)(Qe, {})
            }))
        }()
};

primary_crowd(1, true)
